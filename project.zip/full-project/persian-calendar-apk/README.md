# بسته آماده‌سازی APK برای تقویم شمسی (نسخه آفلاین/محلی)

این پوشه شامل فایل‌های لازم برای تبدیل اپ وب تقویم به APK اندرویدی آفلاین است.

## محتویات

```
persian-calendar-apk/
├── README.md                          # این فایل
├── BUILD-GUIDE.md                     # راهنمای جامع ساخت APK (۳ روش)
├── twa-config/
│   ├── twa-manifest.json              # پیکربندی نمونه برای Bubblewrap (آفلاین)
│   └── assetlinks-template.json       # الگوی Asset Links
└── source-code/                       # کد منبع پروژه Next.js (برای build)
```

## شروع سریع

### روش توصیه‌شده: Capacitor (آفلاین کامل)

```bash
cd source-code
npm install

# ویرایش next.config.ts: output: 'export' را اضافه کنید
npm run build

npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "تقویم شمسی" "com.persiancalendar.app" --web-dir=out
npx cap add android
npx cap copy
npx cap sync
npx cap open android
# در Android Studio: Build > Build APK(s)
```

### روش ساده: PWA روی گوشی

1. اپ را روی localhost اجرا کنید
2. در کروم اندروید باز کنید
3. Add to Home screen

---

## قابلیت‌های اپ

- 📅 تقویم شمسی-میلادی با نمایش مناسبت‌ها
- 🌙 مناسبت‌های شمسی، قمری و جهانی (قابل فعال/غیرفعال در تنظیمات)
- 🔄 تبدیل تاریخ دو طرفه
- 🎂 محاسبه سن دقیق (ذخیره آخرین محاسبه)
- 🔔 یادآورها با نوتیفیکیشن مرورگری
- 📝 یادداشت‌های عمومی (مثل یادداشت گوشی)
- 📱 پیامک خودکار به تولدها (sms: link)
- ✏️ ویرایش و حذف یادآورها
- 🎨 رابط کاربری با استایل اپل و تم لایت
- 📱 ریسپانسیو و PWA
- 🔒 کاملاً آفلاین و محلی

## مشخصات

| ویژگی | مقدار |
|---|---|
| نام | تقویم شمسی میلادی |
| Package ID | `com.persiancalendar.app` |
| حداقل اندروید | ۸.۰ (API 26) |
| زبان | فارسی (RTL) |
| تم رنگ | `#5856D6` |
| حالت | آفلاین / محلی |
| اندازه APK | ۳-۵ مگابایت |

برای جزئیات کامل، فایل **BUILD-GUIDE.md** را بخوانید.
