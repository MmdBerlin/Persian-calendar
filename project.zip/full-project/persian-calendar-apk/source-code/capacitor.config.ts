import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.persiancalendar.app',
  appName: 'تقویم شمسی',
  webDir: 'out',
  android: {
    // Allow the web view to access in-app content only; sms:/tel: links
    // are handled by the OS through intent filters.
    allowMixedContent: false,
  },
  plugins: {
    LocalNotifications: {
      smallIcon: 'ic_stat_icon',
      iconColor: '#5856D6',
    },
    StatusBar: {
      backgroundColor: '#FFFFFF',
      style: 'LIGHT',
      overlaysWebView: false,
    },
  },
};

export default config;
