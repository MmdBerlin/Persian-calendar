// Run after `npx cap add android`: copies native resources into the generated
// android/ project (the android/ folder is generated in CI and not committed).
import { cpSync, existsSync, mkdirSync } from 'node:fs';

const resSrc = 'android-resources';
const resDst = 'android/app/src/main/res';

if (!existsSync('android')) {
  console.error('android/ not found. Run `npx cap add android` first.');
  process.exit(1);
}

mkdirSync(resDst, { recursive: true });
cpSync(resSrc, resDst, { recursive: true });
console.log(`Copied ${resSrc} -> ${resDst} (notification icon ic_stat_icon)`);
