// Run after `npx cap add android` (and again after every `npx cap sync` if you like; it is idempotent).
// The android/ folder is generated in CI and not committed, so project-specific native tweaks live here:
//   1. copies android-resources/ (notification icon, splash drawable, splash colors) into the project
//   2. removes the default splash.png images so our splash.xml is used
//   3. patches styles.xml: light (never dark/black) window background + branded launch splash
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const resSrc = 'android-resources';
const resDst = 'android/app/src/main/res';

if (!existsSync('android')) {
  console.error('android/ not found. Run `npx cap add android` first.');
  process.exit(1);
}

// 1) resources
mkdirSync(resDst, { recursive: true });
cpSync(resSrc, resDst, { recursive: true });
console.log(`Copied ${resSrc} -> ${resDst}`);

// 2) default splash images (a splash.png next to our splash.xml would be a duplicate resource)
for (const dir of readdirSync(resDst)) {
  if (!dir.startsWith('drawable')) continue;
  const png = join(resDst, dir, 'splash.png');
  if (existsSync(png)) {
    rmSync(png);
    console.log(`Removed ${png}`);
  }
}

// 3) styles.xml
const stylesPath = join(resDst, 'values', 'styles.xml');
if (existsSync(stylesPath)) {
  let s = readFileSync(stylesPath, 'utf8');
  const before = s;

  // DayNight theme turns the window black on phones in dark mode; the app UI is light-only.
  s = s.replace('Theme.AppCompat.DayNight.NoActionBar', 'Theme.AppCompat.Light.NoActionBar');

  if (!s.includes('android:windowBackground')) {
    s = s.replace(
      /(<style name="AppTheme\.NoActionBar"[^>]*>)/,
      '$1\n        <item name="android:windowBackground">@color/splash_background</item>'
    );
  }
  if (!s.includes('windowSplashScreenBackground')) {
    s = s.replace(
      /(<style name="AppTheme\.NoActionBarLaunch"[^>]*>)/,
      '$1\n        <item name="windowSplashScreenBackground">@color/splash_background</item>' +
        '\n        <item name="windowSplashScreenAnimatedIcon">@drawable/splash_icon</item>'
    );
  }
  if (s !== before) {
    writeFileSync(stylesPath, s);
    console.log('Patched styles.xml (light window background + branded splash)');
  } else {
    console.log('styles.xml already patched');
  }
}

// 4) AndroidManifest: exact alarms, so a reminder set for 09:35 fires at 09:35 and not minutes later.
//    (Android 14+ denies SCHEDULE_EXACT_ALARM by default; USE_EXACT_ALARM is granted automatically.)
const manifestPath = 'android/app/src/main/AndroidManifest.xml';
if (existsSync(manifestPath)) {
  let m = readFileSync(manifestPath, 'utf8');
  const perms = ['android.permission.USE_EXACT_ALARM', 'android.permission.SCHEDULE_EXACT_ALARM'];
  let changed = false;
  for (const perm of perms) {
    if (!m.includes(`"${perm}"`)) {
      m = m.replace('</manifest>', `    <uses-permission android:name="${perm}" />\n</manifest>`);
      changed = true;
    }
  }
  if (changed) {
    writeFileSync(manifestPath, m);
    console.log('Patched AndroidManifest.xml (exact alarm permissions)');
  }
}
