'use client';

import { useEffect, useCallback, useRef, useSyncExternalStore } from 'react';
import type { Reminder } from '@/hooks/use-reminders';
import {
  todayJalali,
  daysBetweenJalali,
  jalaliToGregorian,
  gregorianToJalali,
  toPersianDigits,
  type JalaliDate,
} from '@/lib/jalali';
import {
  detectNotificationChannel,
  isNativePlatform,
  notificationsSupported,
  scheduleReminderNotifications,
  cancelAllScheduledNotifications,
  requestNotificationPermission,
  checkNotificationPermission,
  showNotification,
  type NotificationChannel,
} from '@/lib/notifications';

const PERMISSION_KEY = 'persian-calendar-notification-permission-requested';
const LAST_CHECK_KEY = 'persian-calendar-notification-last-check';
const ENABLED_KEY = 'persian-calendar-notifications-enabled';

export type NotificationPermissionState = 'default' | 'granted' | 'denied' | 'unsupported';

// --- permission store (useSyncExternalStore) ---
const permListeners = new Set<() => void>();
let permOverride: NotificationPermissionState | null = null;
function notifyPermListeners() {
  permListeners.forEach((l) => l());
}
function subscribePerm(cb: () => void) {
  permListeners.add(cb);
  return () => permListeners.delete(cb);
}
function getPermissionClient(): NotificationPermissionState {
  if (permOverride) return permOverride;
  if (typeof window === 'undefined') return 'unsupported';
  if (!notificationsSupported()) return 'unsupported';
  // Android APK: never read the (absent) Web Notification API, the real
  // permission is resolved asynchronously through the native plugin.
  if (isNativePlatform()) return 'default';
  // Web API available (Capacitor path resolves async via override)
  if ('Notification' in window) {
    return Notification.permission as NotificationPermissionState;
  }
  // Capacitor-only environment: assume default until checked async
  return 'default';
}
function getPermissionServer(): NotificationPermissionState {
  return 'default';
}
// --- end permission store ---

// --- enabled store ---
const enabledListeners = new Set<() => void>();
function notifyEnabledListeners() {
  enabledListeners.forEach((l) => l());
}
function subscribeEnabled(cb: () => void) {
  enabledListeners.add(cb);
  if (typeof window !== 'undefined') {
    window.addEventListener('storage', handleStorageEvent);
  }
  return () => {
    enabledListeners.delete(cb);
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', handleStorageEvent);
    }
  };
}
function handleStorageEvent(e: StorageEvent) {
  if (e.key === ENABLED_KEY) {
    notifyEnabledListeners();
  }
}
function getEnabledClient(): boolean {
  if (typeof window === 'undefined') return false;
  // In Capacitor there is no Notification.permission gate — only our flag
  const channel = detectNotificationChannel();
  if (channel === 'capacitor') {
    try {
      return localStorage.getItem(ENABLED_KEY) === 'true';
    } catch {
      return false;
    }
  }
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return false;
  try {
    return localStorage.getItem(ENABLED_KEY) === 'true';
  } catch {
    return false;
  }
}
function getEnabledServer(): boolean {
  return false;
}
function setEnabledStore(value: boolean) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(ENABLED_KEY, value ? 'true' : 'false');
  } catch {
    // ignore
  }
  notifyEnabledListeners();
}
// --- end enabled store ---

// --- channel store (useSyncExternalStore; the channel never changes at runtime) ---
const channelListeners = new Set<() => void>();
function subscribeChannel(cb: () => void) {
  channelListeners.add(cb);
  return () => channelListeners.delete(cb);
}
let cachedChannel: NotificationChannel | null = null;
function getChannelClient(): NotificationChannel {
  if (cachedChannel === null) {
    cachedChannel = detectNotificationChannel();
  }
  return cachedChannel;
}
function getChannelServer(): NotificationChannel {
  return 'webapi'; // server snapshot; matches typical browser render
}
// --- end channel store ---

/**
 * Calculate days until next occurrence of a reminder from today
 */
function daysUntilNext(r: Reminder, today: JalaliDate): number {
  let reminderJalali: JalaliDate;
  if (r.calendar === 'jalali') {
    reminderJalali = { jy: today.jy, jm: r.month, jd: r.day };
  } else {
    const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
    reminderJalali = gregorianToJalali(todayG.gy, r.month, r.day);
  }
  let days = daysBetweenJalali(today, reminderJalali);
  if (days < 0) {
    if (r.calendar === 'jalali') {
      reminderJalali = { jy: today.jy + 1, jm: r.month, jd: r.day };
    } else {
      const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
      reminderJalali = gregorianToJalali(todayG.gy + 1, r.month, r.day);
    }
    days = daysBetweenJalali(today, reminderJalali);
  }
  return days;
}

export function useNotifications(reminders: Reminder[]) {
  const permission = useSyncExternalStore(subscribePerm, getPermissionClient, getPermissionServer);
  const enabled = useSyncExternalStore(subscribeEnabled, getEnabledClient, getEnabledServer);
  const firedRef = useRef<Set<string>>(new Set());

  // The channel we're actually running on (for UI hints) — no setState-in-effect
  const channel = useSyncExternalStore(subscribeChannel, getChannelClient, getChannelServer);

  // In Capacitor, permission resolves asynchronously — kick off the check once
  // and push the result into the external permission store (not React state).
  useEffect(() => {
    if (channel !== 'capacitor' || permOverride) return;
    let cancelled = false;
    checkNotificationPermission().then((perm) => {
      if (cancelled || permOverride) return; // user already acted
      if (perm === 'granted') {
        permOverride = 'granted';
      } else if (perm === 'denied') {
        permOverride = 'denied';
      }
      notifyPermListeners();
    }).catch(() => { /* ignore */ });
    return () => { cancelled = true; };
  }, [channel]);

  // Request permission from user (works on both Capacitor and web)
  const requestPermission = useCallback(async (): Promise<boolean> => {
    const result = await requestNotificationPermission();
    const mapped: NotificationPermissionState =
      result === 'granted' ? 'granted' :
      result === 'denied' ? 'denied' :
      result === 'unsupported' ? 'unsupported' : 'default';
    permOverride = mapped;
    notifyPermListeners();

    if (mapped === 'granted') {
      setEnabledStore(true);
      try {
        localStorage.setItem(PERMISSION_KEY, 'true');
      } catch { /* ignore */ }
      // Welcome notification (best effort)
      setTimeout(() => {
        showNotification({
          title: 'تقویم شمسی',
          body: 'نوتیفیکیشن با موفقیت فعال شد',
          tag: 'welcome',
        }).catch(() => { /* ignore */ });
      }, 400);
      return true;
    }
    return false;
  }, []);

  const disable = useCallback(() => {
    setEnabledStore(false);
  }, []);

  // Fire a single notification
  const fireNotification = useCallback((reminder: Reminder, daysUntil: number) => {
    if (!enabled || permission !== 'granted') return;
    if (typeof window === 'undefined') return;

    const fireKey = `${reminder.id}-${daysUntil}`;
    if (firedRef.current.has(fireKey)) return;
    firedRef.current.add(fireKey);

    let title: string;
    let body: string;

    if (daysUntil === 0) {
      title = reminder.title;
      body = reminder.description
        ? `${reminder.description} — امروز`
        : 'امروز فرا رسیده است';
    } else if (daysUntil === 1) {
      title = reminder.title;
      body = 'فردا فرا می رسد';
    } else {
      title = reminder.title;
      body = `${toPersianDigits(daysUntil)} روز دیگر فرا می رسد`;
    }

    showNotification({ title, body, tag: reminder.id }).catch((e) => {
      console.error('Failed to fire notification:', e);
    });
  }, [enabled, permission]);

  // Check reminders and fire notifications if needed
  const checkAndFire = useCallback(() => {
    if (channel === 'capacitor') return; // native: scheduled ahead of time, see effect below
    if (!enabled || permission !== 'granted') return;
    if (typeof window === 'undefined') return;

    const today = todayJalali();

    reminders.forEach((r) => {
      const days = daysUntilNext(r, today);
      if (days === 0 || days === r.notifyDaysBefore) {
        fireNotification(r, days);
      }
    });

    try {
      localStorage.setItem(LAST_CHECK_KEY, `${today.jy}-${today.jm}-${today.jd}`);
    } catch {
      // ignore
    }
  }, [channel, enabled, permission, reminders, fireNotification]);

  // Periodic checks (browser only)
  useEffect(() => {
    if (channel === 'capacitor') return;
    if (!enabled || permission !== 'granted') return;
    const initialTimer = setTimeout(() => checkAndFire(), 1500);
    const interval = setInterval(() => checkAndFire(), 30 * 60 * 1000);
    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, [channel, enabled, permission, checkAndFire]);

  // Browser/PWA: schedule same-day timeouts at each reminder's notifyHour
  // so notifications still fire while the tab is open (even if not "today" at load).
  useEffect(() => {
    if (channel === 'capacitor') return;
    if (!enabled || permission !== 'granted') return;
    if (typeof window === 'undefined') return;

    const timers: ReturnType<typeof setTimeout>[] = [];
    const today = todayJalali();
    const now = Date.now();

    reminders.forEach((r) => {
      const days = daysUntilNext(r, today);
      const targets: number[] = [0];
      if (r.notifyDaysBefore > 0) targets.push(r.notifyDaysBefore);

      targets.forEach((offset) => {
        if (days !== offset) return;
        const hour =
          typeof r.notifyHour === 'number' && r.notifyHour >= 0 && r.notifyHour <= 23
            ? Math.floor(r.notifyHour)
            : 9;
        const fireAt = new Date();
        fireAt.setHours(hour, 0, 0, 0);
        let delay = fireAt.getTime() - now;
        if (delay < 0) {
          // hour already passed — fire once soon if not yet fired today
          delay = 3000;
        }
        if (delay > 24 * 60 * 60 * 1000) return;
        const t = setTimeout(() => {
          fireNotification(r, offset);
        }, delay);
        timers.push(t);
      });
    });

    return () => timers.forEach(clearTimeout);
  }, [channel, enabled, permission, reminders, fireNotification]);

  // Fire for newly added reminders
  const prevRemindersRef = useRef<Reminder[]>([]);
  useEffect(() => {
    if (channel === 'capacitor') return;
    if (!enabled || permission !== 'granted') return;
    const prevIds = new Set(prevRemindersRef.current.map((r) => r.id));
    const newReminders = reminders.filter((r) => !prevIds.has(r.id));
    if (newReminders.length > 0 && prevRemindersRef.current.length > 0) {
      const today = todayJalali();
      newReminders.forEach((r) => {
        const days = daysUntilNext(r, today);
        if (days === 0 || days === r.notifyDaysBefore) {
          fireNotification(r, days);
        }
      });
    }
    prevRemindersRef.current = reminders;
  }, [channel, reminders, enabled, permission, fireNotification]);

  // Android APK: (re)schedule native notifications so they are delivered at
  // the right time even when the app is closed. Runs on start, on every
  // reminder change and whenever the app comes back to the foreground.
  useEffect(() => {
    if (channel !== 'capacitor') return;
    if (permission === 'default' || permission === 'unsupported') return; // not resolved yet
    if (!enabled || permission !== 'granted') {
      void cancelAllScheduledNotifications();
      return;
    }
    void scheduleReminderNotifications(reminders);
    const onVisible = () => {
      if (document.visibilityState === 'visible') {
        void scheduleReminderNotifications(reminders);
      }
    };
    document.addEventListener('visibilitychange', onVisible);
    return () => document.removeEventListener('visibilitychange', onVisible);
  }, [channel, enabled, permission, reminders]);

  // Manual test notification
  const sendTestNotification = useCallback(() => {
    if (permission !== 'granted') return;
    showNotification({
      title: 'تقویم شمسی — آزمایش',
      body: 'این یک نوتیفیکیشن آزمایشی است',
      tag: 'test',
    }).catch((e) => {
      console.error('Test notification failed:', e);
    });
  }, [permission]);

  return {
    permission,
    enabled,
    channel,
    requestPermission,
    disable,
    sendTestNotification,
    fireNotification,
    checkAndFire,
  };
}
