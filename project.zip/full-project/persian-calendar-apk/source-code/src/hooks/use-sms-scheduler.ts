'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import type { Reminder } from '@/hooks/use-reminders';
import {
  todayJalali,
  daysBetweenJalali,
  jalaliToGregorian,
  gregorianToJalali,
  toPersianDigits,
  type JalaliDate,
} from '@/lib/jalali';

const LAST_SMS_KEY = 'persian-calendar-last-sms-check';
const SMS_FIRED_KEY = 'persian-calendar-sms-fired';

/**
 * useSmsScheduler — checks birthday reminders for today and, at the configured hour,
 * opens an sms: link so the user can send a pre-filled SMS.
 *
 * Note: In a fully offline TWA app, we cannot send SMS silently. Instead, at the
 * configured hour, the app opens the default SMS app with the recipient and body
 * pre-filled. The user just taps "Send".
 */
export function useSmsScheduler(reminders: Reminder[]) {
  const firedRef = useRef<Set<string>>(new Set());

  // Load fired SMS ids from sessionStorage (per-session dedup)
  useEffect(() => {
    try {
      const raw = sessionStorage.getItem(SMS_FIRED_KEY);
      if (raw) {
        const arr = JSON.parse(raw) as string[];
        firedRef.current = new Set(arr);
      }
    } catch {
      // ignore
    }
  }, []);

  const markFired = useCallback((id: string) => {
    firedRef.current.add(id);
    try {
      sessionStorage.setItem(SMS_FIRED_KEY, JSON.stringify([...firedRef.current]));
    } catch {
      // ignore
    }
  }, []);

  const openSmsLink = useCallback((reminder: Reminder) => {
    if (!reminder.smsPhone || !reminder.smsText) return;

    // Compute age if birthday with year
    let age = '';
    if (reminder.type === 'birthday' && reminder.year) {
      const today = todayJalali();
      const birthJ = reminder.calendar === 'jalali'
        ? { jy: reminder.year, jm: reminder.month, jd: reminder.day }
        : gregorianToJalali(reminder.year, reminder.month, reminder.day);
      age = String(today.jy - birthJ.jy);
    }

    // Replace placeholders
    const body = reminder.smsText
      .replace(/\{name\}/g, reminder.title)
      .replace(/\{age\}/g, age || '');

    // Build sms: link. Format: sms:<phone>?body=<encoded>
    // On Android, this opens the default SMS app with prefilled fields.
    const phone = reminder.smsPhone.replace(/\s/g, '');
    const encodedBody = encodeURIComponent(body);
    const smsUrl = `sms:${phone}?body=${encodedBody}`;

    // Prefer opening without navigating the whole app away
    try {
      const a = document.createElement('a');
      a.href = smsUrl;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } catch (e) {
      try {
        window.open(smsUrl, '_blank');
      } catch (e2) {
        console.error('Failed to open SMS link:', e2);
      }
    }

    markFired(reminder.id);
  }, [markFired]);

  /** Manual trigger from UI (e.g. reminder card button). */
  const sendSmsNow = useCallback((reminder: Reminder) => {
    openSmsLink(reminder);
  }, [openSmsLink]);

  // Check every minute if it's time to send SMS
  useEffect(() => {
    const check = () => {
      const now = new Date();
      const currentHour = now.getHours();
      const today = todayJalali();

      reminders.forEach((r) => {
        if (r.type !== 'birthday' || !r.smsEnabled || !r.smsPhone) return;
        const targetHour = r.smsHour ?? 9;

        // Is today the birthday?
        let reminderJalali: JalaliDate;
        if (r.calendar === 'jalali') {
          reminderJalali = { jy: today.jy, jm: r.month, jd: r.day };
        } else {
          const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
          reminderJalali = gregorianToJalali(todayG.gy, r.month, r.day);
        }
        const days = daysBetweenJalali(today, reminderJalali);

        // Birthday today: open SMS once when we reach (or pass) the target hour
        // while the app is in the foreground.
        if (days === 0 && currentHour === targetHour) {
          if (!firedRef.current.has(r.id)) {
            openSmsLink(r);
          }
        }
      });
    };

    // Check immediately, then every 30s near the hour for better reliability
    const interval = setInterval(check, 30 * 1000);
    const initial = setTimeout(check, 1500);

    return () => {
      clearInterval(interval);
      clearTimeout(initial);
    };
  }, [reminders, openSmsLink]);

  return { sendSmsNow };
}
