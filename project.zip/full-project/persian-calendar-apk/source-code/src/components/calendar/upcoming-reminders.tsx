'use client';

import { useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Bell, Clock } from 'lucide-react';
import {
  JALALI_MONTHS,
  GREGORIAN_MONTHS,
  toPersianDigits,
  todayJalali,
  daysBetweenJalali,
  jalaliToGregorian,
  gregorianToJalali,
  type JalaliDate,
} from '@/lib/jalali';
import type { Reminder } from '@/hooks/use-reminders';
import { REMINDER_TYPE_COLORS, REMINDER_TYPE_LABELS } from '@/lib/reminder-types';
import { Badge } from '@/components/ui/badge';

interface UpcomingRemindersProps {
  reminders: Reminder[];
  limit?: number;
}

export function UpcomingReminders({ reminders, limit = 5 }: UpcomingRemindersProps) {
  const today = todayJalali();

  const upcoming = useMemo(() => {
    return reminders
      .map((r) => {
        let reminderJalali: JalaliDate;
        if (r.calendar === 'jalali') {
          reminderJalali = { jy: today.jy, jm: r.month, jd: r.day };
        } else {
          const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
          reminderJalali = gregorianToJalali(todayG.gy, r.month, r.day);
        }
        let days = daysBetweenJalali(today, reminderJalali);
        if (days < 0) {
          if (r.calendar === 'jalali') {
            reminderJalali = { jy: today.jy + 1, jm: r.month, jd: r.day };
          } else {
            const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
            reminderJalali = gregorianToJalali(todayG.gy + 1, r.month, r.day);
          }
          days = daysBetweenJalali(today, reminderJalali);
        }
        return { reminder: r, days, date: reminderJalali };
      })
      .sort((a, b) => a.days - b.days)
      .slice(0, limit);
  }, [reminders, today, limit]);

  return (
    <Card className="glass-card p-5 border-0 rounded-3xl">
      <div className="flex items-center gap-3 mb-4">
        <div className="h-9 w-9 rounded-lg bg-amber-100 flex items-center justify-center">
          <Clock className="h-4 w-4 text-amber-600" />
        </div>
        <div>
          <h3 className="text-base font-bold">یادآورهای پیش رو</h3>
          <p className="text-xs text-muted-foreground">نزدیک‌ترین مناسبت‌ها</p>
        </div>
      </div>

      {upcoming.length === 0 ? (
        <div className="text-center py-8">
          <Bell className="h-8 w-8 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-xs text-muted-foreground">یادآوری وجود ندارد</p>
        </div>
      ) : (
        <div className="space-y-2">
          {upcoming.map(({ reminder: r, days, date }) => {
            const isToday = days === 0;
            return (
              <div
                key={r.id}
                className={`flex items-center gap-3 p-2.5 rounded-lg ${
                  isToday ? 'bg-rose-50' : 'bg-background/50'
                }`}
              >
                <div className="flex flex-col items-center justify-center min-w-[44px]">
                  <span className="text-lg font-bold leading-none">
                    {toPersianDigits(date.jd)}
                  </span>
                  <span className="text-[10px] text-muted-foreground mt-0.5">
                    {r.calendar === 'jalali' ? JALALI_MONTHS[date.jm - 1] : GREGORIAN_MONTHS[r.month - 1].slice(0, 3)}
                  </span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{r.title}</div>
                  <div className="flex items-center gap-2 mt-0.5">
                    <Badge variant="outline" className={`text-[9px] px-1.5 py-0 ${REMINDER_TYPE_COLORS[r.type]}`}>
                      {REMINDER_TYPE_LABELS[r.type]}
                    </Badge>
                    {isToday ? (
                      <span className="text-[11px] text-rose-600 font-medium">امروز!</span>
                    ) : (
                      <span className="text-[11px] text-muted-foreground">
                        {toPersianDigits(days)} روز دیگر
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </Card>
  );
}
