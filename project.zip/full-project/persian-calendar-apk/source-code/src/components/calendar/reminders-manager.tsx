'use client';

import { useState, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Plus, Pencil, Trash2, Bell, Gift, Calendar, Star, CheckCircle2, MessageSquare, CheckSquare } from 'lucide-react';
import {
  JALALI_MONTHS,
  GREGORIAN_MONTHS,
  toPersianDigits,
  todayJalali,
  daysBetweenJalali,
  jalaliToGregorian,
  gregorianToJalali,
  isJalaliLeap,
  type JalaliDate,
} from '@/lib/jalali';
import {
  useReminders,
  type Reminder,
  type ReminderType,
} from '@/hooks/use-reminders';
import {
  REMINDER_TYPE_LABELS,
  REMINDER_TYPE_COLORS,
} from '@/lib/reminder-types';

interface RemindersManagerProps {
  remindersHook: ReturnType<typeof useReminders>;
  onSendSms?: (r: Reminder) => void;
}

export function RemindersManager({ remindersHook, onSendSms }: RemindersManagerProps) {
  const { reminders, addReminder, updateReminder, deleteReminder, deleteMultiple, clearAll } = remindersHook;
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectionMode, setSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [confirmClearAll, setConfirmClearAll] = useState(false);

  const sortedReminders = useMemo(() => {
    const today = todayJalali();
    return [...reminders].sort((a, b) => {
      const aDays = daysUntilNext(a, today);
      const bDays = daysUntilNext(b, today);
      return aDays - bDays;
    });
  }, [reminders]);

  const openNewDialog = () => {
    setEditingId(null);
    setDialogOpen(true);
  };

  const openEditDialog = (id: string) => {
    if (selectionMode) {
      toggleSelect(id);
      return;
    }
    setEditingId(id);
    setDialogOpen(true);
  };

  const handleClose = () => {
    setDialogOpen(false);
    setTimeout(() => setEditingId(null), 200);
  };

  const handleSave = (data: Omit<Reminder, 'id' | 'createdAt'>) => {
    if (editingId) {
      updateReminder(editingId, data);
    } else {
      addReminder(data);
    }
    handleClose();
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const exitSelectionMode = () => {
    setSelectionMode(false);
    setSelectedIds(new Set());
  };

  const handleBulkDelete = () => {
    if (selectedIds.size === 0) return;
    deleteMultiple([...selectedIds]);
    exitSelectionMode();
  };

  const handleClearAll = () => {
    clearAll();
    setConfirmClearAll(false);
    exitSelectionMode();
  };

  const editingReminder = editingId ? reminders.find((r) => r.id === editingId) : null;

  return (
    <Card className="glass-card p-6 border-0 rounded-3xl">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-blue-100 flex items-center justify-center">
            <Bell className="h-5 w-5 text-blue-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold">یادآورها</h3>
            <p className="text-sm text-muted-foreground">
              {selectionMode
                ? `${toPersianDigits(selectedIds.size)} انتخاب شده`
                : 'تولدها، سالگردها و مناسبت‌های شما'}
            </p>
          </div>
        </div>
        {selectionMode ? (
          <div className="flex items-center gap-1.5">
            <Button
              variant="ghost"
              size="sm"
              onClick={exitSelectionMode}
              className="rounded-xl text-xs h-9"
            >
              لغو
            </Button>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleBulkDelete}
              disabled={selectedIds.size === 0}
              className="rounded-xl text-xs h-9 gap-1.5"
            >
              <Trash2 className="h-3.5 w-3.5" />
              حذف ({toPersianDigits(selectedIds.size)})
            </Button>
          </div>
        ) : (
          <div className="flex items-center gap-1.5">
            {reminders.length > 0 && (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectionMode(true)}
                  className="rounded-xl text-xs h-9"
                  aria-label="حذف چندتایی"
                >
                  <CheckSquare className="h-3.5 w-3.5 ml-1" />
                  انتخاب
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setConfirmClearAll(true)}
                  className="rounded-xl text-xs h-9 text-destructive hover:text-destructive"
                  aria-label="حذف همه"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </>
            )}
            <Button
              onClick={openNewDialog}
              className="rounded-2xl h-9 w-9 p-0"
              aria-label="افزودن یادآور"
            >
              <Plus className="h-5 w-5" />
            </Button>
          </div>
        )}
      </div>

      {selectionMode && (
        <div className="mb-3 p-2 rounded-lg bg-primary/5 text-xs text-muted-foreground text-center">
          برای انتخاب روی یادآورها ضربه بزنید
        </div>
      )}

      {sortedReminders.length === 0 ? (
        <div className="text-center py-12">
          <div className="h-16 w-16 rounded-lg bg-muted mx-auto flex items-center justify-center mb-4">
            <Bell className="h-7 w-7 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground">
            هنوز یادآوری اضافه نکرده‌اید
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            روی دکمه + بزنید تا اولین یادآور را اضافه کنید
          </p>
        </div>
      ) : (
        <div className="space-y-2 max-h-[480px] overflow-y-auto pr-1">
          {sortedReminders.map((r) => (
            <ReminderItem
              key={r.id}
              reminder={r}
              onEdit={() => openEditDialog(r.id)}
              onDelete={() => {
                if (typeof window !== 'undefined' && window.confirm(`«${r.title}» حذف شود؟`)) {
                  deleteReminder(r.id);
                }
              }}
              selectionMode={selectionMode}
              isSelected={selectedIds.has(r.id)}
              onSendSms={onSendSms}
            />
          ))}
        </div>
      )}

      <ReminderDialog
        key={editingId || 'new'}
        open={dialogOpen}
        onOpenChange={(v) => { if (!v) handleClose(); }}
        editingReminder={editingReminder}
        onSave={handleSave}
      />

      {/* Clear all confirmation */}
      <Dialog open={confirmClearAll} onOpenChange={setConfirmClearAll}>
        <DialogContent className="sm:max-w-sm rounded-3xl" dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-lg">حذف همه یادآورها؟</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground py-2">
            آیا از حذف همه {toPersianDigits(reminders.length)} یادآور مطمئن هستید؟ این عمل قابل بازگشت نیست.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => setConfirmClearAll(false)} className="rounded-2xl">
              انصراف
            </Button>
            <Button variant="destructive" onClick={handleClearAll} className="rounded-2xl">
              بله، حذف کن
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function daysUntilNext(r: Reminder, today: JalaliDate): number {
  let reminderJalali: JalaliDate;
  if (r.calendar === 'jalali') {
    reminderJalali = { jy: today.jy, jm: r.month, jd: r.day };
  } else {
    const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
    reminderJalali = gregorianToJalali(todayG.gy, r.month, r.day);
  }

  let days = daysBetweenJalali(today, reminderJalali);
  if (days < 0) {
    if (r.calendar === 'jalali') {
      reminderJalali = { jy: today.jy + 1, jm: r.month, jd: r.day };
    } else {
      const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
      reminderJalali = gregorianToJalali(todayG.gy + 1, r.month, r.day);
    }
    days = daysBetweenJalali(today, reminderJalali);
  }
  return days;
}

function ReminderItem({
  reminder,
  onEdit,
  onDelete,
  selectionMode,
  isSelected,
  onSendSms,
}: {
  reminder: Reminder;
  onEdit: () => void;
  onDelete: () => void;
  selectionMode: boolean;
  isSelected: boolean;
  onSendSms?: (r: Reminder) => void;
}) {
  const [expanded, setExpanded] = useState(false);
  const today = todayJalali();
  const days = daysUntilNext(reminder, today);
  const isToday = days === 0;
  const isSoon = days > 0 && days <= 7;

  const typeIcon = {
    birthday: <Gift className="h-4 w-4" />,
    anniversary: <Star className="h-4 w-4" />,
    event: <Calendar className="h-4 w-4" />,
    task: <CheckCircle2 className="h-4 w-4" />,
    note: <Bell className="h-4 w-4" />,
  }[reminder.type];

  let ageInfo: string | null = null;
  if (reminder.type === 'birthday' && reminder.year) {
    const birthJ = reminder.calendar === 'jalali'
      ? { jy: reminder.year, jm: reminder.month, jd: reminder.day }
      : gregorianToJalali(reminder.year, reminder.month, reminder.day);
    const ageYears = today.jy - birthJ.jy;
    if (ageYears >= 0) {
      ageInfo = ` (${toPersianDigits(ageYears + 1)} سالگی)`;
    }
  }

  const hour =
    typeof reminder.notifyHour === 'number' ? reminder.notifyHour : 9;

  const handleCardClick = () => {
    if (selectionMode) {
      onEdit();
      return;
    }
    setExpanded((v) => !v);
  };

  return (
    <div
      className={`relative rounded-2xl border transition-all ${
        isToday && !isSelected
          ? 'bg-rose-50 border-rose-200'
          : isSoon && !isSelected
          ? 'bg-amber-50/50 border-amber-200'
          : isSelected
          ? 'bg-primary/5 border-primary ring-2 ring-primary'
          : 'bg-background/60 border-border'
      } ${expanded ? 'shadow-md' : 'hover:shadow-sm'}`}
    >
      <button
        type="button"
        className="w-full flex items-center gap-3 p-3 text-right"
        onClick={handleCardClick}
        aria-expanded={expanded}
      >
        <div className={`h-10 w-10 rounded-xl flex items-center justify-center flex-shrink-0 ${
          reminder.type === 'birthday' ? 'bg-pink-100 text-pink-600' :
          reminder.type === 'anniversary' ? 'bg-purple-100 text-purple-600' :
          reminder.type === 'event' ? 'bg-blue-100 text-blue-600' :
          reminder.type === 'task' ? 'bg-orange-100 text-orange-600' :
          'bg-gray-100 text-gray-600'
        }`}>
          {typeIcon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-semibold text-sm truncate">{reminder.title}</span>
            <Badge variant="outline" className={`text-[10px] px-2 py-0 ${REMINDER_TYPE_COLORS[reminder.type]}`}>
              {REMINDER_TYPE_LABELS[reminder.type]}
            </Badge>
            {reminder.smsEnabled && (
              <Badge variant="outline" className="text-[10px] px-2 py-0 bg-emerald-50 text-emerald-700 border-emerald-200">
                <MessageSquare className="h-2.5 w-2.5 ml-0.5" />
                پیامک
              </Badge>
            )}
          </div>
          <div className="text-xs text-muted-foreground mt-0.5">
            {toPersianDigits(reminder.day)} {reminder.calendar === 'jalali' ? JALALI_MONTHS[reminder.month - 1] : GREGORIAN_MONTHS[reminder.month - 1]}
            {reminder.calendar === 'gregorian' && ' (میلادی)'}
            {reminder.annual && ' • هر سال'}
            {ageInfo}
            {' • '}
            ساعت {toPersianDigits(String(hour).padStart(2, '0'))}:۰۰
          </div>
          {isToday && (
            <div className="text-xs text-rose-600 font-medium mt-0.5">امروز!</div>
          )}
          {!isToday && isSoon && (
            <div className="text-xs text-amber-600 font-medium mt-0.5">{toPersianDigits(days)} روز دیگر</div>
          )}
        </div>
      </button>

      {expanded && !selectionMode && (
        <div className="px-3 pb-3 pt-0 space-y-2 border-t border-border/50 mt-0 animate-in fade-in duration-200">
          {reminder.description && (
            <p className="text-xs text-muted-foreground pt-2">{reminder.description}</p>
          )}
          <div className="flex flex-wrap gap-2 pt-2">
            <Button
              variant="outline"
              size="sm"
              className="rounded-xl gap-1.5 flex-1"
              onClick={(e) => {
                e.stopPropagation();
                onEdit();
              }}
            >
              <Pencil className="h-3.5 w-3.5" />
              ویرایش
            </Button>
            {reminder.smsEnabled && reminder.smsPhone && onSendSms && (
              <Button
                variant="outline"
                size="sm"
                className="rounded-xl gap-1.5 flex-1 border-emerald-200 text-emerald-700 hover:bg-emerald-50"
                onClick={(e) => {
                  e.stopPropagation();
                  onSendSms(reminder);
                }}
              >
                <MessageSquare className="h-3.5 w-3.5" />
                ارسال پیامک
              </Button>
            )}
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="w-full rounded-xl text-destructive hover:text-destructive hover:bg-rose-50 gap-1.5"
            onClick={(e) => {
              e.stopPropagation();
              onDelete();
            }}
          >
            <Trash2 className="h-3.5 w-3.5" />
            حذف یادآور
          </Button>
        </div>
      )}
    </div>
  );
}

interface ReminderDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editingReminder: Reminder | null;
  onSave: (data: Omit<Reminder, 'id' | 'createdAt'>) => void;
}

function ReminderDialog({ open, onOpenChange, editingReminder, onSave }: ReminderDialogProps) {
  const today = todayJalali();
  const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);

  const [title, setTitle] = useState(editingReminder?.title || '');
  const [description, setDescription] = useState(editingReminder?.description || '');
  const [type, setType] = useState<ReminderType>(editingReminder?.type || 'birthday');
  const [calendar, setCalendar] = useState<'jalali' | 'gregorian'>(editingReminder?.calendar || 'jalali');
  const [year, setYear] = useState<string>(editingReminder?.year ? String(editingReminder.year) : '');
  const [month, setMonth] = useState<string>(String(editingReminder?.month || 1));
  const [day, setDay] = useState<string>(String(editingReminder?.day || 1));
  const [annual, setAnnual] = useState(editingReminder?.annual ?? true);
  const [notifyDaysBefore, setNotifyDaysBefore] = useState<string>(
    String(editingReminder?.notifyDaysBefore ?? 0)
  );
  const [notifyHour, setNotifyHour] = useState<string>(
    String(editingReminder?.notifyHour ?? 9)
  );
  // SMS fields (for birthdays)
  const [smsEnabled, setSmsEnabled] = useState(editingReminder?.smsEnabled ?? false);
  const [smsPhone, setSmsPhone] = useState(editingReminder?.smsPhone || '');
  const [smsText, setSmsText] = useState(editingReminder?.smsText || 'تولدت مبارک {name}! {age} سالت شد.');
  const [smsHour, setSmsHour] = useState<string>(String(editingReminder?.smsHour ?? 9));

  const maxDay = useMemo(() => {
    const m = parseInt(month, 10);
    if (calendar === 'jalali') {
      if (m <= 6) return 31;
      if (m <= 11) return 30;
      const y = year ? parseInt(year, 10) : today.jy;
      return isJalaliLeap(y) ? 30 : 29;
    } else {
      const y = year ? parseInt(year, 10) : todayG.gy;
      return new Date(y, m, 0).getDate();
    }
  }, [calendar, month, year, today.jy, todayG.gy]);

  const dayNum = parseInt(day, 10);
  const safeDay = isNaN(dayNum) || dayNum < 1 ? 1 : Math.min(dayNum, maxDay);

  const handleDayChange = (val: string) => {
    // Allow empty while typing so user can clear and retype (e.g. 18 → clear → 8)
    const cleaned = val.replace(/[^\d]/g, '').slice(0, 2);
    setDay(cleaned);
  };

  const handleDayBlur = () => {
    setDay(String(safeDay));
  };

  const handleYearChange = (val: string) => {
    const cleaned = val.replace(/[^\d]/g, '').slice(0, 4);
    setYear(cleaned);
  };

  const handleSave = () => {
    if (!title.trim()) return;
    onSave({
      title: title.trim(),
      description: description.trim() || undefined,
      type,
      calendar,
      year: year ? parseInt(year, 10) : undefined,
      month: parseInt(month, 10),
      day: safeDay,
      annual,
      notifyDaysBefore: parseInt(notifyDaysBefore, 10) || 0,
      notifyHour: Math.min(23, Math.max(0, parseInt(notifyHour, 10) || 9)),
      // SMS fields only for birthdays
      smsEnabled: type === 'birthday' ? smsEnabled : false,
      smsPhone: type === 'birthday' && smsEnabled ? smsPhone.trim() : undefined,
      smsText: type === 'birthday' && smsEnabled ? smsText.trim() : undefined,
      smsHour: type === 'birthday' && smsEnabled ? (parseInt(smsHour, 10) || 9) : undefined,
    });
  };

  const monthsList = calendar === 'jalali' ? JALALI_MONTHS : GREGORIAN_MONTHS;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md rounded-3xl" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-xl">
            {editingReminder ? 'ویرایش یادآور' : 'یادآور جدید'}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 max-h-[60vh] overflow-y-auto px-1">
          <div className="space-y-2">
            <Label htmlFor="title">عنوان</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="مثلاً: تولد علی"
              className="rounded-lg"
              autoFocus
            />
          </div>

          <div className="space-y-2">
            <Label>نوع یادآور</Label>
            <div className="grid grid-cols-5 gap-1.5">
              {(Object.keys(REMINDER_TYPE_LABELS) as ReminderType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`px-2 py-2 rounded-xl text-[11px] font-medium transition-all ${
                    type === t
                      ? REMINDER_TYPE_COLORS[t] + ' border'
                      : 'bg-muted/40 text-muted-foreground hover:bg-muted'
                  }`}
                >
                  {REMINDER_TYPE_LABELS[t]}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>نوع تقویم</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setCalendar('jalali')}
                className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                  calendar === 'jalali'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted/40 text-muted-foreground hover:bg-muted'
                }`}
              >
                شمسی
              </button>
              <button
                type="button"
                onClick={() => setCalendar('gregorian')}
                className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                  calendar === 'gregorian'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted/40 text-muted-foreground hover:bg-muted'
                }`}
              >
                میلادی
              </button>
            </div>
          </div>

          {type === 'birthday' && (
            <div className="space-y-2">
              <Label htmlFor="year">سال تولد (اختیاری - برای محاسبه سن)</Label>
              <Input
                id="year"
                value={year}
                onChange={(e) => handleYearChange(e.target.value)}
                placeholder={calendar === 'jalali' ? 'مثلاً ۱۳۷۰' : 'e.g. 1990'}
                className="rounded-lg"
                dir="ltr"
                inputMode="numeric"
              />
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>ماه</Label>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {monthsList.map((name, i) => (
                  <option key={i} value={i + 1}>{name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="day">روز (۱ تا {toPersianDigits(maxDay)})</Label>
              <Input
                id="day"
                value={day}
                onChange={(e) => handleDayChange(e.target.value)}
                onBlur={handleDayBlur}
                className="rounded-lg text-center"
                dir="ltr"
                inputMode="numeric"
                placeholder="۱"
                maxLength={2}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="notifyDaysBefore">چند روز قبل؟</Label>
              <Input
                id="notifyDaysBefore"
                value={notifyDaysBefore}
                onChange={(e) => setNotifyDaysBefore(e.target.value.replace(/[^\d]/g, ''))}
                type="number"
                min={0}
                max={30}
                className="rounded-lg"
                dir="ltr"
              />
              <p className="text-[10px] text-muted-foreground">۰ = همان روز</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notifyHour">ساعت نوتیفیکیشن</Label>
              <select
                id="notifyHour"
                value={notifyHour}
                onChange={(e) => setNotifyHour(e.target.value)}
                className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-ring"
                dir="ltr"
              >
                {Array.from({ length: 24 }, (_, h) => (
                  <option key={h} value={h}>
                    {String(h).padStart(2, '0')}:00
                  </option>
                ))}
              </select>
              <p className="text-[10px] text-muted-foreground">ساعت دلخواه شما</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">توضیحات (اختیاری)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="یادداشت یا توضیحات..."
              className="rounded-lg resize-none"
              rows={2}
            />
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={annual}
              onChange={(e) => setAnnual(e.target.checked)}
              className="h-4 w-4 rounded accent-primary"
            />
            <span className="text-sm">هر سال تکرار شود</span>
          </label>

          {/* SMS section - only for birthdays */}
          {type === 'birthday' && (
            <div className="space-y-3 p-3 rounded-lg bg-emerald-50/50 border border-emerald-200">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={smsEnabled}
                  onChange={(e) => setSmsEnabled(e.target.checked)}
                  className="h-4 w-4 rounded accent-emerald-600"
                />
                <span className="text-sm font-medium flex items-center gap-1.5">
                  <MessageSquare className="h-3.5 w-3.5 text-emerald-600" />
                  ارسال پیامک خودکار در روز تولد
                </span>
              </label>

              {smsEnabled && (
                <div className="space-y-3">
                  <div className="space-y-2">
                    <Label htmlFor="smsPhone" className="text-xs">شماره موبایل گیرنده</Label>
                    <Input
                      id="smsPhone"
                      value={smsPhone}
                      onChange={(e) => setSmsPhone(e.target.value)}
                      placeholder="09121234567"
                      className="rounded-lg"
                      dir="ltr"
                      inputMode="tel"
                    />
                    <p className="text-[11px] text-muted-foreground">با کد ایران وارد کنید (مثال: 09121234567)</p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smsText" className="text-xs">متن پیامک</Label>
                    <Textarea
                      id="smsText"
                      value={smsText}
                      onChange={(e) => setSmsText(e.target.value)}
                      className="rounded-lg resize-none"
                      rows={2}
                    />
                    <p className="text-[11px] text-muted-foreground">
                      متغیرها: <code dir="ltr" className="bg-muted px-1 rounded">{'{name}'}</code> = نام یادآور، <code dir="ltr" className="bg-muted px-1 rounded">{'{age}'}</code> = سن جدید
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="smsHour" className="text-xs">ساعت ارسال</Label>
                    <Input
                      id="smsHour"
                      value={smsHour}
                      onChange={(e) => setSmsHour(e.target.value.replace(/[^\d]/g, '').slice(0, 2))}
                      type="number"
                      min={0}
                      max={23}
                      className="rounded-lg"
                      dir="ltr"
                    />
                    <p className="text-[11px] text-muted-foreground">بین ۰ تا ۲۳ (پیش‌فرض: ۹ صبح)</p>
                  </div>
                  <div className="text-[11px] text-amber-700 bg-amber-50 rounded p-2">
                    ⚠️ نکته: در حالت آفلاین، اپ در ساعت مشخص یک لینک <code dir="ltr">sms:</code> باز می‌کند و شما باید روی «ارسال» بزنید. ارسال کاملاً خودکار نیاز به سرویس آنلاین پیامک دارد.
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-2xl">
            انصراف
          </Button>
          <Button onClick={handleSave} disabled={!title.trim()} className="rounded-2xl">
            {editingReminder ? 'ذخیره' : 'افزودن'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
