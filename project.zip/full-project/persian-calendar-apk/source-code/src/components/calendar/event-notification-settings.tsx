'use client';

import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import { CalendarClock } from 'lucide-react';
import type { useSettings } from '@/hooks/use-settings';
import type { useNotifications } from '@/hooks/use-notifications';
import { CATEGORY_STYLES, HOLIDAY_STYLE } from '@/lib/events';
import type { EventNotifyPrefs } from '@/lib/event-notify-prefs';
import { toPersianDigits } from '@/lib/jalali';

interface Props {
  settingsHook: ReturnType<typeof useSettings>;
  notificationsHook: ReturnType<typeof useNotifications>;
}

const ROWS: {
  key: 'holidays' | 'shamsi' | 'qamari' | 'global';
  label: string;
  hint: string;
  dot: string;
  switchOn: string;
}[] = [
  {
    key: 'holidays',
    label: HOLIDAY_STYLE.label,
    hint: 'مثلا «فردا تعطیل رسمی است»',
    dot: HOLIDAY_STYLE.dot,
    switchOn: 'data-[state=checked]:bg-rose-500',
  },
  {
    key: 'shamsi',
    label: 'مناسبت های شمسی',
    hint: 'روزهای ملی و تاریخی',
    dot: CATEGORY_STYLES.shamsi.dot,
    switchOn: CATEGORY_STYLES.shamsi.switchOn,
  },
  {
    key: 'qamari',
    label: 'مناسبت های قمری',
    hint: 'مثلا «فردا شب قدر است»',
    dot: CATEGORY_STYLES.qamari.dot,
    switchOn: CATEGORY_STYLES.qamari.switchOn,
  },
  {
    key: 'global',
    label: 'مناسبت های جهانی',
    hint: 'روزهای جهانی',
    dot: CATEGORY_STYLES.global.dot,
    switchOn: CATEGORY_STYLES.global.switchOn,
  },
];

export function EventNotificationSettings({ settingsHook, notificationsHook }: Props) {
  const { settings, updateSettings } = settingsHook;
  const prefs = settings.eventNotify;
  const active = notificationsHook.enabled && notificationsHook.permission === 'granted';
  const isNative = notificationsHook.channel === 'capacitor';

  const update = (patch: Partial<EventNotifyPrefs>) => updateSettings({ eventNotify: { ...prefs, ...patch } });

  return (
    <Card className="glass-card p-4 border-0 rounded-3xl">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <CalendarClock className="h-5 w-5 text-primary" />
        </div>
        <div className="flex-1">
          <div className="font-semibold text-sm">نوتیف مناسبت ها</div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {active
              ? isNative
                ? 'مناسبت های ۴۵ روز آینده زمان بندی می شوند (با هر بار باز کردن برنامه تمدید می شود)'
                : 'نوتیف مناسبت ها فقط داخل اپلیکیشن اندروید کار می کند'
              : 'اول نوتیفیکیشن را در بالا فعال کنید'}
          </p>
        </div>
      </div>

      <div className={`space-y-1 ${active ? '' : 'opacity-50 pointer-events-none'}`}>
        {ROWS.map((row) => (
          <div key={row.key} className="flex items-center gap-3 py-2">
            <span className={`h-2.5 w-2.5 rounded-full ${row.dot}`} />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium">{row.label}</div>
              <div className="text-[11px] text-muted-foreground">{row.hint}</div>
            </div>
            <Switch
              className={row.switchOn}
              checked={prefs[row.key]}
              onCheckedChange={(v) => update({ [row.key]: v } as Partial<EventNotifyPrefs>)}
            />
          </div>
        ))}

        <div className="pt-3 mt-2 border-t border-border/40 space-y-3">
          <div>
            <div className="text-xs font-medium mb-1.5">زمان اعلام</div>
            <div className="grid grid-cols-2 gap-2">
              {[
                { v: 1, label: 'یک روز قبل' },
                { v: 0, label: 'همان روز' },
              ].map((o) => (
                <button
                  key={o.v}
                  type="button"
                  onClick={() => update({ daysBefore: o.v })}
                  className={`rounded-xl border px-3 py-2 text-xs font-medium transition-colors ${
                    prefs.daysBefore === o.v
                      ? 'bg-primary text-primary-foreground border-primary'
                      : 'bg-background/60 hover:bg-accent/50'
                  }`}
                >
                  {o.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <label htmlFor="eventNotifyTime" className="text-xs font-medium flex-1">
              ساعت اعلام ({toPersianDigits(prefs.time)})
            </label>
            <Input
              id="eventNotifyTime"
              type="time"
              step={60}
              dir="ltr"
              value={prefs.time}
              onChange={(e) => e.target.value && update({ time: e.target.value })}
              className="rounded-lg w-32 text-center"
            />
          </div>
          <p className="text-[11px] text-muted-foreground leading-relaxed">
            اگر چند مناسبت در یک روز باشد، همه در یک نوتیف می آیند. کانال «مناسبت های تقویم» را می توانید از تنظیمات اندروید جدا خاموش کنید.
          </p>
        </div>
      </div>
    </Card>
  );
}
