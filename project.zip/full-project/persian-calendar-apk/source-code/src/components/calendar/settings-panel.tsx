'use client';

import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Calendar, Globe, Moon, Info } from 'lucide-react';
import { useSettings } from '@/hooks/use-settings';
import { CATEGORY_STYLES, getEventCounts, getDataYears, getDataFetchedAt } from '@/lib/events';
import { updateEventsFromInternet, getUpdateState } from '@/lib/events-remote';
import { useEventsVersion } from '@/hooks/use-events-version';
import { RefreshCw } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { toPersianDigits } from '@/lib/jalali';

interface SettingsPanelProps {
  settingsHook: ReturnType<typeof useSettings>;
}

export function SettingsPanel({ settingsHook }: SettingsPanelProps) {
  const { settings, updateSettings } = settingsHook;
  useEventsVersion(); // re-render after an update
  const [updating, setUpdating] = useState(false);
  const [updateMsg, setUpdateMsg] = useState<string | null>(null);
  const counts = getEventCounts();
  const years = getDataYears();
  const fetchedAt = getDataFetchedAt();

  const categoryConfig: {
    key: 'showShamsiEvents' | 'showQamariEvents' | 'showGlobalEvents';
    category: 'shamsi' | 'qamari' | 'global';
    icon: React.ReactNode;
    count: number;
  }[] = [
    {
      key: 'showShamsiEvents',
      category: 'shamsi',
      icon: <Calendar className="h-4 w-4" />,
      count: counts.shamsi,
    },
    {
      key: 'showQamariEvents',
      category: 'qamari',
      icon: <Moon className="h-4 w-4" />,
      count: counts.qamari,
    },
    {
      key: 'showGlobalEvents',
      category: 'global',
      icon: <Globe className="h-4 w-4" />,
      count: counts.global,
    },
  ];

  return (
    <div className="space-y-4">
      <Card className="glass-card p-6 border-0 rounded-3xl">
        <div className="flex items-center gap-3 mb-5">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">مناسبت ها</h3>
            <p className="text-sm text-muted-foreground">انتخاب دسته های مناسبت قابل نمایش</p>
          </div>
        </div>

        <div className="space-y-3">
          {categoryConfig.map(({ key, category, icon, count }) => (
            <div
              key={key}
              className="flex items-center gap-3 p-3 rounded-lg bg-background/60 border"
            >
              <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${CATEGORY_STYLES[category].iconBox}`}>
                {icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{CATEGORY_STYLES[category].label}</div>
                <div className="text-xs text-muted-foreground">
                  {toPersianDigits(count)} مناسبت
                </div>
              </div>
              <Switch
                className={CATEGORY_STYLES[category].switchOn}
                checked={settings[key]}
                onCheckedChange={(checked) => updateSettings({ [key]: checked } as Partial<typeof settings>)}
              />
            </div>
          ))}
        </div>

        <div className="mt-4 pt-3 border-t border-border/40">
          <Button
            variant="outline"
            size="sm"
            disabled={updating}
            className="rounded-xl gap-1.5 w-full"
            onClick={async () => {
              setUpdating(true);
              setUpdateMsg(null);
              try {
                const r = await updateEventsFromInternet(true);
                setUpdateMsg(r.message);
              } catch {
                setUpdateMsg('به روزرسانی انجام نشد.');
              } finally {
                setUpdating(false);
              }
            }}
          >
            <RefreshCw className={`h-3.5 w-3.5 ${updating ? 'animate-spin' : ''}`} />
            {updating ? 'در حال دریافت ...' : 'به روزرسانی مناسبت ها از اینترنت'}
          </Button>
          {(updateMsg || getUpdateState()?.lastMessage) && (
            <p className="text-[11px] text-muted-foreground mt-2 leading-relaxed">
              {updateMsg ?? getUpdateState()?.lastMessage}
            </p>
          )}
        </div>

        <p className="text-[11px] text-muted-foreground mt-4 leading-relaxed">
          منبع مناسبت ها: Time.ir
          {years.length > 0 && ` (سال ${years.map((y) => toPersianDigits(y)).join('، ')})`}
          {fetchedAt && ` • دریافت شده در ${fetchedAt}`}
          . تاریخ مناسبت های قمری برای سال های دارای داده دقیق است و برای بقیه سال ها تقریبی نمایش داده می شود.
        </p>
      </Card>

      {/* About */}
      <Card className="glass-card p-6 border-0 rounded-3xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center">
            <Info className="h-5 w-5 text-amber-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold">درباره اپ</h3>
          </div>
        </div>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>تقویم شمسی و میلادی — نسخه ۱.۰</p>
          <p>تمام داده ها به صورت محلی در مرورگر شما ذخیره می شوند و به سروری ارسال نمی شوند.</p>
          <p>اپ کاملاً آفلاین و برای استفاده شخصی طراحی شده است.</p>
        </div>
      </Card>
    </div>
  );
}
