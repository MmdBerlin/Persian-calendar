'use client';

import { Card } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Calendar, Globe, Moon, Info } from 'lucide-react';
import { useSettings } from '@/hooks/use-settings';
import { CATEGORY_LABELS, SHAMSI_EVENTS, QAMARI_EVENTS, GLOBAL_EVENTS } from '@/lib/events';
import { toPersianDigits } from '@/lib/jalali';

interface SettingsPanelProps {
  settingsHook: ReturnType<typeof useSettings>;
}

export function SettingsPanel({ settingsHook }: SettingsPanelProps) {
  const { settings, updateSettings } = settingsHook;

  const categoryConfig: {
    key: 'showShamsiEvents' | 'showQamariEvents' | 'showGlobalEvents';
    category: 'shamsi' | 'qamari' | 'global';
    icon: React.ReactNode;
    color: string;
    count: number;
  }[] = [
    {
      key: 'showShamsiEvents',
      category: 'shamsi',
      icon: <Calendar className="h-4 w-4" />,
      color: 'bg-red-100 text-red-600',
      count: SHAMSI_EVENTS.length,
    },
    {
      key: 'showQamariEvents',
      category: 'qamari',
      icon: <Moon className="h-4 w-4" />,
      color: 'bg-teal-100 text-teal-600',
      count: QAMARI_EVENTS.length,
    },
    {
      key: 'showGlobalEvents',
      category: 'global',
      icon: <Globe className="h-4 w-4" />,
      color: 'bg-emerald-100 text-emerald-600',
      count: GLOBAL_EVENTS.length,
    },
  ];

  return (
    <div className="space-y-4">
      <Card className="glass-card p-6 border-0 rounded-3xl">
        <div className="flex items-center gap-3 mb-5">
          <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
            <Calendar className="h-5 w-5 text-primary" />
          </div>
          <div>
            <h3 className="text-xl font-bold">مناسبت‌ها</h3>
            <p className="text-sm text-muted-foreground">انتخاب دسته‌های مناسبت قابل نمایش</p>
          </div>
        </div>

        <div className="space-y-3">
          {categoryConfig.map(({ key, category, icon, color, count }) => (
            <div
              key={key}
              className="flex items-center gap-3 p-3 rounded-lg bg-background/60 border"
            >
              <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${color}`}>
                {icon}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-medium text-sm">{CATEGORY_LABELS[category]}</div>
                <div className="text-xs text-muted-foreground">
                  {toPersianDigits(count)} مناسبت
                </div>
              </div>
              <Switch
                checked={settings[key]}
                onCheckedChange={(checked) => updateSettings({ [key]: checked } as Partial<typeof settings>)}
              />
            </div>
          ))}
        </div>
      </Card>

      {/* About */}
      <Card className="glass-card p-6 border-0 rounded-3xl">
        <div className="flex items-center gap-3 mb-4">
          <div className="h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center">
            <Info className="h-5 w-5 text-amber-600" />
          </div>
          <div>
            <h3 className="text-xl font-bold">درباره اپ</h3>
          </div>
        </div>
        <div className="space-y-2 text-sm text-muted-foreground">
          <p>تقویم شمسی و میلادی — نسخه ۱.۰</p>
          <p>تمام داده‌ها به‌صورت محلی در مرورگر شما ذخیره می‌شوند و به سروری ارسال نمی‌شوند.</p>
          <p>اپ کاملاً آفلاین و برای استفاده شخصی طراحی شده است.</p>
        </div>
      </Card>
    </div>
  );
}
