'use client';

import { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { CalendarDays } from 'lucide-react';
import {
  JALALI_MONTHS,
  GREGORIAN_MONTHS,
  WEEKDAYS_FA,
  toPersianDigits,
  todayJalali,
  jalaliToGregorian,
  jalaliWeekday,
  isJalaliLeap,
  type JalaliDate,
} from '@/lib/jalali';
import type { Reminder, ReminderType } from '@/hooks/use-reminders';
import { REMINDER_TYPE_LABELS, REMINDER_TYPE_COLORS, REMINDER_TYPE_HINTS } from '@/lib/reminder-types';
import { buildReminderMessage, formatNotifyTime } from '@/lib/notification-text';

/** "HH:MM" from <input type="time"> -> hour/minute (falls back to 09:00). */
function parseTimeInput(value: string): { hour: number; minute: number } {
  const m = /^(\d{1,2}):(\d{2})/.exec(value || '');
  if (!m) return { hour: 9, minute: 0 };
  return {
    hour: Math.min(23, Math.max(0, parseInt(m[1], 10))),
    minute: Math.min(59, Math.max(0, parseInt(m[2], 10))),
  };
}

export interface ReminderDialogProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  editingReminder: Reminder | null;
  onSave: (data: Omit<Reminder, 'id' | 'createdAt'>) => void;
  /** New reminder: start on this (Jalali) day, e.g. the day selected in the calendar. */
  defaultDate?: JalaliDate;
}

export function ReminderDialog({ open, onOpenChange, editingReminder, onSave, defaultDate }: ReminderDialogProps) {
  const today = todayJalali();
  const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);

  const [title, setTitle] = useState(editingReminder?.title || '');
  const [description, setDescription] = useState(editingReminder?.description || '');
  const [type, setType] = useState<ReminderType>(editingReminder?.type || 'birthday');
  const [calendar, setCalendar] = useState<'jalali' | 'gregorian'>(editingReminder?.calendar || 'jalali');
  const [year, setYear] = useState<string>(editingReminder?.year ? String(editingReminder.year) : '');
  const [month, setMonth] = useState<string>(String(editingReminder?.month ?? defaultDate?.jm ?? 1));
  const [day, setDay] = useState<string>(String(editingReminder?.day ?? defaultDate?.jd ?? 1));
  const [annual, setAnnual] = useState(editingReminder?.annual ?? true);
  const [notifyDaysBefore, setNotifyDaysBefore] = useState<string>(
    String(editingReminder?.notifyDaysBefore ?? 0)
  );
  // Notification time as "HH:MM" (hour and minute)
  const [notifyTime, setNotifyTime] = useState<string>(
    editingReminder ? formatNotifyTime(editingReminder) : '09:00'
  );

  const hints = REMINDER_TYPE_HINTS[type];

  // Live preview of the notification text for the chosen type
  const preview = useMemo(
    () =>
      buildReminderMessage(
        { title: title.trim() || hints.sampleTitle, type, description: description.trim() || undefined },
        parseInt(notifyDaysBefore, 10) > 0 ? parseInt(notifyDaysBefore, 10) : 0,
        year && (type === 'birthday' || type === 'anniversary') ? 30 : null
      ),
    [title, type, description, notifyDaysBefore, year, hints.sampleTitle]
  );

  const maxDay = useMemo(() => {
    const m = parseInt(month, 10);
    if (calendar === 'jalali') {
      if (m <= 6) return 31;
      if (m <= 11) return 30;
      const y = year ? parseInt(year, 10) : today.jy;
      return isJalaliLeap(y) ? 30 : 29;
    } else {
      const y = year ? parseInt(year, 10) : todayG.gy;
      return new Date(y, m, 0).getDate();
    }
  }, [calendar, month, year, today.jy, todayG.gy]);

  const dayNum = parseInt(day, 10);
  const safeDay = isNaN(dayNum) || dayNum < 1 ? 1 : Math.min(dayNum, maxDay);

  const handleDayChange = (val: string) => {
    // Allow empty while typing so user can clear and retype (e.g. 18 → clear → 8)
    const cleaned = val.replace(/[^\d]/g, '').slice(0, 2);
    setDay(cleaned);
  };

  const handleDayBlur = () => {
    setDay(String(safeDay));
  };

  const handleYearChange = (val: string) => {
    const cleaned = val.replace(/[^\d]/g, '').slice(0, 4);
    setYear(cleaned);
  };

  const handleSave = () => {
    if (!title.trim()) return;
    const parsedTime = parseTimeInput(notifyTime);
    onSave({
      title: title.trim(),
      description: description.trim() || undefined,
      type,
      calendar,
      year: year ? parseInt(year, 10) : undefined,
      month: parseInt(month, 10),
      day: safeDay,
      annual,
      notifyDaysBefore: parseInt(notifyDaysBefore, 10) || 0,
      notifyHour: parsedTime.hour,
      notifyMinute: parsedTime.minute,
    });
  };

  const monthsList = calendar === 'jalali' ? JALALI_MONTHS : GREGORIAN_MONTHS;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md rounded-3xl" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-xl">
            {editingReminder ? 'ویرایش یادآور' : 'یادآور جدید'}
          </DialogTitle>
        </DialogHeader>

        {defaultDate && !editingReminder && (
          <div className="flex items-center gap-2 rounded-xl bg-primary/5 px-3 py-2 text-xs text-primary">
            <CalendarDays className="h-4 w-4 shrink-0" />
            <span>
              برای روز {WEEKDAYS_FA[jalaliWeekday(defaultDate.jy, defaultDate.jm, defaultDate.jd)]}{' '}
              {toPersianDigits(defaultDate.jd)} {JALALI_MONTHS[defaultDate.jm - 1]} {toPersianDigits(defaultDate.jy)}
              <span className="text-muted-foreground"> (در صورت نیاز تغییر دهید)</span>
            </span>
          </div>
        )}

        <div className="space-y-4 max-h-[60vh] overflow-y-auto px-1">
          <div className="space-y-2">
            <Label htmlFor="title">{hints.titleLabel}</Label>
            <Input
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={hints.titlePlaceholder}
              className="rounded-lg"
              autoFocus
            />
            <p className="text-[11px] text-muted-foreground leading-relaxed">{hints.titleHelp}</p>
          </div>

          <div className="space-y-2">
            <Label>نوع یادآور</Label>
            <div className="grid grid-cols-5 gap-1.5">
              {(Object.keys(REMINDER_TYPE_LABELS) as ReminderType[]).map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setType(t)}
                  className={`px-2 py-2 rounded-xl text-[11px] font-medium transition-all ${
                    type === t
                      ? REMINDER_TYPE_COLORS[t] + ' border'
                      : 'bg-muted/40 text-muted-foreground hover:bg-muted'
                  }`}
                >
                  {REMINDER_TYPE_LABELS[t]}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>نوع تقویم</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setCalendar('jalali')}
                className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                  calendar === 'jalali'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted/40 text-muted-foreground hover:bg-muted'
                }`}
              >
                شمسی
              </button>
              <button
                type="button"
                onClick={() => setCalendar('gregorian')}
                className={`px-3 py-2 rounded-xl text-sm font-medium transition-all ${
                  calendar === 'gregorian'
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted/40 text-muted-foreground hover:bg-muted'
                }`}
              >
                میلادی
              </button>
            </div>
          </div>

          {hints.yearLabel && (
            <div className="space-y-2">
              <Label htmlFor="year">{hints.yearLabel}</Label>
              <Input
                id="year"
                value={year}
                onChange={(e) => handleYearChange(e.target.value)}
                placeholder={calendar === 'jalali' ? 'مثلاً ۱۳۷۰' : 'e.g. 1990'}
                className="rounded-lg"
                dir="ltr"
                inputMode="numeric"
              />
              <p className="text-[11px] text-muted-foreground">{hints.yearHelp}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>ماه</Label>
              <select
                value={month}
                onChange={(e) => setMonth(e.target.value)}
                className="flex h-10 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-ring"
              >
                {monthsList.map((name, i) => (
                  <option key={i} value={i + 1}>{name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="day">روز (۱ تا {toPersianDigits(maxDay)})</Label>
              <Input
                id="day"
                value={day}
                onChange={(e) => handleDayChange(e.target.value)}
                onBlur={handleDayBlur}
                className="rounded-lg text-center"
                dir="ltr"
                inputMode="numeric"
                placeholder="۱"
                maxLength={2}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label htmlFor="notifyDaysBefore">چند روز قبل؟</Label>
              <Input
                id="notifyDaysBefore"
                value={notifyDaysBefore}
                onChange={(e) => setNotifyDaysBefore(e.target.value.replace(/[^\d]/g, ''))}
                type="number"
                min={0}
                max={30}
                className="rounded-lg"
                dir="ltr"
              />
              <p className="text-[10px] text-muted-foreground">۰ = همان روز</p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="notifyTime">ساعت و دقیقه نوتیفیکیشن</Label>
              <Input
                id="notifyTime"
                type="time"
                step={60}
                value={notifyTime}
                onChange={(e) => setNotifyTime(e.target.value)}
                className="rounded-lg text-center"
                dir="ltr"
              />
              <p className="text-[10px] text-muted-foreground">مثلا ۰۹:۳۰</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">توضیحات (اختیاری)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={hints.descriptionPlaceholder}
              className="rounded-lg resize-none"
              rows={2}
            />
          </div>

          <div className="rounded-xl border border-dashed bg-muted/30 p-3">
            <p className="text-[10px] text-muted-foreground mb-1">نمونه نوتیفیکیشن</p>
            <p className="text-sm font-semibold">{preview.title}</p>
            <p className="text-xs text-muted-foreground whitespace-pre-line mt-0.5">{preview.body}</p>
          </div>

          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={annual}
              onChange={(e) => setAnnual(e.target.checked)}
              className="h-4 w-4 rounded accent-primary"
            />
            <span className="text-sm">هر سال تکرار شود</span>
          </label>
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-2xl">
            انصراف
          </Button>
          <Button onClick={handleSave} disabled={!title.trim()} className="rounded-2xl">
            {editingReminder ? 'ذخیره' : 'افزودن'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
