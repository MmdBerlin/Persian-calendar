'use client';

import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Bell, BellOff, CheckCircle2, XCircle, AlertCircle, BellRing, Send, Smartphone } from 'lucide-react';
import { useNotifications } from '@/hooks/use-notifications';

interface NotificationSettingsProps {
  notificationsHook: ReturnType<typeof useNotifications>;
}

export function NotificationSettings({ notificationsHook }: NotificationSettingsProps) {
  const {
    permission,
    enabled,
    channel,
    requestPermission,
    disable,
    sendTestNotification,
  } = notificationsHook;

  // Running inside the Android APK (Capacitor)
  const isNative = channel === 'capacitor';

  // Truly unsupported: no Capacitor, no ServiceWorker, no Notification API
  if (permission === 'unsupported') {
    return (
      <Card className="glass-card p-4 border-0 rounded-3xl">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-amber-100 flex items-center justify-center">
            <AlertCircle className="h-5 w-5 text-amber-600" />
          </div>
          <div className="flex-1">
            <div className="font-semibold text-sm">نوتیفیکیشن پشتیبانی نمی شود</div>
            <p className="text-xs text-muted-foreground mt-0.5">
              این محیط از نوتیفیکیشن پشتیبانی نمی کند
            </p>
          </div>
        </div>
      </Card>
    );
  }

  // Permission denied
  if (permission === 'denied') {
    return (
      <Card className="glass-card p-4 border-0 rounded-3xl">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-rose-100 flex items-center justify-center">
            <XCircle className="h-5 w-5 text-rose-600" />
          </div>
          <div className="flex-1">
            <div className="font-semibold text-sm">نوتیفیکیشن مسدود شده</div>
            <p className="text-xs text-muted-foreground mt-0.5">
              {isNative
                ? 'برای فعال سازی، از تنظیمات گوشی (Settings > Apps > تقویم شمسی > Notifications) اجازه دهید'
                : 'برای فعال سازی، از تنظیمات مرورگر اجازه نوتیفیکیشن بدهید و سپس صفحه را رفرش کنید'}
            </p>
          </div>
        </div>
      </Card>
    );
  }

  // Default (not yet asked) — show enable button
  if (permission === 'default') {
    return (
      <Card className="glass-card p-4 border-0 rounded-3xl bg-gradient-to-br from-primary/5 to-primary/10">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-primary/15 flex items-center justify-center">
            <BellRing className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <div className="font-semibold text-sm flex items-center gap-1.5">
              یادآوری با نوتیفیکیشن
              {isNative && (
                <span className="flex items-center gap-0.5 text-[10px] text-primary/70 font-normal">
                  <Smartphone className="h-3 w-3" />
                  اپلیکیشن
                </span>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-0.5">
              برای تولدها و مناسبت ها، نوتیفیکیشن دریافت کنید
            </p>
          </div>
          <Button onClick={requestPermission} size="sm" className="rounded-xl">
            فعال کردن
          </Button>
        </div>
      </Card>
    );
  }

  // Granted — show toggle + test button
  return (
    <Card className="glass-card p-4 border-0 rounded-3xl">
      <div className="flex items-center gap-3">
        <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${
          enabled ? 'bg-emerald-100' : 'bg-muted'
        }`}>
          {enabled ? (
            <Bell className="h-5 w-5 text-emerald-600" />
          ) : (
            <BellOff className="h-5 w-5 text-muted-foreground" />
          )}
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-sm">نوتیفیکیشن</span>
            {enabled && (
              <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-medium">
                <CheckCircle2 className="h-3 w-3" />
                فعال
              </span>
            )}
            {isNative && enabled && (
              <span className="flex items-center gap-0.5 text-[10px] text-primary/70">
                <Smartphone className="h-3 w-3" />
                بومی
              </span>
            )}
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">
            {enabled
              ? isNative
                ? 'تولدها و یادآورها ساعت ۹ صبح اعلام می شوند، حتی وقتی برنامه بسته است'
                : 'برای تولدها و یادآورها نوتیف دریافت می کنید'
              : 'نوتیفیکیشن خاموش است'}
          </p>
        </div>
        <Switch
          checked={enabled}
          onCheckedChange={(checked) => {
            if (checked) {
              requestPermission();
            } else {
              disable();
            }
          }}
        />
      </div>
      {enabled && (
        <div className="mt-3 pt-3 border-t border-border/40 flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={sendTestNotification}
            className="rounded-xl text-xs h-8 gap-1.5"
          >
            <Send className="h-3.5 w-3.5" />
            ارسال نوتیف آزمایشی
          </Button>
          <span className="text-[11px] text-muted-foreground">
            اگر نوتیف دریافت نکردید، تنظیمات نوتیف گوشی را چک کنید
          </span>
        </div>
      )}
    </Card>
  );
}
