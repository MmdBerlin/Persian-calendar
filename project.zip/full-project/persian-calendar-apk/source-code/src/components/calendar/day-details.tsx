'use client';

import { useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Info } from 'lucide-react';
import {
  JALALI_MONTHS,
  GREGORIAN_MONTHS,
  WEEKDAYS_FA,
  jalaliWeekday,
  jalaliToGregorian,
  toPersianDigits,
  type JalaliDate,
} from '@/lib/jalali';
import { getEventsForJalaliDate, CATEGORY_STYLES, HOLIDAY_STYLE } from '@/lib/events';
import type { Reminder } from '@/hooks/use-reminders';
import type { AppSettings } from '@/hooks/use-settings';
import { REMINDER_TYPE_LABELS, REMINDER_TYPE_COLORS } from '@/lib/reminder-types';

interface DayDetailsProps {
  date: JalaliDate;
  reminders: Reminder[];
  settings: AppSettings;
}

export function DayDetails({ date, reminders, settings }: DayDetailsProps) {
  const weekday = jalaliWeekday(date.jy, date.jm, date.jd);
  const gregorian = jalaliToGregorian(date.jy, date.jm, date.jd);
  const gDate = new Date(gregorian.gy, gregorian.gm - 1, gregorian.gd);
  const gWeekday = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][gDate.getDay()];

  const events = useMemo(
    () => getEventsForJalaliDate(date.jy, date.jm, date.jd, settings),
    [date, settings]
  );

  const dayReminders = useMemo(() => {
    return reminders.filter((r) => {
      if (r.calendar === 'jalali') {
        return r.month === date.jm && r.day === date.jd;
      } else {
        return r.month === gregorian.gm && r.day === gregorian.gd;
      }
    });
  }, [reminders, date, gregorian]);

  return (
    <Card className="glass-card p-5 border-0 rounded-3xl">
      <div className="flex items-center gap-3 mb-4">
        <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Calendar className="h-5 w-5 text-primary" />
        </div>
        <div>
          <h3 className="text-base font-bold">جزئیات روز</h3>
          <p className="text-xs text-muted-foreground">اطلاعات و مناسبت های این روز</p>
        </div>
      </div>

      {/* Date display */}
      <div className="rounded-lg bg-gradient-to-br from-primary/5 to-primary/10 p-4 mb-4">
        <div className="text-xs text-muted-foreground mb-1">{WEEKDAYS_FA[weekday]}</div>
        <div className="text-2xl font-bold mb-1">
          {toPersianDigits(date.jd)} {JALALI_MONTHS[date.jm - 1]} {toPersianDigits(date.jy)}
        </div>
        <div className="text-sm text-muted-foreground" dir="ltr">
          {gWeekday}, {GREGORIAN_MONTHS[gregorian.gm - 1]} {gregorian.gd}, {gregorian.gy}
        </div>
      </div>

      {/* Events */}
      {events.length > 0 && (
        <div className="space-y-2 mb-4">
          <div className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
            <Info className="h-3 w-3" />
            مناسبت ها
          </div>
          {events.map((e) => {
            const style = CATEGORY_STYLES[e.category];
            return (
              <div key={e.id} className={`rounded-lg bg-background/60 border border-s-4 ${style.accent} p-3`}>
                <div className="flex items-start justify-between gap-2 mb-1">
                  <span className="font-semibold text-sm">{e.title}</span>
                  <Badge variant="outline" className={`text-[10px] px-2 py-0 whitespace-nowrap ${style.badge}`}>
                    {style.short}
                  </Badge>
                </div>
                {e.hijriLabel && (
                  <p className="text-xs text-muted-foreground mt-1">
                    {e.hijriLabel}
                    {e.approx && ' • تاریخ این سال تقریبی است'}
                  </p>
                )}
                {e.isHoliday && (
                  <div className="mt-1.5">
                    <Badge variant="outline" className={`text-[10px] px-2 py-0 ${HOLIDAY_STYLE.badge}`}>
                      {HOLIDAY_STYLE.label}
                    </Badge>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* User reminders */}
      {dayReminders.length > 0 && (
        <div className="space-y-2">
          <div className="text-xs font-semibold text-muted-foreground flex items-center gap-1.5">
            <Calendar className="h-3 w-3" />
            یادآورهای شما
          </div>
          {dayReminders.map((r) => (
            <div key={r.id} className="rounded-lg bg-background/60 border p-3">
              <div className="flex items-start justify-between gap-2">
                <span className="font-semibold text-sm">{r.title}</span>
                <Badge variant="outline" className={`text-[10px] px-2 py-0 whitespace-nowrap ${REMINDER_TYPE_COLORS[r.type]}`}>
                  {REMINDER_TYPE_LABELS[r.type]}
                </Badge>
              </div>
              {r.description && (
                <p className="text-xs text-muted-foreground mt-1">{r.description}</p>
              )}
            </div>
          ))}
        </div>
      )}

      {events.length === 0 && dayReminders.length === 0 && (
        <div className="text-center py-6 text-xs text-muted-foreground">
          مناسبت یا یادآوری برای این روز ثبت نشده
        </div>
      )}
    </Card>
  );
}
