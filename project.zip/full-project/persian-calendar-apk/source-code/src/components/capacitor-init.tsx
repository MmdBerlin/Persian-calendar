'use client';

import { useEffect } from 'react';
import { Capacitor } from '@capacitor/core';
import { StatusBar, Style } from '@capacitor/status-bar';

/**
 * CapacitorInit: runs once on the client.
 * Inside the Android APK it configures the StatusBar (solid white background,
 * dark icons, no overlay). On a regular browser it does nothing.
 */
export function CapacitorInit() {
  useEffect(() => {
    if (!Capacitor.isNativePlatform()) return;

    (async () => {
      try {
        // Style.Light = dark icons, for a light background
        await StatusBar.setStyle({ style: Style.Light });
        await StatusBar.setBackgroundColor({ color: '#FFFFFF' });
        await StatusBar.setOverlaysWebView({ overlay: false });
      } catch {
        // some calls are not supported on every Android version; never break the app
      }
    })();

    document.documentElement.style.setProperty('background-color', '#FFFFFF');
  }, []);

  return null;
}
