/**
 * Hijri (Islamic Lunar) Date Conversion
 * Algorithm based on Kuwaiti algorithm (fliegel-like).
 * Reference: https://en.wikipedia.org/wiki/Hijri_year
 *
 * Note: This is an arithmetic approximation and may differ from
 * actual astronomical Hijri dates by ±1 day. For Iranian religious
 * observances, the official calendar (شورای نگهبان) is the source of truth.
 */

export interface HijriDate {
  hy: number;
  hm: number; // 1-12
  hd: number; // 1-30
}

export const HIJRI_MONTHS = [
  'محرم',
  'صفر',
  'ربیع‌الاول',
  'ربیع‌الثانی',
  'جمادی‌الاولی',
  'جمادی‌الثانیه',
  'رجب',
  'شعبان',
  'رمضان',
  'شوال',
  'ذی‌القعده',
  'ذی‌الحجه',
];

/**
 * Convert Gregorian to Hijri (arithmetic approximation).
 */
export function gregorianToHijri(gy: number, gm: number, gd: number): HijriDate {
  let day = gd;
  let month = gm;
  let year = gy;

  if (gy < 1 || gy > 9999) {
    return { hy: 1, hm: 1, hd: 1 };
  }
  if (gm < 1 || gm > 12) {
    return { hy: 1, hm: 1, hd: 1 };
  }
  if (gd < 1 || gd > 31) {
    return { hy: 1, hm: 1, hd: 1 };
  }

  // Adjust for the Islamic epoch starting July 16, 622 CE (Julian)
  // Use the standard algorithm:
  // jd = (1461 * (y + 4800 + (m - 14) / 12)) / 4 + (367 * (m - 2 - 12 * ((m - 14) / 12))) / 12 - (3 * ((y + 4900 + (m - 14) / 12) / 100)) / 4 + d - 32075
  // then convert jd to hijri

  const a = Math.floor((14 - month) / 12);
  const y = year + 4800 - a;
  const m = month + 12 * a - 3;
  let jd = day + Math.floor((153 * m + 2) / 5) + 365 * y + Math.floor(y / 4) - Math.floor(y / 100) + Math.floor(y / 400) - 32045;

  // Convert JD to Hijri (Kuwaiti algorithm)
  jd = jd - 1948440 + 10632;
  const n = Math.floor((jd - 1) / 10631);
  jd = jd - 10631 * n + 354;
  const j = Math.floor((10985 - jd) / 5316) * Math.floor((50 * jd) / 17719) + Math.floor(jd / 5670) * Math.floor((43 * jd) / 15238);
  jd = jd - Math.floor((30 - j) / 15) * Math.floor((17719 * j) / 50) - Math.floor(j / 16) * Math.floor((15238 * j) / 43) + 29;

  const hm = Math.min(12, Math.max(1, Math.floor(jd)));
  const hy = Math.max(1, 30 * n + j - 30);
  const hd = Math.min(30, Math.max(1, Math.floor(jd - 29)));

  return { hy, hm, hd };
}

/**
 * Convert Jalali to Hijri (via Gregorian).
 */
export function jalaliToHijri(jy: number, jm: number, jd: number): HijriDate {
  // Use the existing jalaliToGregorian function
  // We import lazily to avoid circular deps
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { jalaliToGregorian } = require('./jalali');
  const g = jalaliToGregorian(jy, jm, jd);
  return gregorianToHijri(g.gy, g.gm, g.gd);
}

/**
 * Get today's Hijri date.
 */
export function todayHijri(): HijriDate {
  const now = new Date();
  return gregorianToHijri(now.getFullYear(), now.getMonth() + 1, now.getDate());
}
