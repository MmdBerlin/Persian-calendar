/**
 * مناسبت ها
 *
 * منبع داده: Time.ir (صفحه تقویم سالانه). فایل های src/data/events-<سال>.json را
 * اسکریپت scripts/update-events-from-timeir.mjs می سازد.
 *
 * - شمسی و جهانی: تاریخ ثابت دارند (روز و ماه شمسی / میلادی) و برای همه سال ها نمایش داده می شوند.
 * - قمری: تاریخ شمسی دقیق هر مناسبت قمری فقط برای سال هایی که داده Time.ir دارند معتبر است.
 *   برای سال های دیگر، تاریخ از روی تقویم قمری حدود محاسبه می شود و علامت «تقریبی» می گیرد
 *   (ممکن است یک روز اختلاف داشته باشد).
 */

import { EVENT_YEARS, type RawEvent, type YearData } from '@/data';
import { jalaliToGregorian } from '@/lib/jalali';
import { jalaliToHijri, HIJRI_MONTHS } from '@/lib/hijri';
import { toPersianDigits } from '@/lib/jalali';

export type EventCategory = 'shamsi' | 'qamari' | 'global';

export interface CalendarEvent {
  id: string;
  title: string;
  category: EventCategory;
  /** تعطیل رسمی */
  isHoliday: boolean;
  /** برای مناسبت های قمری، مثلا «۱ شوال» */
  hijriLabel?: string;
  /** تاریخ شمسی این مناسبت قمری تقریبی است (سال بدون داده Time.ir) */
  approx?: boolean;
}

export interface CategoryFilter {
  showShamsiEvents: boolean;
  showQamariEvents: boolean;
  showGlobalEvents: boolean;
}

// ---------------------------------------------------------------------------
// رنگ هر دسته. کلاس ها کامل نوشته شده اند تا Tailwind آن ها را پیدا کند.
// ---------------------------------------------------------------------------

export interface CategoryStyle {
  label: string;
  short: string;
  /** نقطه روی تقویم و راهنما */
  dot: string;
  /** برچسب (badge) */
  badge: string;
  /** جعبه آیکون */
  iconBox: string;
  /** نوار رنگی کنار کارت */
  accent: string;
  /** رنگ کلید روشن در تنظیمات */
  switchOn: string;
}

export const CATEGORY_STYLES: Record<EventCategory, CategoryStyle> = {
  shamsi: {
    label: 'شمسی (ایرانی)',
    short: 'شمسی',
    dot: 'bg-orange-500',
    badge: 'bg-orange-100 text-orange-700 border-orange-200',
    iconBox: 'bg-orange-100 text-orange-600',
    accent: 'border-s-orange-400',
    switchOn: 'data-[state=checked]:bg-orange-500',
  },
  qamari: {
    label: 'قمری (مذهبی)',
    short: 'قمری',
    dot: 'bg-emerald-500',
    badge: 'bg-emerald-100 text-emerald-700 border-emerald-200',
    iconBox: 'bg-emerald-100 text-emerald-600',
    accent: 'border-s-emerald-400',
    switchOn: 'data-[state=checked]:bg-emerald-500',
  },
  global: {
    label: 'جهانی (میلادی)',
    short: 'جهانی',
    dot: 'bg-fuchsia-500',
    badge: 'bg-fuchsia-100 text-fuchsia-700 border-fuchsia-200',
    iconBox: 'bg-fuchsia-100 text-fuchsia-600',
    accent: 'border-s-fuchsia-400',
    switchOn: 'data-[state=checked]:bg-fuchsia-500',
  },
};

export const HOLIDAY_STYLE = {
  label: 'تعطیل رسمی',
  dot: 'bg-rose-500',
  badge: 'bg-rose-100 text-rose-700 border-rose-200',
};

/** رنگ نقطه یادآورهای کاربر روی تقویم */
export const REMINDER_DOT_CLASS = 'bg-blue-500';

export const CATEGORY_LABELS: Record<EventCategory, string> = {
  shamsi: CATEGORY_STYLES.shamsi.label,
  qamari: CATEGORY_STYLES.qamari.label,
  global: CATEGORY_STYLES.global.label,
};

export const CATEGORY_ORDER: EventCategory[] = ['shamsi', 'qamari', 'global'];

// ---------------------------------------------------------------------------
// ساخت نمایه ها (یک بار، تنبل)
// ---------------------------------------------------------------------------

const k = (m: number, d: number) => m * 100 + d;

function pushTo<T>(map: Map<number, T[]>, key: number, item: T) {
  const arr = map.get(key);
  if (arr) arr.push(item);
  else map.set(key, [item]);
}

function toEvent(e: RawEvent, category: EventCategory, id: string): CalendarEvent {
  const ev: CalendarEvent = { id, title: e.t, category, isHoliday: e.h === 1 };
  if (category === 'qamari') ev.hijriLabel = `${toPersianDigits(e.hd)} ${HIJRI_MONTHS[e.hm - 1] ?? ''}`.trim();
  return ev;
}

interface Index {
  solar: Map<number, CalendarEvent[]>;
  global: Map<number, CalendarEvent[]>;
  /** سال شمسی -> (ماه*100+روز شمسی) -> مناسبت های قمری */
  lunarExact: Map<number, Map<number, CalendarEvent[]>>;
  /** (ماه*100+روز قمری) -> مناسبت قمری برای محاسبه تقریبی */
  lunarByHijri: Map<number, CalendarEvent[]>;
  counts: Record<EventCategory, number>;
}

let _index: Index | null = null;

function newestYear(): YearData | null {
  if (EVENT_YEARS.length === 0) return null;
  return EVENT_YEARS.reduce((a, b) => (b.year > a.year ? b : a));
}

function build(): Index {
  const idx: Index = {
    solar: new Map(),
    global: new Map(),
    lunarExact: new Map(),
    lunarByHijri: new Map(),
    counts: { shamsi: 0, qamari: 0, global: 0 },
  };
  const base = newestYear();
  if (!base) return idx;

  // شمسی و جهانی ثابت اند: از جدیدترین سال داده استفاده می کنیم
  base.events.forEach((e, i) => {
    if (e.b === 0) {
      pushTo(idx.solar, k(e.jm, e.jd), toEvent(e, 'shamsi', `s-${e.jm}-${e.jd}-${i}`));
      idx.counts.shamsi++;
    } else if (e.b === 1) {
      pushTo(idx.global, k(e.gm, e.gd), toEvent(e, 'global', `g-${e.gm}-${e.gd}-${i}`));
      idx.counts.global++;
    }
  });

  // قمری: دقیق برای هر سال داده، و الگوی تقریبی برای بقیه سال ها
  const templateSeen = new Set<string>();
  for (const yd of EVENT_YEARS) {
    const m = new Map<number, CalendarEvent[]>();
    yd.events.forEach((e, i) => {
      if (e.b !== 2) return;
      pushTo(m, k(e.jm, e.jd), toEvent(e, 'qamari', `q-${yd.year}-${e.jm}-${e.jd}-${i}`));
    });
    idx.lunarExact.set(yd.year, m);
  }
  base.events.forEach((e, i) => {
    if (e.b !== 2) return;
    idx.counts.qamari++;
    const tk = `${e.hm}-${e.hd}-${e.t}`;
    if (templateSeen.has(tk)) return;
    templateSeen.add(tk);
    const ev = toEvent(e, 'qamari', `qa-${e.hm}-${e.hd}-${i}`);
    ev.approx = true;
    pushTo(idx.lunarByHijri, k(e.hm, e.hd), ev);
  });
  return idx;
}

function index(): Index {
  if (!_index) _index = build();
  return _index;
}

// ---------------------------------------------------------------------------
// API
// ---------------------------------------------------------------------------

const CATEGORY_RANK: Record<EventCategory, number> = { shamsi: 0, qamari: 1, global: 2 };

/** مناسبت های یک روز شمسی، بر اساس دسته های فعال. تعطیل ها اول می آیند. */
export function getEventsForJalaliDate(
  jy: number,
  jm: number,
  jd: number,
  filter: CategoryFilter
): CalendarEvent[] {
  const idx = index();
  const out: CalendarEvent[] = [];

  if (filter.showShamsiEvents) {
    const a = idx.solar.get(k(jm, jd));
    if (a) out.push(...a);
  }

  if (filter.showQamariEvents) {
    const exact = idx.lunarExact.get(jy);
    if (exact) {
      const a = exact.get(k(jm, jd));
      if (a) out.push(...a);
    } else if (idx.lunarByHijri.size > 0) {
      const h = jalaliToHijri(jy, jm, jd);
      const a = idx.lunarByHijri.get(k(h.hm, h.hd));
      if (a) out.push(...a);
    }
  }

  if (filter.showGlobalEvents) {
    const g = jalaliToGregorian(jy, jm, jd);
    const a = idx.global.get(k(g.gm, g.gd));
    if (a) out.push(...a);
  }

  return out.sort(
    (x, y) =>
      Number(y.isHoliday) - Number(x.isHoliday) || CATEGORY_RANK[x.category] - CATEGORY_RANK[y.category]
  );
}

/** تعداد مناسبت های هر دسته (برای صفحه تنظیمات) */
export function getEventCounts(): Record<EventCategory, number> {
  return index().counts;
}

/** سال هایی که داده دقیق Time.ir دارند */
export function getDataYears(): number[] {
  return EVENT_YEARS.map((y) => y.year).sort((a, b) => a - b);
}

export function getDataFetchedAt(): string | null {
  return newestYear()?.fetchedAt ?? null;
}

/** آیا برای این سال، تاریخ مناسبت های قمری دقیق (از Time.ir) داریم؟ */
export function hasExactLunarYear(jy: number): boolean {
  return index().lunarExact.has(jy);
}
