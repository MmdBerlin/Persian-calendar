/**
 * Iranian, Lunar (Qamari), and Global Events Dataset
 * - Solar (Shamsi) events: fixed by Jalali month/day
 * - Gregorian events: fixed by Gregorian month/day
 * - Lunar (Qamari) events: fixed by Hijri month/day (approximate, common Iranian observances)
 *   Note: Lunar dates shift ~11 days earlier each solar year. The dates here are the
 *   commonly-listed Iranian observances for the current year and are updated manually.
 */

export type EventType = 'national' | 'international' | 'historical' | 'cultural' | 'holiday' | 'religious';
export type EventCategory = 'shamsi' | 'qamari' | 'global';

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  type: EventType;
  category: EventCategory;
  calendar: 'jalali' | 'gregorian' | 'hijri';
  month: number; // 1-12
  day: number; // 1-31
  isHoliday?: boolean; // official holiday
}

// ===== Shamsi (Jalali) Events =====
export const SHAMSI_EVENTS: CalendarEvent[] = [
  // ——— فروردین (from time.ir) ———
  { id: 'j-1-1', title: 'جشن نوروز / سال نو', description: 'جشن نوروز و آغاز سال شمسی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 1, isHoliday: true },
  { id: 'j-1-2', title: 'عید نوروز', description: 'دومین روز جشن نوروز', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 2, isHoliday: true },
  { id: 'j-1-3', title: 'عید نوروز', description: 'سومین روز جشن نوروز', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 3, isHoliday: true },
  { id: 'j-1-4', title: 'عید نوروز', description: 'چهارمین روز جشن نوروز', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 4, isHoliday: true },
  { id: 'j-1-6', title: 'روز امید؛ زادروز زرتشت', description: 'روز امید، روز شادباش‌نویسی؛ زادروز اَشو زرتشت', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 1, day: 6 },
  { id: 'j-1-10', title: 'جشن آبانگاه', description: 'جشن آبانگاه', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 1, day: 10 },
  { id: 'j-1-12', title: 'روز جمهوری اسلامی', description: 'روز جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 12, isHoliday: true },
  { id: 'j-1-13', title: 'سیزده‌بدر', description: 'جشن سیزده به در / روز طبیعت', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 13, isHoliday: true },
  { id: 'j-1-17', title: 'جشن سروشگان', description: 'سروش روز، جشن سروشگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 1, day: 17 },
  { id: 'j-1-19', title: 'جشن فروردینگان', description: 'فروردین روز، جشن فروردینگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 1, day: 19 },
  { id: 'j-1-23', title: 'روز دندانپزشک', description: 'روز دندانپزشک', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 23 },
  { id: 'j-1-25', title: 'روز بزرگداشت عطار نیشابوری', description: 'روز بزرگداشت عطار نیشابوری', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 1, day: 25 },
  { id: 'j-1-29', title: 'روز ارتش', description: 'روز ارتش جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 29 },
  { id: 'j-1-30', title: 'روز علوم آزمایشگاهی', description: 'روز علوم آزمایشگاهی؛ زادروز حکیم سید اسماعیل جرجانی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 1, day: 30 },

  // ——— اردیبهشت ———
  { id: 'j-2-1', title: 'روز بزرگداشت سعدی', description: 'روز بزرگداشت حکیم ابوالقاسم سعدی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 1 },
  { id: 'j-2-2', title: 'جشن گیاه‌آوری؛ روز زمین', description: 'جشن گیاه‌آوری؛ روز زمین', type: 'international', category: 'shamsi', calendar: 'jalali', month: 2, day: 2 },
  { id: 'j-2-3', title: 'روز بزرگداشت شیخ بهایی', description: 'روز بزرگداشت شیخ بهایی؛ روز ملی کارآفرینی؛ روز معماری', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 3 },
  { id: 'j-2-10', title: 'روز ملی خلیج فارس', description: 'جشن چهلم نوروز؛ روز ملی خلیج فارس', type: 'national', category: 'shamsi', calendar: 'jalali', month: 2, day: 10 },
  { id: 'j-2-12', title: 'روز معلم', description: 'سالروز شهادت استاد مرتضی مطهری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 2, day: 12 },
  { id: 'j-2-15', title: 'جشن میانه بهار؛ روز شیراز', description: 'جشن میانه بهار / جشن بهاربد؛ روز شیراز', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 15 },
  { id: 'j-2-25', title: 'روز بزرگداشت فردوسی', description: 'روز بزرگداشت حکیم ابوالقاسم فردوسی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 25 },
  { id: 'j-2-27', title: 'روز ارتباطات و روابط عمومی', description: 'روز ارتباطات و روابط عمومی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 2, day: 27 },
  { id: 'j-2-28', title: 'روز بزرگداشت خیام', description: 'روز بزرگداشت حکیم عمر خیام نیشابوری', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 28 },

  // ——— خرداد ———
  { id: 'j-3-1', title: 'روز بهره‌وری؛ بزرگداشت ملاصدرا', description: 'روز بهره‌وری و بهینه‌سازی مصرف؛ روز بزرگداشت ملاصدرا', type: 'national', category: 'shamsi', calendar: 'jalali', month: 3, day: 1 },
  { id: 'j-3-3', title: 'فتح خرمشهر', description: 'فتح خرمشهر در عملیات بیت‌المقدس؛ روز مقاومت، ایثار و پیروزی', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 3, day: 3 },
  { id: 'j-3-4', title: 'روز دزفول', description: 'روز مقاومت و پایداری دزفول', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 3, day: 4 },
  { id: 'j-3-6', title: 'جشن خردادگان', description: 'خرداد روز، جشن خردادگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 3, day: 6 },
  { id: 'j-3-14', title: 'رحلت امام خمینی', description: 'رحلت بنیان‌گذار جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 3, day: 14, isHoliday: true },
  { id: 'j-3-15', title: 'قیام ۱۵ خرداد', description: 'سالروز قیام خونین ۱۵ خرداد', type: 'national', category: 'shamsi', calendar: 'jalali', month: 3, day: 15, isHoliday: true },
  { id: 'j-3-25', title: 'روز ملی گل و گیاه', description: 'روز ملی گل و گیاه', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 3, day: 25 },
  { id: 'j-3-31', title: 'سالروز زلزله رودبار و منجیل', description: 'سالروز زلزله رودبار و منجیل (۱۳۶۹)', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 3, day: 31 },

  // ——— تیر ———
  { id: 'j-4-1', title: 'جشن آب‌پاشونک', description: 'جشن آب‌پاشونک، جشن آغاز تابستان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 4, day: 1 },
  { id: 'j-4-7', title: 'روز قوه قضاییه', description: 'انفجار دفتر حزب جمهوری اسلامی؛ روز قوه قضاییه', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 7 },
  { id: 'j-4-8', title: 'روز مبارزه با سلاح‌های شیمیایی', description: 'روز مبارزه با سلاح‌های شیمیایی و میکروبی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 8 },
  { id: 'j-4-10', title: 'روز صنعت و معدن', description: 'روز صنعت و معدن؛ بزرگداشت صائب تبریزی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 10 },
  { id: 'j-4-13', title: 'جشن تیرگان', description: 'جشن تیرگان، بزرگداشت آرش کمانگیر', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 4, day: 13 },
  { id: 'j-4-14', title: 'روز قلم', description: 'روز قلم', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 4, day: 14 },
  { id: 'j-4-22', title: 'روز ملی فناوری اطلاعات', description: 'زادروز محمد خوارزمی؛ روز ملی فناوری اطلاعات', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 4, day: 22 },
  { id: 'j-4-25', title: 'روز بهزیستی و تامین اجتماعی', description: 'روز بهزیستی و تامین اجتماعی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 25 },

  // ——— مرداد ———
  { id: 'j-5-7', title: 'جشن اَمردادگان', description: 'اَمرداد روز، جشن اَمردادگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 5, day: 7 },
  { id: 'j-5-8', title: 'روز بزرگداشت سهروردی', description: 'روز بزرگداشت شیخ شهاب‌الدین سهروردی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 5, day: 8 },
  { id: 'j-5-10', title: 'جشن چله تابستان', description: 'جشن چله تابستان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 5, day: 10 },
  { id: 'j-5-14', title: 'سالروز فرمان مشروطیت', description: 'سالروز صدور فرمان مشروطیت', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 5, day: 14 },
  { id: 'j-5-17', title: 'روز خبرنگار', description: 'روز خبرنگار', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 5, day: 17 },
  { id: 'j-5-28', title: 'سالروز ۲۸ مرداد', description: 'سالروز وقایع ۲۸ مرداد؛ فاجعه سینما رکس آبادان', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 5, day: 28 },

  // ——— شهریور ———
  { id: 'j-6-1', title: 'روز پزشک؛ بزرگداشت ابوعلی سینا', description: 'روز بزرگداشت ابوعلی سینا و روز پزشک', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 6, day: 1 },
  { id: 'j-6-2', title: 'آغاز هفته دولت', description: 'آغاز هفته دولت', type: 'national', category: 'shamsi', calendar: 'jalali', month: 6, day: 2 },
  { id: 'j-6-4', title: 'زادروز کوروش بزرگ؛ جشن شهریورگان', description: 'زادروز کوروش بزرگ؛ شهریور روز، جشن شهریورگان', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 6, day: 4 },
  { id: 'j-6-5', title: 'روز داروساز؛ بزرگداشت رازی', description: 'روز بزرگداشت محمدبن زکریای رازی و روز داروساز', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 6, day: 5 },
  { id: 'j-6-8', title: 'روز مبارزه با تروریسم', description: 'انفجار دفتر نخست‌وزیری؛ روز مبارزه با تروریسم', type: 'national', category: 'shamsi', calendar: 'jalali', month: 6, day: 8 },
  { id: 'j-6-11', title: 'روز ملی صنعت چاپ', description: 'روز ملی صنعت چاپ', type: 'national', category: 'shamsi', calendar: 'jalali', month: 6, day: 11 },
  { id: 'j-6-13', title: 'روز بزرگداشت ابوریحان بیرونی', description: 'روز بزرگداشت ابوریحان بیرونی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 6, day: 13 },
  { id: 'j-6-21', title: 'روز سینما', description: 'روز سینما', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 6, day: 21 },
  { id: 'j-6-27', title: 'روز شعر و ادب پارسی', description: 'روز شعر و ادب پارسی و روز بزرگداشت استاد شهریار', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 6, day: 27 },
  { id: 'j-6-31', title: 'آغاز هفته دفاع مقدس', description: 'آغاز هفته دفاع مقدس', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 6, day: 31 },

  // ——— مهر ———
  { id: 'j-7-4', title: 'روز گرامیداشت سربازان وطن', description: 'روز گرامیداشت سربازان وطن', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 4 },
  { id: 'j-7-7', title: 'روز آتش‌نشانی و ایمنی', description: 'روز آتش‌نشانی و ایمنی؛ بزرگداشت شمس تبریزی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 7 },
  { id: 'j-7-8', title: 'روز بزرگداشت مولوی', description: 'روز بزرگداشت مولوی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 7, day: 8 },
  { id: 'j-7-10', title: 'جشن مهرگان', description: 'جشن مهرگان، خیزش کاوه و پیروزی فریدون بر ضحاک', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 7, day: 10 },
  { id: 'j-7-14', title: 'روز دامپزشکی', description: 'روز دامپزشکی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 14 },
  { id: 'j-7-15', title: 'جشن مهرگان بزرگ', description: 'جشن مهرگان بزرگ', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 7, day: 15 },
  { id: 'j-7-16', title: 'روز ملی کودک', description: 'روز ملی کودک', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 16 },
  { id: 'j-7-20', title: 'روز بزرگداشت حافظ', description: 'روز بزرگداشت حافظ', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 7, day: 20 },
  { id: 'j-7-26', title: 'روز تربیت بدنی و ورزش', description: 'روز تربیت بدنی و ورزش', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 26 },
  { id: 'j-7-29', title: 'روز ملی کوهنورد', description: 'روز ملی کوهنورد', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 29 },

  // ——— آبان ———
  { id: 'j-8-1', title: 'روز آمار و برنامه‌ریزی؛ بزرگداشت بیهقی', description: 'روز آمار و برنامه‌ریزی؛ روز بزرگداشت ابوالفضل بیهقی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 8, day: 1 },
  { id: 'j-8-7', title: 'ورود کوروش به بابل', description: 'سالروز ورود کوروش بزرگ به بابل (۵۳۹ پ.م)', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 8, day: 7 },
  { id: 'j-8-8', title: 'روز ملی محیط‌بان', description: 'روز ملی محیط‌بان', type: 'national', category: 'shamsi', calendar: 'jalali', month: 8, day: 8 },
  { id: 'j-8-10', title: 'جشن آبانگان', description: 'آبان روز، جشن آبانگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 8, day: 10 },
  { id: 'j-8-14', title: 'روز ملّی مازندران', description: 'روز ملّی مازندران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 8, day: 14 },
  { id: 'j-8-15', title: 'جشن میانه پاییز', description: 'جشن میانه پاییز', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 8, day: 15 },
  { id: 'j-8-18', title: 'روز ملی کیفیت', description: 'روز ملی کیفیت', type: 'national', category: 'shamsi', calendar: 'jalali', month: 8, day: 18 },
  { id: 'j-8-24', title: 'روز کتاب و کتابخوانی', description: 'روز کتاب و کتابخوانی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 8, day: 24 },

  // ——— آذر ———
  { id: 'j-9-1', title: 'آذر جشن', description: 'آذر جشن', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 9, day: 1 },
  { id: 'j-9-5', title: 'روز بسیج مستضعفان', description: 'روز بسیج مستضعفان', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 5 },
  { id: 'j-9-7', title: 'روز نیروی دریایی', description: 'سالروز عملیات مروارید و روز نیروی دریایی ارتش', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 7 },
  { id: 'j-9-9', title: 'جشن آذرگان', description: 'جشن آذرگان، آذر روز', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 9, day: 9 },
  { id: 'j-9-13', title: 'روز صنعت بیمه', description: 'روز صنعت بیمه', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 13 },
  { id: 'j-9-15', title: 'روز حسابدار', description: 'روز حسابدار', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 15 },
  { id: 'j-9-16', title: 'روز دانشجو', description: 'روز دانشجو', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 16 },
  { id: 'j-9-25', title: 'روز پژوهش و فناوری', description: 'روز پژوهش و فناوری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 25 },
  { id: 'j-9-30', title: 'شب یلدا', description: 'جشن شب یلدا، شب چلّه', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 9, day: 30 },

  // ——— دی ———
  { id: 'j-10-1', title: 'جشن خرم‌روز (دیگان)', description: 'روز میلاد خورشید؛ جشن خرم روز، نخستین جشن دیگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 10, day: 1 },
  { id: 'j-10-5', title: 'سالروز زلزله بم؛ شهادت زرتشت', description: 'زمین‌لرزه بم (۱۳۸۲)؛ سالروز شهادت اَشو زرتشت', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 10, day: 5 },
  { id: 'j-10-8', title: 'جشن دیگان دوم؛ بزرگداشت یعقوب لیث', description: 'دی به آذر روز، دومین جشن دیگان؛ بزرگداشت یعقوب لیث صفاری', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 10, day: 8 },
  { id: 'j-10-12', title: 'روز حافظ', description: 'روز حافظ', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 10, day: 12 },
  { id: 'j-10-13', title: 'شهادت سردار سلیمانی', description: 'شهادت سردار حاج قاسم سلیمانی (۱۳۹۸)', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 10, day: 13 },
  { id: 'j-10-15', title: 'جشن دیگان سوم', description: 'دی به مهر روز، سومین جشن دیگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 10, day: 15 },
  { id: 'j-10-20', title: 'قتل امیرکبیر', description: 'قتل امیرکبیر به دستور ناصرالدین شاه (۱۲۳۰)', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 10, day: 20 },
  { id: 'j-10-23', title: 'جشن دیگان چهارم', description: 'دی به دین روز، چهارمین جشن دیگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 10, day: 23 },

  // ——— بهمن ———
  { id: 'j-11-1', title: 'زادروز فردوسی', description: 'زادروز فردوسی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 11, day: 1 },
  { id: 'j-11-2', title: 'جشن بهمنگان', description: 'بهمن روز، جشن بهمنگان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 11, day: 2 },
  { id: 'j-11-6', title: 'روز موسیقی ایرانی', description: 'بزرگداشت صفی‌الدین اُرمَوی و روز موسیقی ایرانی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 11, day: 6 },
  { id: 'j-11-10', title: 'جشن سده', description: 'جشن سده، گرامیداشت کشف آتش', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 11, day: 10 },
  { id: 'j-11-12', title: 'بازگشت امام خمینی به ایران', description: 'بازگشت امام خمینی (ره) به ایران', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 11, day: 12 },
  { id: 'j-11-15', title: 'جشن میانه زمستان', description: 'جشن میانه زمستان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 11, day: 15 },
  { id: 'j-11-19', title: 'روز نیروی هوایی', description: 'روز نیروی هوایی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 11, day: 19 },
  { id: 'j-11-22', title: 'پیروزی انقلاب اسلامی', description: 'پیروزی انقلاب اسلامی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 11, day: 22, isHoliday: true },
  { id: 'j-11-29', title: 'جشن سپندارمذگان', description: 'جشن سپندارمذگان و روز عشق', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 11, day: 29 },

  // ——— اسفند ———
  { id: 'j-12-5', title: 'روز بزرگداشت خواجه نصیرالدین طوسی و روز مهندسی', description: 'روز بزرگداشت خواجه نصیرالدین طوسی و روز مهندسی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 12, day: 5 },
  { id: 'j-12-7', title: 'سالروز استقلال کانون وکلا', description: 'سالروز استقلال کانون وکلای دادگستری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 7 },
  { id: 'j-12-14', title: 'روز احسان و نیکوکاری', description: 'روز احسان و نیکوکاری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 14 },
  { id: 'j-12-15', title: 'روز درختکاری', description: 'روز درختکاری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 15 },
  { id: 'j-12-18', title: 'روز بزرگداشت سید جمال‌الدین اسدآبادی', description: 'روز بزرگداشت سید جمال‌الدین اسدآبادی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 12, day: 18 },
  { id: 'j-12-20', title: 'روز ملی شدن صنعت نفت', description: 'روز ملی شدن صنعت نفت ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 20 },
  { id: 'j-12-25', title: 'روز بزرگداشت پروین اعتصامی', description: 'روز بزرگداشت پروین اعتصامی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 12, day: 25 },
  { id: 'j-12-29', title: 'روز ملی شدن صنعت نفت', description: 'روز ملی شدن صنعت نفت (تعطیل رسمی در صورت تأیید)', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 29, isHoliday: true },

  // مناسبت‌های تکمیلی رایج (time.ir + تقویم رسمی)
  { id: 'j-1-7', title: 'روز جهانی تئاتر', description: 'روز جهانی تئاتر', type: 'international', category: 'shamsi', calendar: 'jalali', month: 1, day: 7 },
  { id: 'j-2-9', title: 'روز ملی روانشناس و مشاور', description: 'روز ملی روانشناس و مشاور', type: 'national', category: 'shamsi', calendar: 'jalali', month: 2, day: 9 },
  { id: 'j-2-22', title: 'زادروز مریم میرزاخانی', description: 'زادروز مریم میرزاخانی؛ روز زنان در ریاضیات', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 22 },
  { id: 'j-4-12', title: 'شلیک به پرواز ۶۵۵', description: 'شلیک به پرواز ۶۵۵ ایران ایر (۱۳۶۷)', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 4, day: 12 },
  { id: 'j-6-12', title: 'سالروز شهادت رئیسعلی دلواری', description: 'سالروز شهادت رئیسعلی دلواری', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 6, day: 12 },
  { id: 'j-7-1', title: 'آغاز سال تحصیلی', description: 'آغاز سال تحصیلی جدید', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 1 },
  { id: 'j-7-13', title: 'روز نیروی انتظامی', description: 'روز نیروی انتظامی جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 13 },
  { id: 'j-8-4', title: 'روز کوروش بزرگ', description: 'روز بزرگداشت کوروش بزرگ', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 8, day: 4 },
  { id: 'j-10-30', title: 'آتش‌سوزی پلاسکو', description: 'آتش‌سوزی و فروریختن ساختمان پلاسکو (۱۳۹۵)', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 10, day: 30 },
];

// ===== Qamari (Lunar/Hijri) Events =====
// These are commonly observed Iranian religious events. Dates are in Hijri (lunar) calendar.
// NOTE: Because lunar year is ~11 days shorter than solar, these shift each year.
// The month/day here represent the Hijri date. For accurate display, the app converts
// today's solar date to Hijri and matches.
export const QAMARI_EVENTS: CalendarEvent[] = [
  { id: 'q-1-9', title: 'تاسوعای حسینی', description: 'نهم محرم', type: 'religious', category: 'qamari', calendar: 'hijri', month: 1, day: 9, isHoliday: true },
  { id: 'q-1-10', title: 'عاشورای حسینی', description: 'دهم محرم - سالروز شهادت امام حسین (ع)', type: 'religious', category: 'qamari', calendar: 'hijri', month: 1, day: 10, isHoliday: true },
  { id: 'q-1-20', title: 'چهلم امام حسین (ع)', description: 'اربعین حسینی', type: 'religious', category: 'qamari', calendar: 'hijri', month: 2, day: 20, isHoliday: true },
  { id: 'q-2-28', title: 'رحلت پیامبر اکرم (ص)', description: '۲۸ صفر المظفر', type: 'religious', category: 'qamari', calendar: 'hijri', month: 2, day: 28, isHoliday: true },
  { id: 'q-2-29', title: 'شهادت امام حسن مجتبی (ع)', description: '۲۹ صفر', type: 'religious', category: 'qamari', calendar: 'hijri', month: 2, day: 29 },
  { id: 'q-3-8', title: 'شهادت امام کاظم (ع)', description: 'هشتم ربیع‌الاول', type: 'religious', category: 'qamari', calendar: 'hijri', month: 3, day: 8 },
  { id: 'q-3-17', title: 'میلاد پیامبر اکرم (ص) و امام صادق (ع)', description: 'هفدهم ربیع‌الاول', type: 'religious', category: 'qamari', calendar: 'hijri', month: 3, day: 17, isHoliday: true },
  { id: 'q-6-3', title: 'شهادت حضرت زهرا (س)', description: 'سوم جمادی‌الثانی', type: 'religious', category: 'qamari', calendar: 'hijri', month: 6, day: 3, isHoliday: true },
  { id: 'q-7-1', title: 'میلاد امام علی (ع)', description: 'اول رجب', type: 'religious', category: 'qamari', calendar: 'hijri', month: 7, day: 1 },
  { id: 'q-7-13', title: 'میلاد امام حسین (ع)', description: 'سیزدهم رجب', type: 'religious', category: 'qamari', calendar: 'hijri', month: 7, day: 13 },
  { id: 'q-7-27', title: 'مبعث پیامبر اکرم (ص)', description: 'بیست‌وهفتم رجب', type: 'religious', category: 'qamari', calendar: 'hijri', month: 7, day: 27, isHoliday: true },
  { id: 'q-8-15', title: 'ولادت امام زمان (ع) - نیمه شعبان', description: 'پانزدهم شعبان', type: 'religious', category: 'qamari', calendar: 'hijri', month: 8, day: 15, isHoliday: true },
  { id: 'q-9-21', title: 'شهادت امام علی (ع)', description: 'بیست‌ویکم رمضان', type: 'religious', category: 'qamari', calendar: 'hijri', month: 9, day: 21, isHoliday: true },
  { id: 'q-9-19', title: 'ضربت خوردن امام علی (ع)', description: 'نوزدهم رمضان (شب قدر)', type: 'religious', category: 'qamari', calendar: 'hijri', month: 9, day: 19 },
  { id: 'q-9-23', title: 'شهادت امام علی (ع)', description: 'بیست‌وسوم رمضان', type: 'religious', category: 'qamari', calendar: 'hijri', month: 9, day: 23 },
  { id: 'q-10-1', title: 'عید سعید فطر', description: 'اول شوال', type: 'religious', category: 'qamari', calendar: 'hijri', month: 10, day: 1, isHoliday: true },
  { id: 'q-10-2', title: 'تعطیلی عید فطر', description: 'دوم شوال', type: 'religious', category: 'qamari', calendar: 'hijri', month: 10, day: 2, isHoliday: true },
  { id: 'q-10-3', title: 'تعطیلی عید فطر', description: 'سوم شوال', type: 'religious', category: 'qamari', calendar: 'hijri', month: 10, day: 3, isHoliday: true },
  { id: 'q-12-10', title: 'عید سعید قربان', description: 'دهم ذی‌الحجه', type: 'religious', category: 'qamari', calendar: 'hijri', month: 12, day: 10, isHoliday: true },
  { id: 'q-12-18', title: 'عید سعید غدیر خم', description: 'هجدهم ذی‌الحجه', type: 'religious', category: 'qamari', calendar: 'hijri', month: 12, day: 18, isHoliday: true },
];

// ===== Gregorian (Global) Events =====
export const GLOBAL_EVENTS: CalendarEvent[] = [
  { id: 'g-1-1', title: 'New Year\'s Day', description: 'آغاز سال میلادی', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 1 },
  { id: 'g-1-15', title: 'World Religion Day', description: 'روز جهانی ادیان', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 15 },
  { id: 'g-1-24', title: 'International Day of Education', description: 'روز جهانی آموزش', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 24 },
  { id: 'g-1-27', title: 'International Holocaust Remembrance Day', description: 'روز بین‌المللی یادبود هولوکاست', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 27 },
  { id: 'g-2-4', title: 'World Cancer Day', description: 'روز جهانی سرطان', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 4 },
  { id: 'g-2-11', title: 'International Day of Women and Girls in Science', description: 'روز جهانی زنان و دختران در علم', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 11 },
  { id: 'g-2-14', title: 'Valentine\'s Day', description: 'روز ولنتاین (روز عشق)', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 14 },
  { id: 'g-2-21', title: 'International Mother Language Day', description: 'روز جهانی زبان مادری', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 21 },
  { id: 'g-3-8', title: 'International Women\'s Day', description: 'روز جهانی حقوق زنان و صلح', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 8 },
  { id: 'g-3-21', title: 'World Poetry Day', description: 'روز جهانی شعر', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 21 },
  { id: 'g-3-22', title: 'World Water Day', description: 'روز جهانی آب', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 22 },
  { id: 'g-3-23', title: 'World Meteorological Day', description: 'روز جهانی هواشناسی', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 23 },
  { id: 'g-4-7', title: 'World Health Day', description: 'روز جهانی بهداشت', type: 'international', category: 'global', calendar: 'gregorian', month: 4, day: 7 },
  { id: 'g-4-22', title: 'Earth Day', description: 'روز زمین', type: 'international', category: 'global', calendar: 'gregorian', month: 4, day: 22 },
  { id: 'g-4-23', title: 'World Book and Copyright Day', description: 'روز جهانی کتاب و حق مؤلف', type: 'international', category: 'global', calendar: 'gregorian', month: 4, day: 23 },
  { id: 'g-5-1', title: 'International Workers\' Day', description: 'روز جهانی کارگر', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 1 },
  { id: 'g-5-8', title: 'World Red Cross and Red Crescent Day', description: 'روز جهانی صلیب سرخ و هلال احمر', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 8 },
  { id: 'g-5-15', title: 'International Day of Families', description: 'روز جهانی خانواده', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 15 },
  { id: 'g-5-17', title: 'World Telecommunication Day', description: 'روز جهانی مخابرات', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 17 },
  { id: 'g-5-31', title: 'World No Tobacco Day', description: 'روز جهانی بدون دخانیات', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 31 },
  { id: 'g-6-1', title: 'International Children\'s Day', description: 'روز جهانی کودکان', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 1 },
  { id: 'g-6-5', title: 'World Environment Day', description: 'روز جهانی محیط زیست', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 5 },
  { id: 'g-6-8', title: 'World Oceans Day', description: 'روز جهانی اقیانوس‌ها', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 8 },
  { id: 'g-6-21', title: 'International Day of Yoga', description: 'روز جهانی یوگا', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 21 },
  { id: 'g-6-26', title: 'International Day Against Drug Abuse', description: 'روز جهانی مبارزه با مواد مخدر', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 26 },
  { id: 'g-7-11', title: 'World Population Day', description: 'روز جهانی جمعیت', type: 'international', category: 'global', calendar: 'gregorian', month: 7, day: 11 },
  { id: 'g-7-18', title: 'Nelson Mandela International Day', description: 'روز جهانی نلسون ماندلا', type: 'international', category: 'global', calendar: 'gregorian', month: 7, day: 18 },
  { id: 'g-8-12', title: 'International Youth Day', description: 'روز جهانی جوانان', type: 'international', category: 'global', calendar: 'gregorian', month: 8, day: 12 },
  { id: 'g-8-19', title: 'World Humanitarian Day', description: 'روز جهانی امدادگران', type: 'international', category: 'global', calendar: 'gregorian', month: 8, day: 19 },
  { id: 'g-9-8', title: 'International Literacy Day', description: 'روز جهانی سوادآموزی', type: 'international', category: 'global', calendar: 'gregorian', month: 9, day: 8 },
  { id: 'g-9-21', title: 'International Day of Peace', description: 'روز جهانی صلح', type: 'international', category: 'global', calendar: 'gregorian', month: 9, day: 21 },
  { id: 'g-9-27', title: 'World Tourism Day', description: 'روز جهانی گردشگری', type: 'international', category: 'global', calendar: 'gregorian', month: 9, day: 27 },
  { id: 'g-10-1', title: 'International Day of Older Persons', description: 'روز جهانی سالمندان', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 1 },
  { id: 'g-10-5', title: 'World Teachers\' Day', description: 'روز جهانی معلم', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 5 },
  { id: 'g-10-10', title: 'World Mental Health Day', description: 'روز جهانی سلامت روان', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 10 },
  { id: 'g-10-16', title: 'World Food Day', description: 'روز جهانی غذا', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 16 },
  { id: 'g-10-24', title: 'United Nations Day', description: 'روز سازمان ملل متحد', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 24 },
  { id: 'g-11-11', title: 'World Science Day for Peace and Development', description: 'روز جهانی علم برای صلح و توسعه', type: 'international', category: 'global', calendar: 'gregorian', month: 11, day: 11 },
  { id: 'g-11-20', title: 'Universal Children\'s Day', description: 'روز جهانی کودکان', type: 'international', category: 'global', calendar: 'gregorian', month: 11, day: 20 },
  { id: 'g-12-1', title: 'World AIDS Day', description: 'روز جهانی ایدز', type: 'international', category: 'global', calendar: 'gregorian', month: 12, day: 1 },
  { id: 'g-12-10', title: 'Human Rights Day', description: 'روز جهانی حقوق بشر', type: 'international', category: 'global', calendar: 'gregorian', month: 12, day: 10 },
  { id: 'g-12-25', title: 'Christmas Day', description: 'روز کریسمس', type: 'international', category: 'global', calendar: 'gregorian', month: 12, day: 25 },
];

export const ALL_EVENTS: CalendarEvent[] = [...SHAMSI_EVENTS, ...QAMARI_EVENTS, ...GLOBAL_EVENTS];

export const EVENT_TYPE_LABELS: Record<EventType, string> = {
  national: 'ملی',
  international: 'جهانی',
  historical: 'تاریخی',
  cultural: 'فرهنگی',
  holiday: 'تعطیلی',
  religious: 'مذهبی',
};

export const EVENT_TYPE_COLORS: Record<EventType, string> = {
  national: 'bg-red-100 text-red-700 border-red-200',
  international: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  historical: 'bg-amber-100 text-amber-700 border-amber-200',
  cultural: 'bg-violet-100 text-violet-700 border-violet-200',
  holiday: 'bg-rose-100 text-rose-700 border-rose-200',
  religious: 'bg-teal-100 text-teal-700 border-teal-200',
};

export const CATEGORY_LABELS: Record<EventCategory, string> = {
  shamsi: 'شمسی (ایرانی)',
  qamari: 'قمری (مذهبی)',
  global: 'جهانی (میلادی)',
};
