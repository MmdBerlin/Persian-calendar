import type { ReminderType } from '@/hooks/use-reminders';

export const REMINDER_TYPE_LABELS: Record<ReminderType, string> = {
  birthday: 'تولد',
  anniversary: 'سالگرد',
  event: 'مناسبت',
  task: 'کار',
  note: 'یادداشت',
};

export const REMINDER_TYPE_COLORS: Record<ReminderType, string> = {
  birthday: 'bg-pink-100 text-pink-700 border-pink-200',
  anniversary: 'bg-purple-100 text-purple-700 border-purple-200',
  event: 'bg-blue-100 text-blue-700 border-blue-200',
  task: 'bg-orange-100 text-orange-700 border-orange-200',
  note: 'bg-gray-100 text-gray-700 border-gray-200',
};

export const REMINDER_TYPE_DOT_COLORS: Record<ReminderType, string> = {
  birthday: 'bg-pink-500',
  anniversary: 'bg-purple-500',
  event: 'bg-blue-500',
  task: 'bg-orange-500',
  note: 'bg-gray-500',
};

export interface ReminderHints {
  titleLabel: string;
  titlePlaceholder: string;
  titleHelp: string;
  /** Used in the notification preview while the title is empty */
  sampleTitle: string;
  /** Year field is shown only when this is set */
  yearLabel?: string;
  yearHelp?: string;
  descriptionPlaceholder: string;
}

/** Hint texts of the reminder form, one set per reminder type. */
export const REMINDER_TYPE_HINTS: Record<ReminderType, ReminderHints> = {
  birthday: {
    titleLabel: 'نام شخص',
    titlePlaceholder: 'مثلاً: علی',
    titleHelp: 'فقط اسم را بنویسید؛ نوتیف می شود «تولد علی».',
    sampleTitle: 'علی',
    yearLabel: 'سال تولد (اختیاری)',
    yearHelp: 'با وارد کردن سال تولد، در نوتیف سن فرد هم نوشته می شود.',
    descriptionPlaceholder: 'مثلاً: کادو بخرم، کیک سفارش بدهم',
  },
  anniversary: {
    titleLabel: 'سالگرد چه چیزی؟',
    titlePlaceholder: 'مثلاً: ازدواج',
    titleHelp: 'موضوع را بنویسید؛ نوتیف می شود «سالگرد ازدواج».',
    sampleTitle: 'ازدواج',
    yearLabel: 'سال شروع (اختیاری)',
    yearHelp: 'با وارد کردن سال شروع، تعداد سال ها در نوتیف نوشته می شود.',
    descriptionPlaceholder: 'مثلاً: رزرو رستوران، گل سفارش بدهم',
  },
  event: {
    titleLabel: 'عنوان مناسبت',
    titlePlaceholder: 'مثلاً: جلسه با مدیر پروژه',
    titleHelp: 'نام رویداد یا قرار را بنویسید.',
    sampleTitle: 'جلسه با مدیر پروژه',
    descriptionPlaceholder: 'مثلاً: ساعت ۱۰ صبح، دفتر مرکزی',
  },
  task: {
    titleLabel: 'کاری که باید انجام شود',
    titlePlaceholder: 'مثلاً: پرداخت قبض برق',
    titleHelp: 'کار را کوتاه و روشن بنویسید؛ نوتیف می گوید موعد انجامش رسیده.',
    sampleTitle: 'پرداخت قبض برق',
    descriptionPlaceholder: 'مثلاً: تا آخر وقت اداری، شناسه قبض ...',
  },
  note: {
    titleLabel: 'عنوان یادداشت',
    titlePlaceholder: 'مثلاً: کد تخفیف فروشگاه',
    titleHelp: 'عنوان کوتاه یادداشت؛ متن کامل را در توضیحات بنویسید.',
    sampleTitle: 'کد تخفیف فروشگاه',
    descriptionPlaceholder: 'متن یادداشت ...',
  },
};
