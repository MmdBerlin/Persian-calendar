import type { ReminderType } from '@/hooks/use-reminders';

export const REMINDER_TYPE_LABELS: Record<ReminderType, string> = {
  birthday: 'تولد',
  anniversary: 'سالگرد',
  event: 'مناسبت',
  task: 'کار',
  note: 'یادداشت',
};

export const REMINDER_TYPE_COLORS: Record<ReminderType, string> = {
  birthday: 'bg-pink-100 text-pink-700 border-pink-200',
  anniversary: 'bg-purple-100 text-purple-700 border-purple-200',
  event: 'bg-blue-100 text-blue-700 border-blue-200',
  task: 'bg-orange-100 text-orange-700 border-orange-200',
  note: 'bg-gray-100 text-gray-700 border-gray-200',
};

export const REMINDER_TYPE_DOT_COLORS: Record<ReminderType, string> = {
  birthday: 'bg-pink-500',
  anniversary: 'bg-purple-500',
  event: 'bg-blue-500',
  task: 'bg-orange-500',
  note: 'bg-gray-500',
};
