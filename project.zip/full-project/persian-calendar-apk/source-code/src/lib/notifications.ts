/**
 * Cross-platform notification layer.
 *
 * Android APK (Capacitor):
 *   Notifications are scheduled natively with @capacitor/local-notifications
 *   (AlarmManager), so they appear at the right time even when the app is
 *   closed and they are restored after a phone reboot by the plugin.
 *
 * Browser / PWA:
 *   Service worker or the Web Notification API (only while the page is open).
 */

'use client';

import { Capacitor } from '@capacitor/core';
import { LocalNotifications } from '@capacitor/local-notifications';
import type { Reminder } from '@/hooks/use-reminders';
import {
  todayJalali,
  jalaliToGregorian,
  jalaliMonthLength,
  toPersianDigits,
} from '@/lib/jalali';

export const ANDROID_CHANNEL_ID = 'calendar-reminders';
/** Local hour (0-23) at which reminder notifications are delivered. */
export const NOTIFY_HOUR = 9;
/** How many yearly occurrences ahead are scheduled natively. */
const YEARS_AHEAD = 3;
/** Safety cap on the number of pending native notifications. */
const MAX_SCHEDULED = 400;
const FIRED_KEY = 'persian-calendar-native-fired';

export type NotificationChannel =
  | 'capacitor'    // native Android via Capacitor
  | 'serviceworker' // PWA service worker
  | 'webapi'       // desktop main-thread Notification
  | 'unsupported'; // nothing available

type Perm = 'granted' | 'denied' | 'prompt' | 'unsupported';

export function isNativePlatform(): boolean {
  try {
    return typeof window !== 'undefined' && Capacitor.isNativePlatform();
  } catch {
    return false;
  }
}

/** Detect the best available notification channel. */
export function detectNotificationChannel(): NotificationChannel {
  if (typeof window === 'undefined') return 'unsupported';
  if (isNativePlatform()) return 'capacitor';
  if ('serviceWorker' in navigator) return 'serviceworker';
  if ('Notification' in window) return 'webapi';
  return 'unsupported';
}

/** True when the platform can show notifications at all. */
export function notificationsSupported(): boolean {
  return detectNotificationChannel() !== 'unsupported';
}

function mapPermission(display: string | undefined): Perm {
  if (display === 'granted') return 'granted';
  if (display === 'denied') return 'denied';
  return 'prompt';
}

// ---------------------------------------------------------------------------
// Android channel
// ---------------------------------------------------------------------------

let channelPromise: Promise<void> | null = null;

/** Create the Android notification channel once (required on API 26+). */
function ensureAndroidChannel(): Promise<void> {
  if (!channelPromise) {
    channelPromise = (async () => {
      try {
        await LocalNotifications.createChannel({
          id: ANDROID_CHANNEL_ID,
          name: 'یادآورهای تقویم',
          description: 'نوتیفیکیشن تولدها و مناسبت ها',
          importance: 4, // HIGH: heads-up + sound
          visibility: 1,
          vibration: true,
          lights: true,
          lightColor: '#5856D6',
        });
      } catch (e) {
        console.error('createChannel failed:', e);
        channelPromise = null; // allow retry
      }
    })();
  }
  return channelPromise;
}

// ---------------------------------------------------------------------------
// Immediate notification (test / welcome / web fallbacks)
// ---------------------------------------------------------------------------

interface ShowOptions {
  title: string;
  body: string;
  tag?: string;
  id?: number;
}

export async function showNotification(opts: ShowOptions): Promise<boolean> {
  if (typeof window === 'undefined') return false;

  const channel = detectNotificationChannel();

  // 1) Capacitor native: the APK path
  if (channel === 'capacitor') {
    try {
      await ensureAndroidChannel();
      await LocalNotifications.schedule({
        notifications: [
          {
            title: opts.title,
            body: opts.body,
            id: opts.id ?? (Math.floor(Date.now() / 1000) % 2147483000) + 1,
            channelId: ANDROID_CHANNEL_ID,
            schedule: { at: new Date(Date.now() + 200), allowWhileIdle: true },
            // Do not send the user to the "Alarms & reminders" settings page.
            isExactNotification: false,
            extra: { tag: opts.tag },
          },
        ],
      });
      return true;
    } catch (e) {
      console.error('Capacitor notification failed:', e);
      return false;
    }
  }

  const iconUrl = window.location.origin + '/icons/icon-192.png';

  // 2) Service Worker (PWA)
  if (channel === 'serviceworker') {
    try {
      const reg = await navigator.serviceWorker.ready;
      await reg.showNotification(opts.title, {
        body: opts.body,
        icon: iconUrl,
        badge: '/icons/icon-96.png',
        dir: 'rtl',
        lang: 'fa',
        tag: opts.tag || 'calendar',
        vibrate: [200, 100, 200],
      } as NotificationOptions);
      return true;
    } catch (e) {
      console.warn('SW notification failed, trying main thread:', e);
    }
  }

  // 3) main-thread Web Notification (desktop)
  if ('Notification' in window) {
    try {
      const notif = new Notification(opts.title, {
        body: opts.body,
        icon: iconUrl,
        dir: 'rtl',
        lang: 'fa',
        tag: opts.tag || 'calendar',
      });
      setTimeout(() => { try { notif.close(); } catch { /* ignore */ } }, 8000);
      return true;
    } catch (e) {
      console.error('Web notification failed:', e);
    }
  }

  return false;
}

// ---------------------------------------------------------------------------
// Permissions
// ---------------------------------------------------------------------------

export async function requestNotificationPermission(): Promise<Perm> {
  if (typeof window === 'undefined') return 'unsupported';

  const channel = detectNotificationChannel();
  if (channel === 'unsupported') return 'unsupported';

  if (channel === 'capacitor') {
    try {
      const status = await LocalNotifications.checkPermissions();
      if (status.display === 'granted') {
        await ensureAndroidChannel();
        return 'granted';
      }
      const req = await LocalNotifications.requestPermissions();
      if (req.display === 'granted') {
        await ensureAndroidChannel();
        return 'granted';
      }
      return 'denied';
    } catch (e) {
      console.error('Capacitor permission failed:', e);
      return 'denied';
    }
  }

  if ('Notification' in window) {
    try {
      const result = await Notification.requestPermission();
      if (result === 'granted' && 'serviceWorker' in navigator) {
        try {
          await navigator.serviceWorker.register('/sw.js');
        } catch {
          // main-thread notifications still work
        }
      }
      return result === 'default' ? 'prompt' : (result as Perm);
    } catch {
      return 'denied';
    }
  }

  return 'unsupported';
}

/** Check the current permission state without prompting. */
export async function checkNotificationPermission(): Promise<Perm> {
  if (typeof window === 'undefined') return 'unsupported';

  const channel = detectNotificationChannel();
  if (channel === 'unsupported') return 'unsupported';

  if (channel === 'capacitor') {
    try {
      const status = await LocalNotifications.checkPermissions();
      return mapPermission(status.display);
    } catch {
      return 'prompt';
    }
  }

  if ('Notification' in window) {
    return Notification.permission === 'default'
      ? 'prompt'
      : (Notification.permission as Perm);
  }
  return 'unsupported';
}

// ---------------------------------------------------------------------------
// Native scheduling (works while the app is closed)
// ---------------------------------------------------------------------------

export interface PlannedNotification {
  id: number;
  key: string;
  title: string;
  body: string;
  at: Date;
}

function pad(n: number): string {
  return String(n).padStart(2, '0');
}
function isoDay(d: Date): string {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Stable positive 31-bit id from a string (Android needs a 32-bit int). */
function hashId(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return ((h >>> 0) % 2147483646) + 1;
}

/** Local-midnight dates on which this reminder's event happens (today or later). */
function eventDates(r: Reminder, now: Date): Date[] {
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const out: Date[] = [];

  const jalaliDate = (jy: number): Date => {
    const day = Math.min(r.day, jalaliMonthLength(jy, r.month));
    const g = jalaliToGregorian(jy, r.month, day);
    return new Date(g.gy, g.gm - 1, g.gd);
  };
  const gregorianDate = (gy: number): Date => {
    const day = Math.min(r.day, new Date(gy, r.month, 0).getDate());
    return new Date(gy, r.month - 1, day);
  };

  // One-off reminder with an explicit year
  if (!r.annual && r.year) {
    const d = r.calendar === 'jalali' ? jalaliDate(r.year) : gregorianDate(r.year);
    if (d >= startOfToday) out.push(d);
    return out;
  }

  const baseYear = r.calendar === 'jalali' ? todayJalali().jy : now.getFullYear();
  for (let k = 0; k <= YEARS_AHEAD + 1; k++) {
    const d = r.calendar === 'jalali' ? jalaliDate(baseYear + k) : gregorianDate(baseYear + k);
    if (d < startOfToday) continue;
    out.push(d);
    if (!r.annual) break; // non-annual without year: next occurrence only
    if (out.length > YEARS_AHEAD) break;
  }
  return out;
}

function bodyFor(r: Reminder, daysUntil: number): string {
  if (daysUntil === 0) {
    return r.description ? `${r.description} — امروز` : 'امروز فرا رسیده است';
  }
  if (daysUntil === 1) return 'فردا فرا می رسد';
  return `${toPersianDigits(daysUntil)} روز دیگر فرا می رسد`;
}

/**
 * Pure planning function (no native calls): which notifications should exist.
 * `fired` holds keys already delivered/scheduled so that a notification whose
 * time already passed today is only caught up once.
 */
export function planNotifications(
  reminders: Reminder[],
  now: Date,
  fired: Set<string>
): PlannedNotification[] {
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const plan: PlannedNotification[] = [];

  for (const r of reminders) {
    const before = Math.max(0, Math.floor(r.notifyDaysBefore || 0));
    const kinds = before > 0 ? [0, before] : [0];

    for (const day of eventDates(r, now)) {
      for (const offset of kinds) {
        const fireAt = new Date(day.getFullYear(), day.getMonth(), day.getDate() - offset, NOTIFY_HOUR, 0, 0);
        const key = `${r.id}|${isoDay(day)}|${offset}`;

        let at: Date | null = null;
        if (fireAt.getTime() > now.getTime() + 5000) {
          at = fireAt;
        } else if (fireAt >= startOfToday && !fired.has(key)) {
          at = new Date(now.getTime() + 3000); // catch-up for today
        }
        if (!at) continue;

        plan.push({ id: hashId(key), key, title: r.title, body: bodyFor(r, offset), at });
      }
    }
  }

  plan.sort((a, b) => a.at.getTime() - b.at.getTime());
  return plan.slice(0, MAX_SCHEDULED);
}

function loadFired(): Set<string> {
  try {
    const raw = localStorage.getItem(FIRED_KEY);
    return new Set(raw ? (JSON.parse(raw) as string[]) : []);
  } catch {
    return new Set();
  }
}
function saveFired(set: Set<string>, now: Date) {
  try {
    const limit = isoDay(new Date(now.getFullYear(), now.getMonth(), now.getDate() - 7));
    const keep = [...set].filter((k) => (k.split('|')[1] ?? '') >= limit);
    localStorage.setItem(FIRED_KEY, JSON.stringify(keep));
  } catch {
    // ignore
  }
}

let syncChain: Promise<void> = Promise.resolve();

async function cancelPending(): Promise<void> {
  const pending = await LocalNotifications.getPending();
  if (pending.notifications.length > 0) {
    await LocalNotifications.cancel({
      notifications: pending.notifications.map((n) => ({ id: n.id })),
    });
  }
}

/** Replace all pending native notifications with the plan for `reminders`. */
export function scheduleReminderNotifications(reminders: Reminder[]): Promise<void> {
  if (!isNativePlatform()) return Promise.resolve();
  syncChain = syncChain
    .then(async () => {
      await ensureAndroidChannel();
      const now = new Date();
      const fired = loadFired();
      const plan = planNotifications(reminders, now, fired);

      await cancelPending();

      for (let i = 0; i < plan.length; i += 50) {
        const chunk = plan.slice(i, i + 50);
        await LocalNotifications.schedule({
          notifications: chunk.map((p) => ({
            id: p.id,
            title: p.title,
            body: p.body,
            channelId: ANDROID_CHANNEL_ID,
            schedule: { at: p.at, allowWhileIdle: true },
            isExactNotification: false,
            extra: { key: p.key },
          })),
        });
      }

      plan.forEach((p) => fired.add(p.key));
      saveFired(fired, now);
    })
    .catch((e) => {
      console.error('scheduleReminderNotifications failed:', e);
    });
  return syncChain;
}

/** Remove every pending native notification (notifications turned off). */
export function cancelAllScheduledNotifications(): Promise<void> {
  if (!isNativePlatform()) return Promise.resolve();
  syncChain = syncChain
    .then(() => cancelPending())
    .catch((e) => {
      console.error('cancelAllScheduledNotifications failed:', e);
    });
  return syncChain;
}
