/**
 * متن نوتیفیکیشن بر اساس نوع یادآور (تولد، سالگرد، مناسبت، کار، یادداشت)
 * و اینکه چند روز تا موعد مانده است.
 */

import type { Reminder } from '@/hooks/use-reminders';
import { gregorianToJalali, toPersianDigits } from '@/lib/jalali';
import type { CalendarEvent } from '@/lib/events';

export interface NotificationMessage {
  title: string;
  body: string;
}

function whenPhrase(daysUntil: number): string {
  if (daysUntil <= 0) return 'امروز';
  if (daysUntil === 1) return 'فردا';
  return `${toPersianDigits(daysUntil)} روز دیگر`;
}

/**
 * @param age سنی که فرد در همین تولد کامل می کند، یا تعداد سال های سالگرد (اگر سال شروع معلوم باشد)
 */
export function buildReminderMessage(
  r: Pick<Reminder, 'title' | 'type' | 'description'>,
  daysUntil: number,
  age?: number | null
): NotificationMessage {
  const when = whenPhrase(daysUntil);
  // "تولد علی" typed in full still reads well: drop a duplicated prefix
  const name = r.title
    .trim()
    .replace(r.type === 'birthday' ? /^تولد\s+/ : r.type === 'anniversary' ? /^سالگرد\s+/ : /^$/, '');
  const note = r.description?.trim();
  const hasAge = typeof age === 'number' && age > 0 && age < 150;
  const withNote = (text: string) => (note ? `${text}\n${note}` : text);

  switch (r.type) {
    case 'birthday': {
      const title = `🎂 تولد ${name}`;
      if (daysUntil <= 0) {
        return {
          title,
          body: withNote(
            hasAge
              ? `امروز تولد ${name} است؛ ${toPersianDigits(age!)} ساله می شود. تبریک بگویید!`
              : `امروز تولد ${name} است. تبریک بگویید!`
          ),
        };
      }
      return {
        title,
        body: withNote(
          hasAge
            ? `${when} تولد ${name} است و ${toPersianDigits(age!)} ساله می شود.`
            : `${when} تولد ${name} است.`
        ),
      };
    }

    case 'anniversary': {
      const title = `💍 سالگرد ${name}`;
      const years = hasAge ? ` (${toPersianDigits(age!)} سال)` : '';
      return {
        title,
        body: withNote(
          daysUntil <= 0 ? `امروز سالگرد ${name} است${years}.` : `${when} سالگرد ${name} است${years}.`
        ),
      };
    }

    case 'event': {
      const title = `📅 ${name}`;
      return {
        title,
        body: withNote(daysUntil <= 0 ? `امروز: ${name}` : `${when}: ${name}`),
      };
    }

    case 'task': {
      const title = `✅ کار: ${name}`;
      return {
        title,
        body: withNote(
          daysUntil <= 0 ? `موعد انجام «${name}» امروز است.` : `${when} موعد انجام «${name}» است.`
        ),
      };
    }

    case 'note':
    default: {
      const title = `📝 ${name}`;
      return {
        title,
        body: withNote(daysUntil <= 0 ? 'یادداشت امروز شما' : `یادداشت شما برای ${when}`),
      };
    }
  }
}

/** Local notification time of a reminder (hour 0-23, minute 0-59). Defaults to 09:00. */
export function notifyTimeOf(r: Pick<Reminder, 'notifyHour' | 'notifyMinute'>): { hour: number; minute: number } {
  const hour =
    typeof r.notifyHour === 'number' && r.notifyHour >= 0 && r.notifyHour <= 23 ? Math.floor(r.notifyHour) : 9;
  const minute =
    typeof r.notifyMinute === 'number' && r.notifyMinute >= 0 && r.notifyMinute <= 59
      ? Math.floor(r.notifyMinute)
      : 0;
  return { hour, minute };
}

/** "09:05" */
export function formatNotifyTime(r: Pick<Reminder, 'notifyHour' | 'notifyMinute'>): string {
  const { hour, minute } = notifyTimeOf(r);
  return `${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`;
}

/**
 * Age (birthday) or number of years (anniversary) reached on the occurrence `day`,
 * when the reminder has a start year. Otherwise null.
 */
export function occurrenceAge(
  r: Pick<Reminder, 'type' | 'year' | 'calendar'>,
  day: Date
): number | null {
  if (!r.year || (r.type !== 'birthday' && r.type !== 'anniversary')) return null;
  const occYear =
    r.calendar === 'jalali'
      ? gregorianToJalali(day.getFullYear(), day.getMonth() + 1, day.getDate()).jy
      : day.getFullYear();
  const n = occYear - r.year;
  return n > 0 ? n : null;
}

const CATEGORY_EMOJI: Record<CalendarEvent['category'], string> = { shamsi: '📅', qamari: '🕌', global: '🌍' };

/**
 * One notification for all official occasions of a day.
 * "فردا تعطیل رسمی است" when a holiday is among them, otherwise "فردا: <occasion>".
 */
export function buildEventMessage(events: CalendarEvent[], daysUntil: number): NotificationMessage {
  const when = whenPhrase(daysUntil);
  const holiday = events.some((e) => e.isHoliday);
  const lines = events.map((e) => (e.approx ? `${e.title} (تاریخ تقریبی)` : e.title));
  if (holiday) {
    return { title: `🏖️ ${when} تعطیل رسمی است`, body: lines.join('\n') };
  }
  const first = events[0];
  return {
    title: `${CATEGORY_EMOJI[first.category]} ${when}: ${first.title}`,
    body: events.length > 1 ? lines.slice(1).join('\n') : first.hijriLabel ? first.hijriLabel : 'مناسبت تقویم',
  };
}
