'use client';

import { useState } from 'react';
import { CalendarView } from '@/components/calendar/calendar-view';
import { DateConverter } from '@/components/calendar/date-converter';
import { AgeCalculator } from '@/components/calendar/age-calculator';
import { RemindersManager } from '@/components/calendar/reminders-manager';
import { DayDetails } from '@/components/calendar/day-details';
import { UpcomingReminders } from '@/components/calendar/upcoming-reminders';
import { NotificationSettings } from '@/components/calendar/notification-settings';
import { SettingsPanel } from '@/components/calendar/settings-panel';
import { NotesPanel } from '@/components/calendar/notes-panel';
import { useReminders } from '@/hooks/use-reminders';
import { useNotifications } from '@/hooks/use-notifications';
import { useSettings } from '@/hooks/use-settings';
import { useSmsScheduler } from '@/hooks/use-sms-scheduler';
import { todayJalali, type JalaliDate } from '@/lib/jalali';
import { Sparkles, Calendar, ArrowRightLeft, Cake, Bell, Settings as SettingsIcon, StickyNote } from 'lucide-react';

type Tab = 'calendar' | 'converter' | 'age' | 'reminders' | 'notes' | 'settings';

export default function Home() {
  const remindersHook = useReminders();
  const notificationsHook = useNotifications(remindersHook.reminders);
  const settingsHook = useSettings();
  const smsHook = useSmsScheduler(remindersHook.reminders);
  const [selectedDate, setSelectedDate] = useState<JalaliDate>(todayJalali());
  const [tab, setTab] = useState<Tab>('calendar');

  // Read URL query for tab (?tab=reminders etc.) on first load
  useState(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const t = params.get('tab');
      if (t && ['calendar', 'converter', 'age', 'reminders', 'notes', 'settings'].includes(t)) {
        setTab(t as Tab);
      }
    }
  });

  const today = todayJalali();
  const todayFaDigits = `${String(today.jd).replace(/[0-9]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)])} ${
    ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'][today.jm - 1]
  } ${String(today.jy).replace(/[0-9]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)])}`;

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'calendar', label: 'تقویم', icon: <Calendar className="h-4 w-4" /> },
    { id: 'converter', label: 'تبدیل', icon: <ArrowRightLeft className="h-4 w-4" /> },
    { id: 'age', label: 'سن', icon: <Cake className="h-4 w-4" /> },
    { id: 'reminders', label: 'یادآور', icon: <Bell className="h-4 w-4" /> },
    { id: 'notes', label: 'یادداشت', icon: <StickyNote className="h-4 w-4" /> },
    { id: 'settings', label: 'تنظیمات', icon: <SettingsIcon className="h-4 w-4" /> },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background to-muted/30">
      {/* Top bar — includes safe-area top padding so the Android status bar
          (notification bar) never overlaps the app header. */}
      <header className="glass safe-top sticky top-0 z-50 border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-md shadow-primary/30">
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-tight">تقویم شمسی</h1>
              <p className="text-[10px] text-muted-foreground leading-tight">نوروزی، میلادی، یادآور</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => setTab('reminders')}
              className={`relative h-9 w-9 rounded-xl flex items-center justify-center transition-colors ${
                notificationsHook.enabled
                  ? 'bg-emerald-100 text-emerald-600'
                  : 'bg-muted text-muted-foreground hover:bg-accent'
              }`}
              title={notificationsHook.enabled ? 'نوتیفیکیشن فعال' : 'نوتیفیکیشن خاموش'}
              aria-label="تنظیمات نوتیفیکیشن"
            >
              {notificationsHook.permission === 'default' ? (
                <Bell className="h-4 w-4" />
              ) : notificationsHook.enabled ? (
                <Bell className="h-4 w-4" />
              ) : (
                <Bell className="h-4 w-4" />
              )}
              {notificationsHook.enabled && (
                <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-500 border-2 border-background" />
              )}
            </button>
            <div className="text-left hidden sm:block">
              <div className="text-xs text-muted-foreground">امروز</div>
              <div className="text-sm font-semibold">{todayFaDigits}</div>
            </div>
          </div>
        </div>
      </header>

      {/* Tab bar - mobile-first bottom style */}
      <nav className="sm:hidden sticky top-0 z-40 glass border-b border-border/40">
        <div className="grid grid-cols-6">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex flex-col items-center gap-1 py-2 text-[10px] font-medium transition-colors ${
                tab === t.id ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Main content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6">
        {/* Desktop tab bar */}
        <div className="hidden sm:flex items-center gap-2 mb-6 p-1.5 glass-card rounded-2xl w-fit flex-wrap">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-medium transition-all ${
                tab === t.id
                  ? 'bg-primary text-primary-foreground shadow-md shadow-primary/30'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
              }`}
            >
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>

        {/* Calendar tab */}
        {tab === 'calendar' && (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <CalendarView
                reminders={remindersHook.reminders}
                selectedDate={selectedDate}
                onSelectDate={setSelectedDate}
                settings={settingsHook.settings}
              />
            </div>
            <div className="space-y-6">
              <DayDetails date={selectedDate} reminders={remindersHook.reminders} settings={settingsHook.settings} />
              <UpcomingReminders reminders={remindersHook.reminders} limit={4} />
            </div>
          </div>
        )}

        {/* Converter tab */}
        {tab === 'converter' && (
          <div className="grid lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <DateConverter />
            <div className="space-y-6">
              <UpcomingReminders reminders={remindersHook.reminders} limit={5} />
            </div>
          </div>
        )}

        {/* Age tab */}
        {tab === 'age' && (
          <div className="grid lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
            <AgeCalculator />
            <div className="space-y-6">
              <UpcomingReminders reminders={remindersHook.reminders} limit={5} />
            </div>
          </div>
        )}

        {/* Reminders tab */}
        {tab === 'reminders' && (
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-4">
              <NotificationSettings notificationsHook={notificationsHook} />
              <RemindersManager remindersHook={remindersHook} />
            </div>
            <div className="space-y-6">
              <UpcomingReminders reminders={remindersHook.reminders} limit={6} />
            </div>
          </div>
        )}

        {/* Notes tab */}
        {tab === 'notes' && (
          <div className="max-w-4xl mx-auto">
            <NotesPanel />
          </div>
        )}

        {/* Settings tab */}
        {tab === 'settings' && (
          <div className="max-w-3xl mx-auto">
            <SettingsPanel settingsHook={settingsHook} />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/40 bg-background/60 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 text-center text-xs text-muted-foreground">
          <p>تقویم شمسی-میلادی • آفلاین و محلی • تمام داده‌ها در دستگاه شما ذخیره می‌شوند</p>
        </div>
      </footer>
    </div>
  );
}
