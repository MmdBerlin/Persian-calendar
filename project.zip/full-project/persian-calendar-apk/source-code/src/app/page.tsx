'use client';

import { useState, useEffect, useCallback, useRef, type ReactNode } from 'react';
import { motion, useAnimationControls, useReducedMotion } from 'framer-motion';
import { CalendarView } from '@/components/calendar/calendar-view';
import { DateConverter } from '@/components/calendar/date-converter';
import { AgeCalculator } from '@/components/calendar/age-calculator';
import { RemindersManager } from '@/components/calendar/reminders-manager';
import { DayDetails } from '@/components/calendar/day-details';
import { UpcomingReminders } from '@/components/calendar/upcoming-reminders';
import { NotificationSettings } from '@/components/calendar/notification-settings';
import { SettingsPanel } from '@/components/calendar/settings-panel';
import { NotesPanel } from '@/components/calendar/notes-panel';
import { useReminders } from '@/hooks/use-reminders';
import { useNotifications } from '@/hooks/use-notifications';
import { useSettings } from '@/hooks/use-settings';
import { todayJalali, toPersianDigits, JALALI_MONTHS, type JalaliDate } from '@/lib/jalali';
import { ReminderDialog } from '@/components/calendar/reminder-dialog';
import { Sparkles, Calendar, ArrowRightLeft, Cake, Bell, Settings as SettingsIcon, StickyNote } from 'lucide-react';

type Tab = 'calendar' | 'converter' | 'age' | 'reminders' | 'notes' | 'settings';

const TAB_IDS: Tab[] = ['calendar', 'converter', 'age', 'reminders', 'notes', 'settings'];

/** Smooth ease-out curve: quick start, soft landing. */
const ENTER_EASE = [0.22, 1, 0.36, 1] as const;

/**
 * One tab panel. All panels stay mounted (no re-mount lag, inputs and scroll state are kept),
 * and the panel that becomes active plays a short fade + slide in the direction of travel.
 */
function TabPanel({
  active,
  dir,
  reduceMotion,
  children,
}: {
  active: boolean;
  /** +1: slide in from the right, -1: from the left */
  dir: 1 | -1;
  reduceMotion: boolean;
  children: ReactNode;
}) {
  const controls = useAnimationControls();
  const firstRender = useRef(true);

  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    if (!active) return;
    if (reduceMotion) {
      controls.set({ opacity: 1, x: 0, scale: 1 });
      return;
    }
    controls.start({
      opacity: [0, 1],
      x: [dir * 28, 0],
      scale: [0.985, 1],
      transition: { duration: 0.3, ease: ENTER_EASE },
    });
  }, [active, dir, reduceMotion, controls]);

  return (
    <motion.div
      aria-hidden={!active}
      animate={controls}
      className={active ? 'block' : 'hidden'}
      style={{ willChange: active ? 'transform, opacity' : undefined }}
    >
      {children}
    </motion.div>
  );
}

export default function Home() {
  const remindersHook = useReminders();
  const notificationsHook = useNotifications(remindersHook.reminders);
  const settingsHook = useSettings();
  const [selectedDate, setSelectedDate] = useState<JalaliDate>(() => todayJalali());
  // "+" under the calendar: add a reminder for the selected day without leaving the calendar tab
  const [dayDialogOpen, setDayDialogOpen] = useState(false);
  const [dayDialogKey, setDayDialogKey] = useState(0);
  const openDayDialog = useCallback(() => {
    setDayDialogKey((k) => k + 1); // fresh form (and fresh default date) every time
    setDayDialogOpen(true);
  }, []);
  const [tab, setTab] = useState<Tab>('calendar');
  const [dir, setDir] = useState<1 | -1>(1);
  const reduceMotion = useReducedMotion() ?? false;

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const params = new URLSearchParams(window.location.search);
    const t = params.get('tab');
    if (t && (TAB_IDS as string[]).includes(t)) {
      setTab(t as Tab);
    }
  }, []);

  const today = todayJalali();
  const todayFaDigits = `${String(today.jd).replace(/[0-9]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)])} ${
    ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'][today.jm - 1]
  } ${String(today.jy).replace(/[0-9]/g, (d) => '۰۱۲۳۴۵۶۷۸۹'[parseInt(d)])}`;

  const tabs: { id: Tab; label: string; icon: React.ReactNode }[] = [
    { id: 'calendar', label: 'تقویم', icon: <Calendar className="h-4 w-4" /> },
    { id: 'converter', label: 'تبدیل', icon: <ArrowRightLeft className="h-4 w-4" /> },
    { id: 'age', label: 'سن', icon: <Cake className="h-4 w-4" /> },
    { id: 'reminders', label: 'یادآور', icon: <Bell className="h-4 w-4" /> },
    { id: 'notes', label: 'یادداشت', icon: <StickyNote className="h-4 w-4" /> },
    { id: 'settings', label: 'تنظیمات', icon: <SettingsIcon className="h-4 w-4" /> },
  ];

  const tabRef = useRef<Tab>(tab);
  useEffect(() => {
    tabRef.current = tab;
  }, [tab]);

  const switchTab = useCallback((id: Tab) => {
    const current = tabRef.current;
    if (current === id) return;
    // The page is RTL: later tabs are further left, so their content arrives from the left.
    setDir(TAB_IDS.indexOf(id) > TAB_IDS.indexOf(current) ? -1 : 1);
    tabRef.current = id;
    setTab(id);
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background to-muted/30">
      <header className="glass safe-top sticky top-0 z-50 border-b border-border/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-2xl bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center shadow-md shadow-primary/30">
              <Sparkles className="h-4 w-4 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-base font-bold leading-tight">تقویم شمسی</h1>
              <p className="text-[10px] text-muted-foreground leading-tight">نوروزی، میلادی، یادآور</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => switchTab('reminders')}
              className={`relative h-9 w-9 rounded-xl flex items-center justify-center transition-colors duration-200 ${
                notificationsHook.enabled
                  ? 'bg-emerald-100 text-emerald-600'
                  : 'bg-muted text-muted-foreground hover:bg-accent'
              }`}
              title={notificationsHook.enabled ? 'نوتیفیکیشن فعال' : 'نوتیفیکیشن خاموش'}
              aria-label="تنظیمات نوتیفیکیشن"
            >
              <Bell className="h-4 w-4" />
              {notificationsHook.enabled && (
                <span className="absolute -top-0.5 -right-0.5 h-2 w-2 rounded-full bg-emerald-500 border-2 border-background" />
              )}
            </button>
            <div className="text-left hidden sm:block">
              <div className="text-xs text-muted-foreground">امروز</div>
              <div className="text-sm font-semibold">{todayFaDigits}</div>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile tab bar */}
      <nav className="sm:hidden sticky top-0 z-40 glass border-b border-border/40">
        <div className="grid grid-cols-6">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => switchTab(t.id)}
              className={`relative flex flex-col items-center gap-1 py-2 text-[10px] font-medium transition-colors duration-200 ${
                tab === t.id ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              {tab === t.id && (
                <motion.span
                  layoutId="mobile-tab-indicator"
                  className="absolute top-0 inset-x-3 h-0.5 rounded-full bg-primary"
                  transition={reduceMotion ? { duration: 0 } : { type: 'spring', stiffness: 500, damping: 38 }}
                />
              )}
              {t.icon}
              {t.label}
            </button>
          ))}
        </div>
      </nav>

      <main className="flex-1 max-w-7xl mx-auto w-full px-4 sm:px-6 py-6">
        {/* Desktop tab bar */}
        <div className="hidden sm:flex items-center gap-2 mb-6 p-1.5 glass-card rounded-2xl w-fit flex-wrap">
          {tabs.map((t) => (
            <button
              key={t.id}
              onClick={() => switchTab(t.id)}
              className={`relative flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-medium transition-colors duration-200 ${
                tab === t.id
                  ? 'text-primary-foreground'
                  : 'text-muted-foreground hover:text-foreground hover:bg-accent/50'
              }`}
            >
              {tab === t.id && (
                <motion.span
                  layoutId="desktop-tab-pill"
                  className="absolute inset-0 rounded-2xl bg-primary shadow-md shadow-primary/30"
                  transition={reduceMotion ? { duration: 0 } : { type: 'spring', stiffness: 500, damping: 38 }}
                />
              )}
              <span className="relative z-10 flex items-center gap-2">
                {t.icon}
                {t.label}
              </span>
            </button>
          ))}
        </div>

        {/* All panels stay mounted; the newly active one animates in (fade + slide, ~0.3s). */}
        <div className="relative min-h-[50vh]">
          {(
            [
              ['calendar', (
                <div className="grid lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2">
                    <CalendarView
                      reminders={remindersHook.reminders}
                      selectedDate={selectedDate}
                      onSelectDate={setSelectedDate}
                      settings={settingsHook.settings}
                    />
                  </div>
                  <div className="space-y-6">
                    <DayDetails date={selectedDate} reminders={remindersHook.reminders} settings={settingsHook.settings} />
                    <UpcomingReminders
                      reminders={remindersHook.reminders}
                      limit={4}
                      onAdd={openDayDialog}
                      addLabel={`افزودن یادآور برای ${toPersianDigits(selectedDate.jd)} ${JALALI_MONTHS[selectedDate.jm - 1]}`}
                    />
                  </div>
                </div>
              )],
              ['converter', (
                <div className="grid lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
                  <DateConverter />
                  <div className="space-y-6">
                    <UpcomingReminders reminders={remindersHook.reminders} limit={5} />
                  </div>
                </div>
              )],
              ['age', (
                <div className="grid lg:grid-cols-2 gap-6 max-w-5xl mx-auto">
                  <AgeCalculator />
                  <div className="space-y-6">
                    <UpcomingReminders reminders={remindersHook.reminders} limit={5} />
                  </div>
                </div>
              )],
              ['reminders', (
                <div className="grid lg:grid-cols-3 gap-6">
                  <div className="lg:col-span-2 space-y-4">
                    <NotificationSettings notificationsHook={notificationsHook} />
                    <RemindersManager remindersHook={remindersHook} />
                  </div>
                  <div className="space-y-6">
                    <UpcomingReminders reminders={remindersHook.reminders} limit={6} />
                  </div>
                </div>
              )],
              ['notes', (
                <div className="max-w-4xl mx-auto">
                  <NotesPanel />
                </div>
              )],
              ['settings', (
                <div className="max-w-3xl mx-auto">
                  <SettingsPanel settingsHook={settingsHook} />
                </div>
              )],
            ] as [Tab, ReactNode][]
          ).map(([id, content]) => (
            <TabPanel key={id} active={tab === id} dir={dir} reduceMotion={reduceMotion}>
              {content}
            </TabPanel>
          ))}
        </div>
        <ReminderDialog
          key={dayDialogKey}
          open={dayDialogOpen}
          onOpenChange={setDayDialogOpen}
          editingReminder={null}
          defaultDate={selectedDate}
          onSave={(data) => {
            remindersHook.addReminder(data);
            setDayDialogOpen(false);
          }}
        />
      </main>

      <footer className="mt-auto border-t border-border/40 bg-background/60 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 text-center text-xs text-muted-foreground">
          <p>تقویم شمسی-میلادی • آفلاین و محلی • تمام داده ها در دستگاه شما ذخیره می شوند</p>
        </div>
      </footer>
    </div>
  );
}
