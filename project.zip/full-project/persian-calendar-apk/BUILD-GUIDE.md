# راهنمای ساخت APK اندروید از تقویم شمسی (نسخه آفلاین/محلی)

این راهنما برای استفاده شخصی و آفلاین طراحی شده است. اپ بدون نیاز به اینترنت کار می کند و انتشار در Google Play در نظر گرفته نشده است.

## پیش نیازها

### ۱. نصب Node.js (نسخه ۱۸ یا بالاتر)
- از https://nodejs.org دانلود کنید

### ۲. نصب Android Studio
- از https://developer.android.com/studio دانلود کنید
- شامل Android SDK و JDK است

### ۳. نصب JDK 17
- اگر Android Studio نصب باشد، JDK دارد
- متغیر `JAVA_HOME` را به مسیر JDK تنظیم کنید

---

## نکته مهم: پروژه از قبل آماده Capacitor است

این فایل ها از قبل در سورس وجود دارند و نیازی به ساخت دستی ندارند:

| فایل | نقش |
|---|---|
| `capacitor.config.ts` | پیکربندی Capacitor (webDir: `out`) |
| `next.config.ts` | خروجی `export` استاتیک + `images.unoptimized` + `trailingSlash` |
| `package.json` | شامل `@capacitor/core`، `@capacitor/cli`، `@capacitor/android`، `@capacitor/local-notifications`، `@capacitor/status-bar` و اسکریپت `build` ساده (فقط `next build`) |
| `src/lib/notifications.ts` | لایه نوتیفیکیشن چندسکویی — در APK از پلاگین `LocalNotifications` بومی استفاده می کند، در وب از Service Worker |
| `src/components/capacitor-init.tsx` | راه اندازی StatusBar در اندروید (پس زمینه سفید، بدون overlap) |
| `.github/workflows/build-apk.yml` | GitHub Actions — ساخت خودکار APK |

مسیر `src/app/api/route.ts` حذف شده چون با خروجی استاتیک سازگار نبود.

---

## روش ۱: ساخت با GitHub Actions (بدون نیاز به کامپیوتر قوی — ساده ترین)

1. یک ریپازیتوری در GitHub بسازید
2. کل محتوای `source-code/` را push کنید
3. در تب **Actions**، ورک فلو **Build Android APK** را اجرا کنید (Run workflow)
4. پس از اتمام (حدود ۵-۱۰ دقیقه)، از بخش **Artifacts** فایل `persian-calendar-apk` را دانلود کنید
5. داخل آن `app-debug.apk` را روی گوشی نصب کنید

ورک فلو: Node 20 + JDK 17 + Android SDK → `npm ci` → `next build` → `cap add android` → `node scripts/patch-android.mjs` → `cap sync` → `gradlew assembleDebug` → آپلود APK

---

## روش ۲: ساخت لوکال با Capacitor

### گام ۱: نصب وابستگی ها
```bash
cd source-code
npm install
```

### گام ۲: Build استاتیک
```bash
npm run build
```
خروجی در پوشه `out/` ساخته می شود (خودکار).

### گام ۳: اضافه کردن پلتفرم اندروید
```bash
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
```

### گام ۴: باز کردن در Android Studio و گرفتن APK
```bash
npx cap open android
```
در Android Studio: منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)**

### گام ۵: نصب روی گوشی
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```
یا فایل APK را مستقیم روی گوشی کپی و نصب کنید.

---

## روش ۳: ساخت خط فرمان کامل (بدون Android Studio GUI)

اگر Android SDK و JDK 17 را دارید:
```bash
npm install
npm run build
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
```

---

## نوتیفیکیشن در APK چگونه کار می کند

در WebView اندروید، API استاندارد `Notification` وجود ندارد. برای همین:

- **لایه `src/lib/notifications.ts`** به صورت خودکار محیط را تشخیص می دهد:
  1. `capacitor` — اگر پلاگین بومی `LocalNotifications` موجود باشد (داخل APK) → نوتیف بومی اندروید با کانال اعلان «یادآورهای تقویم»، لرزش و نور LED
  2. `serviceworker` — اگر PWA در مرورگر نصب شده باشد → `registration.showNotification`
  3. `webapi` — دسکتاپ → `new Notification`
  4. `unsupported` — هیچ کدام نبود (قبلاً در APK به اشتباه این حالت نمایش داده می شد — الان فیکس شد)
- پلاگین های لازم (`@capacitor/local-notifications` و `@capacitor/status-bar`) در `package.json` هستند و `cap sync` آن ها را به پروژه اندروید اضافه می کند

## مارجین بالای صفحه (نوار وضعیت گوشی)

- `viewport` با `viewportFit: cover` تنظیم شده
- کلاس `safe-top` روی هدر + `--safe-top: env(safe-area-inset-top)` در CSS → محتوا زیر نوار اعلان گوشی نمی رود
- `capacitor-init.tsx` پلاگین StatusBar را طوری تنظیم می کند که نوار وضعیت، WebView را نپوشاند (پس زمینه سفید + آیکون های تیره)

## روش ۴: نصب به صورت PWA (بدون APK)

1. اپ را روی یک هاست اجرا کنید (حتی localhost با IP کامپیوتر)
2. در کروم اندروید باز کنید
3. منوی سه نقطه > **Add to Home screen**

---

## رفع مشکل

| مشکل | راه حل |
|---|---|
| `npx cap` چیزی پیدا نمی کند | `@capacitor/cli` در `package.json` هست؛ `npm install` را اجرا کنید |
| خروجی `next build` با Capacitor جور نیست | `next.config.ts` الان `output: 'export'` دارد — نباید به `standalone` برگردانید |
| `Cannot find Android SDK` | `export ANDROID_HOME=$HOME/Android/Sdk` |
| `Java version mismatch` | JDK 17 نصب کنید |
| نوتیف در APK نمی آید | تنظیمات گوشی: Settings > Apps > تقویم شمسی > Notifications را روشن کنید |
| نوتیف می گوید «پشتیبانی نمی شود» | اگر نسخه قدیمی APK را دارید، با سورس جدید دوباره build بگیرید — این باگ فیکس شد |
| محتوا زیر نوار اعلان می رود | هدر کلاس `safe-top` دارد؛ اگر مشکل ادامه داشت مطمئن شوید `cap sync` بعد از تغییرات اجرا شده |
| Prisma/DB خطا می دهد | اپ از localStorage استفاده می کند؛ Prisma فقط در `package.json` مانده و import نمی شود |

---

## مشخصات فنی اپ

| ویژگی | مقدار |
|---|---|
| **نام اپ** | تقویم شمسی میلادی |
| **Package ID** | `com.persiancalendar.app` |
| **حداقل اندروید** | ۸.۰ (API 26) |
| **اندروید هدف** | ۱۴ (API 34) |
| **جهت** | عمودی (portrait) |
| **تم رنگ** | `#5856D6` |
| **زبان** | فارسی (RTL) |
| **حالت** | آفلاین / محلی |
| **نوتیف** | بومی (Capacitor LocalNotifications) |

---

## خلاصه دستورات (روش لوکال)

```bash
cd source-code
npm install
npm run build          # خروجی در out/
npx cap add android
node scripts/patch-android.mjs
npx cap sync android
cd android && ./gradlew assembleDebug
adb install app/build/outputs/apk/debug/app-debug.apk
```

موفق باشید! 🎉


---

## افزوده ها در این نسخه

- بعد از `npx cap add android` حتما `node scripts/patch-android.mjs` اجرا شود (آیکن نوتیف، اسپلش اسکرین، تم روشن و مجوز آلارم دقیق برای نوتیف سر دقیقه). اگر ورک فلو GitHub Actions دارید، این مرحله باید بین `cap add android` و `cap sync` باشد.
- به روزرسانی مناسبت ها پس از هر نوروز: `node scripts/update-events-from-timeir.mjs` (فایل `src/data/events-<سال>.json` و `src/data/index.ts` را می سازد). سال های قبلی حفظ می شوند.

### به روزرسانی خودکار مناسبت ها (بدون ساخت APK جدید)

1. فایل `.github/workflows/update-events.yml` (داخل `source-code/`) هر ماه صفحه سالانه Time.ir را می گیرد و `src/data/events-<سال>.json` را در ریپازیتوری commit می کند. از تب Actions هم می توانید دستی اجرایش کنید.
2. آدرس فایل را در `src/lib/events-config.ts` بگذارید (یا هنگام بیلد متغیر `NEXT_PUBLIC_EVENTS_JSON_URL` را تنظیم کنید):
   `https://raw.githubusercontent.com/<کاربر>/<ریپو>/main/src/data/events-{year}.json`
   (به جای `{year}` خود برنامه سال شمسی را می گذارد.)
3. برنامه وقتی سال جاری را ندارد (یا در بهمن و اسفند برای سال بعد) خودش از اینترنت می گیرد و در تنظیمات هم دکمه «به روزرسانی مناسبت ها از اینترنت» هست. اگر آدرس شما تنظیم نباشد یا در دسترس نباشد، به عنوان راه آخر مستقیم از Time.ir می خواند. داده دریافتی قبل از ذخیره اعتبارسنجی می شود؛ اگر خراب بود، داده داخل برنامه می ماند.
