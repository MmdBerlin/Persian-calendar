فایل راهنمای فارسی ساخت APK:
persian-calendar-apk/source-code/BUILD-APK-FA.md

پروژه با Capacitor تنظیم شده و GitHub Actions فایل APK آزمایشی را می‌سازد.
برای گرفتن APK واقعی باید سورس را به یک مخزن GitHub آپلود کنید و workflow را اجرا کنید.
