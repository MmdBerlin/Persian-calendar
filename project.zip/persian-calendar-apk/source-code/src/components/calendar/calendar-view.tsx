'use client';

import { useState, useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronRight, ChevronLeft } from 'lucide-react';
import {
  JALALI_MONTHS,
  GREGORIAN_MONTHS,
  WEEKDAYS_FA_ABBR,
  jalaliWeekday,
  generateJalaliMonthGrid,
  jalaliToGregorian,
  gregorianToJalali,
  todayJalali,
  toPersianDigits,
  type JalaliDate,
} from '@/lib/jalali';
import {
  SHAMSI_EVENTS,
  QAMARI_EVENTS,
  GLOBAL_EVENTS,
  type CalendarEvent,
} from '@/lib/events';
import { jalaliToHijri } from '@/lib/hijri';
import type { Reminder } from '@/hooks/use-reminders';
import type { AppSettings } from '@/hooks/use-settings';

interface CalendarViewProps {
  reminders: Reminder[];
  selectedDate?: JalaliDate;
  onSelectDate?: (date: JalaliDate) => void;
  settings: AppSettings;
}

export function CalendarView({ reminders, selectedDate, onSelectDate, settings }: CalendarViewProps) {
  const today = todayJalali();
  const [viewYear, setViewYear] = useState(today.jy);
  const [viewMonth, setViewMonth] = useState(today.jm);
  const [useJalali, setUseJalali] = useState(true);

  const grid = useMemo(() => {
    if (useJalali) {
      return generateJalaliMonthGrid(viewYear, viewMonth);
    } else {
      const j = gregorianToJalali(viewYear, viewMonth, 1);
      return generateJalaliMonthGrid(j.jy, j.jm);
    }
  }, [viewYear, viewMonth, useJalali]);

  const headerInfo = useMemo(() => {
    if (useJalali) {
      const g = jalaliToGregorian(viewYear, viewMonth, 1);
      return {
        primary: `${JALALI_MONTHS[viewMonth - 1]} ${toPersianDigits(viewYear)}`,
        secondary: `${GREGORIAN_MONTHS[g.gm - 1]} ${g.gy}`,
      };
    } else {
      const j = gregorianToJalali(viewYear, viewMonth, 1);
      return {
        primary: `${GREGORIAN_MONTHS[viewMonth - 1]} ${viewYear}`,
        secondary: `${JALALI_MONTHS[j.jm - 1]} ${toPersianDigits(j.jy)}`,
      };
    }
  }, [viewYear, viewMonth, useJalali]);

  const goToPrevMonth = () => {
    if (viewMonth === 1) {
      setViewMonth(12);
      setViewYear((y) => y - 1);
    } else {
      setViewMonth((m) => m - 1);
    }
  };

  const goToNextMonth = () => {
    if (viewMonth === 12) {
      setViewMonth(1);
      setViewYear((y) => y + 1);
    } else {
      setViewMonth((m) => m + 1);
    }
  };

  const goToToday = () => {
    setViewYear(today.jy);
    setViewMonth(today.jm);
    setUseJalali(true);
  };

  // Get filtered events and reminders for a given Jalali date
  const getDayData = (d: JalaliDate) => {
    const events: CalendarEvent[] = [];
    const g = jalaliToGregorian(d.jy, d.jm, d.jd);
    const h = jalaliToHijri(d.jy, d.jm, d.jd);

    if (settings.showShamsiEvents) {
      events.push(...SHAMSI_EVENTS.filter((e) => e.month === d.jm && e.day === d.jd));
    }
    if (settings.showQamariEvents) {
      events.push(...QAMARI_EVENTS.filter((e) => e.month === h.hm && e.day === h.hd));
    }
    if (settings.showGlobalEvents) {
      events.push(...GLOBAL_EVENTS.filter((e) => e.month === g.gm && e.day === g.gd));
    }

    const dayReminders = reminders.filter((r) => {
      if (r.calendar === 'jalali') {
        return r.month === d.jm && r.day === d.jd;
      } else {
        return r.month === g.gm && r.day === g.gd;
      }
    });

    return { events, reminders: dayReminders, gregorianDate: g };
  };

  const isToday = (d: JalaliDate) =>
    d.jy === today.jy && d.jm === today.jm && d.jd === today.jd;

  const isSelected = (d: JalaliDate) =>
    !!selectedDate && d.jy === selectedDate.jy && d.jm === selectedDate.jm && d.jd === selectedDate.jd;

  const isCurrentMonth = (d: JalaliDate) =>
    d.jm === viewMonth && d.jy === viewYear;

  return (
    <Card className="glass-card p-4 sm:p-6 border-0 rounded-3xl">
      {/* Header */}
      <div className="flex items-center justify-between mb-5 flex-wrap gap-3">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight">{headerInfo.primary}</h2>
          <p className="text-sm text-muted-foreground mt-0.5">{headerInfo.secondary}</p>
        </div>
        <div className="flex items-center gap-1.5">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setUseJalali(!useJalali)}
            className="rounded-xl text-xs px-3 h-9"
          >
            {useJalali ? 'میلادی' : 'شمسی'}
          </Button>
          <Button variant="ghost" size="sm" onClick={goToToday} className="rounded-xl text-xs px-3 h-9">
            امروز
          </Button>
          <Button variant="ghost" size="icon" onClick={goToPrevMonth} className="rounded-xl h-9 w-9">
            <ChevronRight className="h-4 w-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={goToNextMonth} className="rounded-xl h-9 w-9">
            <ChevronLeft className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Weekday header */}
      <div className="grid grid-cols-7 gap-1 mb-1.5">
        {WEEKDAYS_FA_ABBR.map((day, idx) => (
          <div
            key={day}
            className={`text-center text-xs font-medium py-2 ${
              idx === 6 ? 'text-rose-500' : 'text-muted-foreground'
            }`}
          >
            {day}
          </div>
        ))}
      </div>

      {/* Days grid - 6 weeks always rendered */}
      <div className="grid grid-cols-7 gap-1">
        {grid.flat().map((d, idx) => {
          const { events, reminders: dayReminders, gregorianDate } = getDayData(d);
          const today_ = isToday(d);
          const selected_ = isSelected(d);
          const inMonth = isCurrentMonth(d);
          const isFriday = jalaliWeekday(d.jy, d.jm, d.jd) === 6;
          const hasHoliday = events.some((e) => e.isHoliday);

          return (
            <button
              key={idx}
              onClick={() => onSelectDate?.(d)}
              className={`
                relative aspect-square rounded-lg p-1.5 sm:p-2 text-right transition-all
                hover:bg-accent/60
                ${!inMonth ? 'opacity-30' : ''}
                ${today_ ? 'bg-primary text-primary-foreground shadow-md shadow-primary/30' : ''}
                ${selected_ && !today_ ? 'ring-2 ring-primary bg-primary/5 text-primary font-semibold' : ''}
                ${hasHoliday && !today_ && !selected_ ? 'bg-rose-50' : ''}
                ${isFriday && !today_ && !selected_ && !hasHoliday ? 'text-rose-600' : ''}
              `}
              aria-label={`${toPersianDigits(d.jd)} ${JALALI_MONTHS[d.jm - 1]}`}
              aria-current={today_ ? 'date' : undefined}
              aria-pressed={selected_}
            >
              <div className="flex flex-col h-full">
                <div className="flex items-start justify-between">
                  <span className="text-sm font-semibold">
                    {toPersianDigits(d.jd)}
                  </span>
                  <span className={`text-[10px] leading-none ${
                    today_ ? 'text-primary-foreground/70' :
                    selected_ ? 'text-primary/70' :
                    'text-muted-foreground/60'
                  }`}>
                    {gregorianDate.gd}
                  </span>
                </div>
                {/* Event/reminder indicators */}
                <div className="flex flex-wrap gap-0.5 mt-auto">
                  {events.slice(0, 3).map((e, i) => (
                    <span
                      key={i}
                      className={`h-1 w-1 rounded-full ${
                        today_ ? 'bg-primary-foreground' :
                        selected_ ? 'bg-primary' :
                        e.isHoliday ? 'bg-rose-500' :
                        e.category === 'shamsi' ? 'bg-red-400' :
                        e.category === 'qamari' ? 'bg-teal-400' :
                        e.category === 'global' ? 'bg-emerald-400' :
                        'bg-amber-400'
                      }`}
                    />
                  ))}
                  {dayReminders.slice(0, 2).map((r, i) => (
                    <span
                      key={`r${i}`}
                      className={`h-1 w-1 rounded-full ${
                        today_ ? 'bg-primary-foreground' :
                        selected_ ? 'bg-primary' :
                        'bg-blue-400'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-5 pt-4 border-t flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
        {settings.showShamsiEvents && (
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-red-400" /> شمسی
          </span>
        )}
        {settings.showQamariEvents && (
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-teal-400" /> قمری
          </span>
        )}
        {settings.showGlobalEvents && (
          <span className="flex items-center gap-1.5">
            <span className="h-2 w-2 rounded-full bg-emerald-400" /> جهانی
          </span>
        )}
        <span className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-blue-400" /> یادآور
        </span>
      </div>
    </Card>
  );
}

