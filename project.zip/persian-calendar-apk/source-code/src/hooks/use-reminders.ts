'use client';

import { useCallback, useSyncExternalStore } from 'react';

export type ReminderType = 'birthday' | 'anniversary' | 'event' | 'task' | 'note';

export interface Reminder {
  id: string;
  title: string;
  description?: string;
  type: ReminderType;
  calendar: 'jalali' | 'gregorian';
  year?: number; // birth year (for age calculation) - optional for annual reminders
  month: number; // 1-12
  day: number; // 1-31
  annual: boolean; // repeat every year
  notifyDaysBefore: number; // 0 = on the day
  color?: string;
  createdAt: number;
  // SMS auto-send (for birthdays, offline app uses tel: link)
  smsEnabled?: boolean;
  smsPhone?: string; // phone number in international format e.g. +989121234567
  smsText?: string; // message body, supports {name} and {age} placeholders
  smsHour?: number; // 0-23 hour to send (default 9)
}

const STORAGE_KEY = 'persian-calendar-reminders-v1';

// --- useSyncExternalStore setup for reminders ---
// SSR returns [] so server HTML matches initial client render (no hydration mismatch).
// The client snapshot is cached: we only re-parse localStorage when the raw string changes,
// so useSyncExternalStore sees a stable reference between notifications.
const remindersListeners = new Set<() => void>();
let cachedRaw: string | null = null;
let cachedReminders: Reminder[] = [];

function notifyRemindersListeners() {
  remindersListeners.forEach((l) => l());
}
function subscribeReminders(cb: () => void) {
  remindersListeners.add(cb);
  if (typeof window !== 'undefined') {
    window.addEventListener('storage', handleStorageEvent);
  }
  return () => {
    remindersListeners.delete(cb);
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', handleStorageEvent);
    }
  };
}
function handleStorageEvent(e: StorageEvent) {
  if (e.key === STORAGE_KEY) {
    cachedRaw = null; // invalidate cache
    notifyRemindersListeners();
  }
}
function getRemindersClient(): Reminder[] {
  if (typeof window === 'undefined') return EMPTY_REMINDERS;
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw === cachedRaw) return cachedReminders; // stable reference, no re-parse
    cachedRaw = raw;
    if (raw) {
      const parsed = JSON.parse(raw) as Reminder[];
      cachedReminders = Array.isArray(parsed) ? parsed : EMPTY_REMINDERS;
    } else {
      cachedReminders = EMPTY_REMINDERS;
    }
  } catch (e) {
    console.error('Failed to load reminders:', e);
    cachedReminders = EMPTY_REMINDERS;
  }
  return cachedReminders;
}
// Cache the server snapshot to avoid infinite loop warnings from React
const EMPTY_REMINDERS: Reminder[] = [];
function getRemindersServer(): Reminder[] {
  return EMPTY_REMINDERS;
}
function setRemindersStore(value: Reminder[]) {
  if (typeof window === 'undefined') return;
  try {
    const str = JSON.stringify(value);
    localStorage.setItem(STORAGE_KEY, str);
    // Update cache so next getRemindersClient() returns the same array reference
    cachedRaw = str;
    cachedReminders = value;
  } catch (e) {
    console.error('Failed to save reminders:', e);
  }
  notifyRemindersListeners();
}
// --- End reminders store ---

export function useReminders() {
  // useSyncExternalStore reads localStorage on client, returns [] on server.
  // No hydration mismatch, no setState-in-effect.
  const reminders = useSyncExternalStore(
    subscribeReminders,
    getRemindersClient,
    getRemindersServer
  );

  const addReminder = useCallback((reminder: Omit<Reminder, 'id' | 'createdAt'>) => {
    const newReminder: Reminder = {
      ...reminder,
      id: `r-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
      createdAt: Date.now(),
    };
    const current = getRemindersClient();
    setRemindersStore([...current, newReminder]);
    return newReminder;
  }, []);

  const updateReminder = useCallback((id: string, updates: Partial<Reminder>) => {
    const current = getRemindersClient();
    setRemindersStore(current.map((r) => (r.id === id ? { ...r, ...updates } : r)));
  }, []);

  const deleteReminder = useCallback((id: string) => {
    const current = getRemindersClient();
    setRemindersStore(current.filter((r) => r.id !== id));
  }, []);

  const clearAll = useCallback(() => {
    setRemindersStore([]);
  }, []);

  // Export to JSON
  const exportReminders = useCallback((): string => {
    return JSON.stringify(reminders, null, 2);
  }, [reminders]);

  // Import from JSON
  const importReminders = useCallback((json: string): boolean => {
    try {
      const parsed = JSON.parse(json) as Reminder[];
      if (Array.isArray(parsed)) {
        setRemindersStore(parsed);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, []);

  return {
    reminders,
    loaded: true,
    addReminder,
    updateReminder,
    deleteReminder,
    clearAll,
    exportReminders,
    importReminders,
  };
}
