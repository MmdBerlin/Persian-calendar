'use client';

import { useState, useEffect, useCallback, useRef, useSyncExternalStore } from 'react';
import type { Reminder } from '@/hooks/use-reminders';
import {
  todayJalali,
  daysBetweenJalali,
  jalaliToGregorian,
  gregorianToJalali,
  toPersianDigits,
  type JalaliDate,
} from '@/lib/jalali';

const PERMISSION_KEY = 'persian-calendar-notification-permission-requested';
const LAST_CHECK_KEY = 'persian-calendar-notification-last-check';
const ENABLED_KEY = 'persian-calendar-notifications-enabled';

export type NotificationPermissionState = 'default' | 'granted' | 'denied' | 'unsupported';

// --- useSyncExternalStore setup for Notification.permission ---
// SSR returns 'default' so server HTML matches the initial client render (no hydration mismatch).
// The store is essentially read-only here; we use a module-level override to update React when we
// explicitly call requestPermission().
const permListeners = new Set<() => void>();
let permOverride: NotificationPermissionState | null = null;
function notifyPermListeners() {
  permListeners.forEach((l) => l());
}
function subscribePerm(cb: () => void) {
  permListeners.add(cb);
  return () => permListeners.delete(cb);
}
function getPermissionClient(): NotificationPermissionState {
  if (permOverride) return permOverride;
  if (typeof window === 'undefined' || !('Notification' in window)) return 'unsupported';
  return Notification.permission as NotificationPermissionState;
}
// Cache the server snapshot to avoid infinite loop warnings from React
const DEFAULT_PERMISSION: NotificationPermissionState = 'default';
function getPermissionServer(): NotificationPermissionState {
  return DEFAULT_PERMISSION;
}
// --- End permission store ---

// --- useSyncExternalStore setup for "enabled" flag in localStorage ---
// The store is writable via setEnabledStore; React subscribes to changes.
const enabledListeners = new Set<() => void>();
function notifyEnabledListeners() {
  enabledListeners.forEach((l) => l());
}
function subscribeEnabled(cb: () => void) {
  enabledListeners.add(cb);
  if (typeof window !== 'undefined') {
    window.addEventListener('storage', handleStorageEvent);
  }
  return () => {
    enabledListeners.delete(cb);
    if (typeof window !== 'undefined') {
      window.removeEventListener('storage', handleStorageEvent);
    }
  };
}
function handleStorageEvent(e: StorageEvent) {
  if (e.key === ENABLED_KEY) {
    notifyEnabledListeners();
  }
}
function getEnabledClient(): boolean {
  if (typeof window === 'undefined') return false;
  // Permission must be granted for enabled to be true
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return false;
  try {
    return localStorage.getItem(ENABLED_KEY) === 'true';
  } catch {
    return false;
  }
}
// Cache the server snapshot to avoid infinite loop warnings from React
const DEFAULT_ENABLED = false;
function getEnabledServer(): boolean {
  return DEFAULT_ENABLED;
}
function setEnabledStore(value: boolean) {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(ENABLED_KEY, value ? 'true' : 'false');
  } catch {
    // ignore
  }
  notifyEnabledListeners();
}
// --- End enabled store ---

/**
 * Calculate days until next occurrence of a reminder from today
 */
function daysUntilNext(r: Reminder, today: JalaliDate): number {
  let reminderJalali: JalaliDate;
  if (r.calendar === 'jalali') {
    reminderJalali = { jy: today.jy, jm: r.month, jd: r.day };
  } else {
    const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
    reminderJalali = gregorianToJalali(todayG.gy, r.month, r.day);
  }
  let days = daysBetweenJalali(today, reminderJalali);
  if (days < 0) {
    if (r.calendar === 'jalali') {
      reminderJalali = { jy: today.jy + 1, jm: r.month, jd: r.day };
    } else {
      const todayG = jalaliToGregorian(today.jy, today.jm, today.jd);
      reminderJalali = gregorianToJalali(todayG.gy + 1, r.month, r.day);
    }
    days = daysBetweenJalali(today, reminderJalali);
  }
  return days;
}

export function useNotifications(reminders: Reminder[]) {
  // Both reads go through useSyncExternalStore — no setState-in-effect, no hydration mismatch.
  const permission = useSyncExternalStore(
    subscribePerm,
    getPermissionClient,
    getPermissionServer
  );
  const enabled = useSyncExternalStore(
    subscribeEnabled,
    getEnabledClient,
    getEnabledServer
  );

  const firedRef = useRef<Set<string>>(new Set()); // ids fired this session

  // Request permission from user (called from event handlers, not effects)
  const requestPermission = useCallback(async (): Promise<boolean> => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      permOverride = 'unsupported';
      notifyPermListeners();
      return false;
    }
    try {
      const result = await Notification.requestPermission();
      permOverride = result as NotificationPermissionState;
      notifyPermListeners();
      if (result === 'granted') {
        setEnabledStore(true);
        try {
          localStorage.setItem(PERMISSION_KEY, 'true');
        } catch {
          // ignore
        }
        // Show a welcome notification — delayed slightly so the browser settles
        // the permission state. Use absolute URL for icon.
        setTimeout(() => {
          try {
            const iconUrl = typeof window !== 'undefined'
              ? window.location.origin + '/logo.svg'
              : '/logo.svg';
            new Notification('تقویم شمسی', {
              body: 'نوتیفیکیشن با موفقیت فعال شد',
              icon: iconUrl,
              dir: 'rtl',
              lang: 'fa',
              tag: 'welcome',
            });
          } catch (e) {
            console.error('Welcome notification failed:', e);
          }
        }, 400);
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }, []);

  // Disable notifications (called from event handlers)
  const disable = useCallback(() => {
    setEnabledStore(false);
  }, []);

  // Fire a single notification
  const fireNotification = useCallback((reminder: Reminder, daysUntil: number) => {
    if (!enabled || permission !== 'granted') return;
    if (typeof window === 'undefined' || !('Notification' in window)) return;

    // Avoid duplicate firing within same session
    const fireKey = `${reminder.id}-${daysUntil}`;
    if (firedRef.current.has(fireKey)) return;
    firedRef.current.add(fireKey);

    let title: string;
    let body: string;

    if (daysUntil === 0) {
      title = `🎉 ${reminder.title}`;
      body = reminder.description
        ? `${reminder.description} — امروز`
        : 'امروز فرا رسیده است';
    } else if (daysUntil === 1) {
      title = `⏰ ${reminder.title}`;
      body = 'فردا فرا می‌رسد';
    } else {
      title = `📅 ${reminder.title}`;
      body = `${toPersianDigits(daysUntil)} روز دیگر فرا می‌رسد`;
    }

    try {
      const iconUrl = typeof window !== 'undefined'
        ? window.location.origin + '/logo.svg'
        : '/logo.svg';
      const notif = new Notification(title, {
        body,
        icon: iconUrl,
        dir: 'rtl',
        lang: 'fa',
        tag: reminder.id,
      });
      // Auto-close after 8 seconds
      setTimeout(() => {
        try {
          notif.close();
        } catch {
          // ignore
        }
      }, 8000);
    } catch (e) {
      console.error('Failed to fire notification:', e);
    }
  }, [enabled, permission]);

  // Check reminders and fire notifications if needed
  const checkAndFire = useCallback(() => {
    if (!enabled || permission !== 'granted') return;
    if (typeof window === 'undefined') return;

    const today = todayJalali();

    reminders.forEach((r) => {
      const days = daysUntilNext(r, today);
      // Fire if today (days === 0) or matches notifyDaysBefore
      if (days === 0 || days === r.notifyDaysBefore) {
        fireNotification(r, days);
      }
    });

    try {
      localStorage.setItem(LAST_CHECK_KEY, `${today.jy}-${today.jm}-${today.jd}`);
    } catch {
      // ignore
    }
  }, [enabled, permission, reminders, fireNotification]);

  // Run check on mount and every 30 minutes (in case the page stays open)
  useEffect(() => {
    if (!enabled || permission !== 'granted') return;
    // Initial check (delayed slightly to allow render)
    const initialTimer = setTimeout(() => {
      checkAndFire();
    }, 1500);
    // Periodic check every 30 minutes
    const interval = setInterval(() => {
      checkAndFire();
    }, 30 * 60 * 1000);
    return () => {
      clearTimeout(initialTimer);
      clearInterval(interval);
    };
  }, [enabled, permission, checkAndFire]);

  // Also fire when reminders list changes (e.g., user adds a new reminder for today)
  const prevRemindersRef = useRef<Reminder[]>([]);
  useEffect(() => {
    if (!enabled || permission !== 'granted') return;
    const prevIds = new Set(prevRemindersRef.current.map((r) => r.id));
    const newReminders = reminders.filter((r) => !prevIds.has(r.id));
    if (newReminders.length > 0 && prevRemindersRef.current.length > 0) {
      const today = todayJalali();
      newReminders.forEach((r) => {
        const days = daysUntilNext(r, today);
        if (days === 0 || days === r.notifyDaysBefore) {
          fireNotification(r, days);
        }
      });
    }
    prevRemindersRef.current = reminders;
  }, [reminders, enabled, permission, fireNotification]);

  // Manual test notification
  const sendTestNotification = useCallback(() => {
    if (permission !== 'granted') return;
    try {
      const iconUrl = typeof window !== 'undefined'
        ? window.location.origin + '/logo.svg'
        : '/logo.svg';
      new Notification('تقویم شمسی - آزمایش', {
        body: 'این یک نوتیفیکیشن آزمایشی است',
        icon: iconUrl,
        dir: 'rtl',
        lang: 'fa',
        tag: 'test',
      });
    } catch (e) {
      console.error('Test notification failed:', e);
    }
  }, [permission]);

  return {
    permission,
    enabled,
    requestPermission,
    disable,
    sendTestNotification,
    fireNotification,
    checkAndFire,
  };
}
