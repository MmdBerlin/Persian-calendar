/**
 * Iranian, Lunar (Qamari), and Global Events Dataset
 * - Solar (Shamsi) events: fixed by Jalali month/day
 * - Gregorian events: fixed by Gregorian month/day
 * - Lunar (Qamari) events: fixed by Hijri month/day (approximate, common Iranian observances)
 *   Note: Lunar dates shift ~11 days earlier each solar year. The dates here are the
 *   commonly-listed Iranian observances for the current year and are updated manually.
 */

export type EventType = 'national' | 'international' | 'historical' | 'cultural' | 'holiday' | 'religious';
export type EventCategory = 'shamsi' | 'qamari' | 'global';

export interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  type: EventType;
  category: EventCategory;
  calendar: 'jalali' | 'gregorian' | 'hijri';
  month: number; // 1-12
  day: number; // 1-31
  isHoliday?: boolean; // official holiday
}

// ===== Shamsi (Jalali) Events =====
export const SHAMSI_EVENTS: CalendarEvent[] = [
  // Farvardin
  { id: 'j-1-1', title: 'نوروز - آغاز سال نو', description: 'جشن نوروز و آغاز سال شمسی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 1, isHoliday: true },
  { id: 'j-1-2', title: 'عید نوروز', description: 'دومین روز جشن نوروز', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 2, isHoliday: true },
  { id: 'j-1-3', title: 'عید نوروز', description: 'سومین روز جشن نوروز', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 3, isHoliday: true },
  { id: 'j-1-4', title: 'عید نوروز', description: 'چهارمین روز جشن نوروز', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 4, isHoliday: true },
  { id: 'j-1-12', title: 'روز جمهوری اسلامی', description: 'سالروز پیروزی انقلاب اسلامی', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 12, isHoliday: true },
  { id: 'j-1-13', title: 'روز طبیعت (سیزده‌بدر)', description: 'روز طبیعت', type: 'national', category: 'shamsi', calendar: 'jalali', month: 1, day: 13, isHoliday: true },

  // Ordibehesht
  { id: 'j-2-1', title: 'روز بزرگداشت سعدی', description: 'روز بزرگداشت حکیم ابوالقاسم سعدی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 1 },
  { id: 'j-2-2', title: 'روز زمین پاک', description: 'روز بزرگداشت زمین', type: 'international', category: 'shamsi', calendar: 'jalali', month: 2, day: 2 },
  { id: 'j-2-3', title: 'روز معلم', description: 'سالروز شهادت استاد مرتضی مطهری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 2, day: 3 },
  { id: 'j-2-10', title: 'روز ملی خلیج فارس', description: 'روز ملی خلیج فارس', type: 'national', category: 'shamsi', calendar: 'jalali', month: 2, day: 10 },
  { id: 'j-2-15', title: 'روز بزرگداشت فردوسی', description: 'روز بزرگداشت حکیم ابوالقاسم فردوسی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 15 },
  { id: 'j-2-25', title: 'روز بزرگداشت حکیم عمر خیام', description: 'روز بزرگداشت حکیم عمر خیام نیشابوری', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 25 },
  { id: 'j-2-28', title: 'روز بزرگداشت حافظ', description: 'روز بزرگداشت حکیم شمس‌الدین محمد حافظ شیرازی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 2, day: 28 },

  // Khordad
  { id: 'j-3-14', title: 'رحلت امام خمینی', description: 'رحلت بنیان‌گذار جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 3, day: 14, isHoliday: true },
  { id: 'j-3-15', title: 'قیام ۱۵ خرداد', description: 'سالروز قیام خونین ۱۵ خرداد', type: 'national', category: 'shamsi', calendar: 'jalali', month: 3, day: 15, isHoliday: true },
  { id: 'j-3-4', title: 'روز دزفول', description: 'روز مقاومت و پایداری دزفول', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 3, day: 4 },
  { id: 'j-3-20', title: 'روز ملّی گل و گلاب', description: 'روز ملی گل و گلاب قمصر کاشان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 3, day: 20 },

  // Tir
  { id: 'j-4-1', title: 'روز اصناف', description: 'روز بزرگداشت اصناف و بازار ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 1 },
  { id: 'j-4-7', title: 'روز قلم', description: 'روز بزرگداشت قلم', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 4, day: 7 },
  { id: 'j-4-10', title: 'روز صنعت و معدن', description: 'روز صنعت و معدن', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 10 },
  { id: 'j-4-14', title: 'روز قلم‌مویه و دیپلماسی', description: 'روز دیپلماسی و روابط بین‌الملل', type: 'national', category: 'shamsi', calendar: 'jalali', month: 4, day: 14 },

  // Mordad
  { id: 'j-5-5', title: 'روز داروسازی - بزرگداشت زکریای رازی', description: 'روز بزرگداشت محمد زکریای رازی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 5, day: 5 },
  { id: 'j-5-14', title: 'روز اهدای خون', description: 'روز بزرگداشت اهداکنندگان خون', type: 'national', category: 'shamsi', calendar: 'jalali', month: 5, day: 14 },
  { id: 'j-5-17', title: 'روز خبرنگار', description: 'روز بزرگداشت خبرنگاران', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 5, day: 17 },

  // Shahrivar
  { id: 'j-6-1', title: 'روز پزشک - بزرگداشت ابوعلی سینا', description: 'روز بزرگداشت شیخ‌الرئیس ابوعلی سینا', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 6, day: 1 },
  { id: 'j-6-17', title: 'قیام ۱۷ شهریور', description: 'سالروز قیام خونین ۱۷ شهریور', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 6, day: 17 },
  { id: 'j-6-31', title: 'آغاز هفته دفاع مقدس', description: 'آغاز هفته دفاع مقدس', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 6, day: 31 },

  // Mehr
  { id: 'j-7-1', title: 'آغاز سال تحصیلی', description: 'آغاز سال تحصیلی جدید', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 1 },
  { id: 'j-7-5', title: 'روز شعر و ادب فارسی', description: 'روز بزرگداشت استاد شهریار', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 7, day: 5 },
  { id: 'j-7-8', title: 'روز بزرگداشت مولوی', description: 'روز بزرگداشت مولانا جلال‌الدین بلخی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 7, day: 8 },
  { id: 'j-7-13', title: 'روز نیروی انتظامی', description: 'روز نیروی انتظامی جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 13 },
  { id: 'j-7-26', title: 'روز تربیت‌بدنی و ورزش', description: 'روز تربیت بدنی و ورزش', type: 'national', category: 'shamsi', calendar: 'jalali', month: 7, day: 26 },

  // Aban
  { id: 'j-8-4', title: 'روز کوروش بزرگ', description: 'روز بزرگداشت کوروش بزرگ، بنیان‌گذار شاهنشاهی هخامنشی', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 8, day: 4 },
  { id: 'j-8-13', title: 'روز دانش‌آموز', description: 'روز بزرگداشت دانش‌آموزان', type: 'national', category: 'shamsi', calendar: 'jalali', month: 8, day: 13 },
  { id: 'j-8-24', title: 'روز کتاب و کتاب‌خوانی', description: 'روز بزرگداشت کتاب و کتاب‌خوانی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 8, day: 24 },

  // Azar
  { id: 'j-9-7', title: 'روز نیروی دریایی', description: 'روز نیروی دریایی ارتش جمهوری اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 7 },
  { id: 'j-9-16', title: 'روز دانشجو', description: 'روز بزرگداشت دانشجویان', type: 'national', category: 'shamsi', calendar: 'jalali', month: 9, day: 16 },
  { id: 'j-9-30', title: 'شب یلدا (چله)', description: 'جشن یلدا، بلندترین شب سال', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 9, day: 30 },

  // Dey
  { id: 'j-10-1', title: 'روز میلاد خورشید', description: 'آغاز فصل زمستان', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 10, day: 1 },
  { id: 'j-10-19', title: 'قیام مردم قم', description: 'سالروز قیام ۱۹ دی مردم قم', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 10, day: 19 },

  // Bahman
  { id: 'j-11-12', title: 'بازگشت امام خمینی به ایران', description: 'سالروز بازگشت امام خمینی به ایران', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 11, day: 12 },
  { id: 'j-11-19', title: 'روز نیروی هوایی', description: 'روز نیروی هوایی ارتش', type: 'national', category: 'shamsi', calendar: 'jalali', month: 11, day: 19 },
  { id: 'j-11-22', title: 'پیروزی انقلاب اسلامی', description: 'سالروز پیروزی انقلاب اسلامی ایران', type: 'national', category: 'shamsi', calendar: 'jalali', month: 11, day: 22, isHoliday: true },
  { id: 'j-11-29', title: 'قیام مردم تبریز', description: 'سالروز قیام ۲۹ بهمن مردم تبریز', type: 'historical', category: 'shamsi', calendar: 'jalali', month: 11, day: 29 },

  // Esfand
  { id: 'j-12-5', title: 'روز بزرگداشت کشاورزان و روستاییان', description: 'روز بزرگداشت کشاورزان و روستاییان', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 5 },
  { id: 'j-12-15', title: 'روز درختکاری', description: 'روز ملی درختکاری', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 15 },
  { id: 'j-12-25', title: 'روز شعر و ادب فارسی', description: 'روز بزرگداشت پروین اعتصامی', type: 'cultural', category: 'shamsi', calendar: 'jalali', month: 12, day: 25 },
  { id: 'j-12-29', title: 'روز ملی شدن صنعت نفت', description: 'سالروز ملی شدن صنعت نفت', type: 'national', category: 'shamsi', calendar: 'jalali', month: 12, day: 29, isHoliday: true },
];

// ===== Qamari (Lunar/Hijri) Events =====
// These are commonly observed Iranian religious events. Dates are in Hijri (lunar) calendar.
// NOTE: Because lunar year is ~11 days shorter than solar, these shift each year.
// The month/day here represent the Hijri date. For accurate display, the app converts
// today's solar date to Hijri and matches.
export const QAMARI_EVENTS: CalendarEvent[] = [
  { id: 'q-1-9', title: 'تاسوعای حسینی', description: 'نهم محرم', type: 'religious', category: 'qamari', calendar: 'hijri', month: 1, day: 9, isHoliday: true },
  { id: 'q-1-10', title: 'عاشورای حسینی', description: 'دهم محرم - سالروز شهادت امام حسین (ع)', type: 'religious', category: 'qamari', calendar: 'hijri', month: 1, day: 10, isHoliday: true },
  { id: 'q-1-20', title: 'چهلم امام حسین (ع)', description: 'اربعین حسینی', type: 'religious', category: 'qamari', calendar: 'hijri', month: 2, day: 20, isHoliday: true },
  { id: 'q-2-28', title: 'رحلت پیامبر اکرم (ص)', description: '۲۸ صفر المظفر', type: 'religious', category: 'qamari', calendar: 'hijri', month: 2, day: 28, isHoliday: true },
  { id: 'q-2-29', title: 'شهادت امام حسن مجتبی (ع)', description: '۲۹ صفر', type: 'religious', category: 'qamari', calendar: 'hijri', month: 2, day: 29 },
  { id: 'q-3-8', title: 'شهادت امام کاظم (ع)', description: 'هشتم ربیع‌الاول', type: 'religious', category: 'qamari', calendar: 'hijri', month: 3, day: 8 },
  { id: 'q-3-17', title: 'میلاد پیامبر اکرم (ص) و امام صادق (ع)', description: 'هفدهم ربیع‌الاول', type: 'religious', category: 'qamari', calendar: 'hijri', month: 3, day: 17, isHoliday: true },
  { id: 'q-6-3', title: 'شهادت حضرت زهرا (س)', description: 'سوم جمادی‌الثانی', type: 'religious', category: 'qamari', calendar: 'hijri', month: 6, day: 3, isHoliday: true },
  { id: 'q-7-1', title: 'میلاد امام علی (ع)', description: 'اول رجب', type: 'religious', category: 'qamari', calendar: 'hijri', month: 7, day: 1 },
  { id: 'q-7-13', title: 'میلاد امام حسین (ع)', description: 'سیزدهم رجب', type: 'religious', category: 'qamari', calendar: 'hijri', month: 7, day: 13 },
  { id: 'q-7-27', title: 'مبعث پیامبر اکرم (ص)', description: 'بیست‌وهفتم رجب', type: 'religious', category: 'qamari', calendar: 'hijri', month: 7, day: 27, isHoliday: true },
  { id: 'q-8-15', title: 'ولادت امام زمان (ع) - نیمه شعبان', description: 'پانزدهم شعبان', type: 'religious', category: 'qamari', calendar: 'hijri', month: 8, day: 15, isHoliday: true },
  { id: 'q-9-21', title: 'شهادت امام علی (ع)', description: 'بیست‌ویکم رمضان', type: 'religious', category: 'qamari', calendar: 'hijri', month: 9, day: 21, isHoliday: true },
  { id: 'q-9-19', title: 'ضربت خوردن امام علی (ع)', description: 'نوزدهم رمضان (شب قدر)', type: 'religious', category: 'qamari', calendar: 'hijri', month: 9, day: 19 },
  { id: 'q-9-23', title: 'شهادت امام علی (ع)', description: 'بیست‌وسوم رمضان', type: 'religious', category: 'qamari', calendar: 'hijri', month: 9, day: 23 },
  { id: 'q-10-1', title: 'عید سعید فطر', description: 'اول شوال', type: 'religious', category: 'qamari', calendar: 'hijri', month: 10, day: 1, isHoliday: true },
  { id: 'q-10-2', title: 'تعطیلی عید فطر', description: 'دوم شوال', type: 'religious', category: 'qamari', calendar: 'hijri', month: 10, day: 2, isHoliday: true },
  { id: 'q-10-3', title: 'تعطیلی عید فطر', description: 'سوم شوال', type: 'religious', category: 'qamari', calendar: 'hijri', month: 10, day: 3, isHoliday: true },
  { id: 'q-12-10', title: 'عید سعید قربان', description: 'دهم ذی‌الحجه', type: 'religious', category: 'qamari', calendar: 'hijri', month: 12, day: 10, isHoliday: true },
  { id: 'q-12-18', title: 'عید سعید غدیر خم', description: 'هجدهم ذی‌الحجه', type: 'religious', category: 'qamari', calendar: 'hijri', month: 12, day: 18, isHoliday: true },
];

// ===== Gregorian (Global) Events =====
export const GLOBAL_EVENTS: CalendarEvent[] = [
  { id: 'g-1-1', title: 'New Year\'s Day', description: 'آغاز سال میلادی', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 1 },
  { id: 'g-1-15', title: 'World Religion Day', description: 'روز جهانی ادیان', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 15 },
  { id: 'g-1-24', title: 'International Day of Education', description: 'روز جهانی آموزش', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 24 },
  { id: 'g-1-27', title: 'International Holocaust Remembrance Day', description: 'روز بین‌المللی یادبود هولوکاست', type: 'international', category: 'global', calendar: 'gregorian', month: 1, day: 27 },
  { id: 'g-2-4', title: 'World Cancer Day', description: 'روز جهانی سرطان', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 4 },
  { id: 'g-2-11', title: 'International Day of Women and Girls in Science', description: 'روز جهانی زنان و دختران در علم', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 11 },
  { id: 'g-2-14', title: 'Valentine\'s Day', description: 'روز ولنتاین (روز عشق)', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 14 },
  { id: 'g-2-21', title: 'International Mother Language Day', description: 'روز جهانی زبان مادری', type: 'international', category: 'global', calendar: 'gregorian', month: 2, day: 21 },
  { id: 'g-3-8', title: 'International Women\'s Day', description: 'روز جهانی حقوق زنان و صلح', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 8 },
  { id: 'g-3-21', title: 'World Poetry Day', description: 'روز جهانی شعر', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 21 },
  { id: 'g-3-22', title: 'World Water Day', description: 'روز جهانی آب', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 22 },
  { id: 'g-3-23', title: 'World Meteorological Day', description: 'روز جهانی هواشناسی', type: 'international', category: 'global', calendar: 'gregorian', month: 3, day: 23 },
  { id: 'g-4-7', title: 'World Health Day', description: 'روز جهانی بهداشت', type: 'international', category: 'global', calendar: 'gregorian', month: 4, day: 7 },
  { id: 'g-4-22', title: 'Earth Day', description: 'روز زمین', type: 'international', category: 'global', calendar: 'gregorian', month: 4, day: 22 },
  { id: 'g-4-23', title: 'World Book and Copyright Day', description: 'روز جهانی کتاب و حق مؤلف', type: 'international', category: 'global', calendar: 'gregorian', month: 4, day: 23 },
  { id: 'g-5-1', title: 'International Workers\' Day', description: 'روز جهانی کارگر', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 1 },
  { id: 'g-5-8', title: 'World Red Cross and Red Crescent Day', description: 'روز جهانی صلیب سرخ و هلال احمر', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 8 },
  { id: 'g-5-15', title: 'International Day of Families', description: 'روز جهانی خانواده', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 15 },
  { id: 'g-5-17', title: 'World Telecommunication Day', description: 'روز جهانی مخابرات', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 17 },
  { id: 'g-5-31', title: 'World No Tobacco Day', description: 'روز جهانی بدون دخانیات', type: 'international', category: 'global', calendar: 'gregorian', month: 5, day: 31 },
  { id: 'g-6-1', title: 'International Children\'s Day', description: 'روز جهانی کودکان', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 1 },
  { id: 'g-6-5', title: 'World Environment Day', description: 'روز جهانی محیط زیست', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 5 },
  { id: 'g-6-8', title: 'World Oceans Day', description: 'روز جهانی اقیانوس‌ها', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 8 },
  { id: 'g-6-21', title: 'International Day of Yoga', description: 'روز جهانی یوگا', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 21 },
  { id: 'g-6-26', title: 'International Day Against Drug Abuse', description: 'روز جهانی مبارزه با مواد مخدر', type: 'international', category: 'global', calendar: 'gregorian', month: 6, day: 26 },
  { id: 'g-7-11', title: 'World Population Day', description: 'روز جهانی جمعیت', type: 'international', category: 'global', calendar: 'gregorian', month: 7, day: 11 },
  { id: 'g-7-18', title: 'Nelson Mandela International Day', description: 'روز جهانی نلسون ماندلا', type: 'international', category: 'global', calendar: 'gregorian', month: 7, day: 18 },
  { id: 'g-8-12', title: 'International Youth Day', description: 'روز جهانی جوانان', type: 'international', category: 'global', calendar: 'gregorian', month: 8, day: 12 },
  { id: 'g-8-19', title: 'World Humanitarian Day', description: 'روز جهانی امدادگران', type: 'international', category: 'global', calendar: 'gregorian', month: 8, day: 19 },
  { id: 'g-9-8', title: 'International Literacy Day', description: 'روز جهانی سوادآموزی', type: 'international', category: 'global', calendar: 'gregorian', month: 9, day: 8 },
  { id: 'g-9-21', title: 'International Day of Peace', description: 'روز جهانی صلح', type: 'international', category: 'global', calendar: 'gregorian', month: 9, day: 21 },
  { id: 'g-9-27', title: 'World Tourism Day', description: 'روز جهانی گردشگری', type: 'international', category: 'global', calendar: 'gregorian', month: 9, day: 27 },
  { id: 'g-10-1', title: 'International Day of Older Persons', description: 'روز جهانی سالمندان', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 1 },
  { id: 'g-10-5', title: 'World Teachers\' Day', description: 'روز جهانی معلم', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 5 },
  { id: 'g-10-10', title: 'World Mental Health Day', description: 'روز جهانی سلامت روان', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 10 },
  { id: 'g-10-16', title: 'World Food Day', description: 'روز جهانی غذا', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 16 },
  { id: 'g-10-24', title: 'United Nations Day', description: 'روز سازمان ملل متحد', type: 'international', category: 'global', calendar: 'gregorian', month: 10, day: 24 },
  { id: 'g-11-11', title: 'World Science Day for Peace and Development', description: 'روز جهانی علم برای صلح و توسعه', type: 'international', category: 'global', calendar: 'gregorian', month: 11, day: 11 },
  { id: 'g-11-20', title: 'Universal Children\'s Day', description: 'روز جهانی کودکان', type: 'international', category: 'global', calendar: 'gregorian', month: 11, day: 20 },
  { id: 'g-12-1', title: 'World AIDS Day', description: 'روز جهانی ایدز', type: 'international', category: 'global', calendar: 'gregorian', month: 12, day: 1 },
  { id: 'g-12-10', title: 'Human Rights Day', description: 'روز جهانی حقوق بشر', type: 'international', category: 'global', calendar: 'gregorian', month: 12, day: 10 },
  { id: 'g-12-25', title: 'Christmas Day', description: 'روز کریسمس', type: 'international', category: 'global', calendar: 'gregorian', month: 12, day: 25 },
];

export const ALL_EVENTS: CalendarEvent[] = [...SHAMSI_EVENTS, ...QAMARI_EVENTS, ...GLOBAL_EVENTS];

export const EVENT_TYPE_LABELS: Record<EventType, string> = {
  national: 'ملی',
  international: 'جهانی',
  historical: 'تاریخی',
  cultural: 'فرهنگی',
  holiday: 'تعطیلی',
  religious: 'مذهبی',
};

export const EVENT_TYPE_COLORS: Record<EventType, string> = {
  national: 'bg-red-100 text-red-700 border-red-200',
  international: 'bg-emerald-100 text-emerald-700 border-emerald-200',
  historical: 'bg-amber-100 text-amber-700 border-amber-200',
  cultural: 'bg-violet-100 text-violet-700 border-violet-200',
  holiday: 'bg-rose-100 text-rose-700 border-rose-200',
  religious: 'bg-teal-100 text-teal-700 border-teal-200',
};

export const CATEGORY_LABELS: Record<EventCategory, string> = {
  shamsi: 'شمسی (ایرانی)',
  qamari: 'قمری (مذهبی)',
  global: 'جهانی (میلادی)',
};
