# تقویم شمسی میلادی - کد منبع (نسخه آفلاین)

این پوشه شامل کد منبع کامل اپ Next.js است که برای استفاده آفلاین/محلی طراحی شده است.

## شروع سریع

### نصب وابستگی‌ها
```bash
npm install
```

### اجرای محلی (توسعه)
```bash
npm run dev
```
اپ در http://localhost:3000 در دسترس خواهد بود.

### Build تولیدی (استاتیک - برای APK)
ابتدا فایل `next.config.ts` را ویرایش کنید:
```typescript
const nextConfig = {
  output: 'export',
  images: { unoptimized: true },
  trailingSlash: true,
};
export default nextConfig;
```

سپس:
```bash
npm run build
```
خروجی در پوشه `out/` ساخته می‌شود.

## ساخت APK (آفلاین)

برای ساخت APK آفلاین، از Capacitor استفاده کنید. راهنمای کامل در `../BUILD-GUIDE.md`.

## تکنولوژی‌ها

- **Framework**: Next.js 16 (App Router)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4
- **UI**: shadcn/ui (Radix UI)
- **Font**: Vazirmatn (فارسی)
- **PWA**: manifest.json + آیکون‌های چندسایز
- **State**: useSyncExternalStore (بدون نیاز به backend)
- **Storage**: localStorage (کاملاً آفلاین)

## قابلیت‌ها

- 📅 تقویم شمسی-میلادی با نمایش مناسبت‌ها
- 🌙 مناسبت‌های شمسی، قمری و جهانی (قابل فعال/غیرفعال)
- 🔄 تبدیل تاریخ دو طرفه
- 🎂 محاسبه سن دقیق (ذخیره آخرین محاسبه)
- 🔔 یادآورها با نوتیفیکیشن مرورگری
- 📝 یادداشت‌های عمومی (مثل یادداشت گوشی)
- 📱 پیامک خودکار به تولدها (sms: link)
- ✏️ ویرایش و حذف یادآورها
- 🎨 رابط کاربری با استایل اپل و تم لایت

## ساختار پروژه

```
├── public/
│   ├── manifest.json          # PWA manifest
│   ├── favicon.ico
│   ├── apple-touch-icon.png
│   └── icons/                 # آیکون‌های PWA
├── src/
│   ├── app/
│   │   ├── layout.tsx         # ریشه با PWA metadata
│   │   ├── page.tsx           # صفحه اصلی (۶ تب)
│   │   └── globals.css        # استایل سراسری
│   ├── components/
│   │   ├── ui/                # کامپوننت‌های shadcn/ui
│   │   └── calendar/
│   │       ├── calendar-view.tsx       # تقویم ماهانه
│   │       ├── date-converter.tsx      # تبدیل تاریخ
│   │       ├── age-calculator.tsx      # محاسبه سن
│   │       ├── reminders-manager.tsx   # مدیریت یادآورها
│   │       ├── notes-panel.tsx         # یادداشت‌های عمومی
│   │       ├── settings-panel.tsx      # تنظیمات
│   │       ├── day-details.tsx         # جزئیات روز
│   │       ├── upcoming-reminders.tsx  # یادآورهای پیش رو
│   │       └── notification-settings.tsx # تنظیمات نوتیف
│   ├── hooks/
│   │   ├── use-reminders.ts        # مدیریت یادآورها (localStorage)
│   │   ├── use-notifications.ts    # نوتیفیکیشن مرورگر
│   │   ├── use-settings.ts         # تنظیمات اپ
│   │   └── use-sms-scheduler.ts    # زمان‌بند پیامک تولد
│   └── lib/
│       ├── jalali.ts          # کتابخانه تاریخ جلالی
│       ├── hijri.ts           # تبدیل تاریخ قمری
│       ├── events.ts          # مناسبت‌های شمسی/قمری/جهانی
│       └── reminder-types.ts  # تعاریف نوع یادآور
├── package.json
├── tsconfig.json
├── tailwind.config.ts
└── next.config.ts
```

## تب‌های اپ

1. **تقویم** - تقویم ماهانه با مناسبت‌ها و یادآورها
2. **تبدیل** - تبدیل دو طرفه شمسی/میلادی
3. **سن** - محاسبه سن دقیق (ذخیره می‌شود)
4. **یادآور** - مدیریت تولدها، سالگردها و مناسبت‌ها
5. **یادداشت** - یادداشت‌های عمومی با رنگ‌های مختلف
6. **تنظیمات** - فعال/غیرفعال مناسبت‌ها + مشاهده آخرین سن

## نکته

این اپ کاملاً آفلاین کار می‌کند و تمام داده‌ها در localStorage مرورگر ذخیره می‌شوند. برای ساخت APK، به `../BUILD-GUIDE.md` مراجعه کنید.
