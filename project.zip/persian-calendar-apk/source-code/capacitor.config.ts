import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "com.persiancalendar.app",
  appName: "تقویم شمسی",
  webDir: "out",
};

export default config;
