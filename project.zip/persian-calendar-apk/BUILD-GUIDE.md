# راهنمای ساخت APK اندروید از تقویم شمسی (نسخه آفلاین/محلی)

این راهنما برای استفاده شخصی و آفلاین طراحی شده است. اپ بدون نیاز به اینترنت کار می‌کند و انتشار در Google Play در نظر گرفته نشده است.

## پیش‌نیازها

### ۱. نصب Node.js (نسخه ۱۸ یا بالاتر)
- از https://nodejs.org دانلود کنید

### ۲. نصب Android Studio
- از https://developer.android.com/studio دانلود کنید
- شامل Android SDK و JDK است
- پس از نصب، یک پروژه نمونه بسازید تا SDK نصب شود

### ۳. نصب JDK 17
- اگر Android Studio نصب باشد، JDK دارد
- متغیر `JAVA_HOME` را به مسیر JDK تنظیم کنید

---

## روش ۱: نصب با Capacitor (توصیه شده برای آفلاین)

Capacitor اپ Next.js را داخل یک APK آفلاین می‌بندد که نیازی به هاست آنلاین ندارد.

### گام ۱: Build و Export اپ

```bash
cd source-code
npm install
```

ابتدا فایل `next.config.ts` را به‌روزرسانی کنید تا خروجی استاتیک بدهد:

```typescript
// next.config.ts
const nextConfig = {
  output: 'export',
  images: { unoptimized: true },
  trailingSlash: true,
};
export default nextConfig;
```

سپس:
```bash
npm run build
```

خروجی در پوشه `out/` ساخته می‌شود.

### گام ۲: نصب Capacitor

```bash
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "تقویم شمسی" "com.persiancalendar.app" --web-dir=out
```

### گام ۳: اضافه کردن پلتفرم اندروید

```bash
npx cap add android
npx cap copy
npx cap sync
```

### گام ۴: باز کردن در Android Studio و گرفتن APK

```bash
npx cap open android
```

در Android Studio:
1. منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** را انتخاب کنید
2. صبر کنید تا build تمام شود
3. روی notification «locate» کلیک کنید تا پوشه خروجی باز شود
4. فایل `app-debug.apk` را پیدا کنید

### گام ۵: نصب روی گوشی

```bash
# با USB به کامپیوتر وصل کنید و USB Debugging را روشن کنید
adb install app/build/outputs/apk/debug/app-debug.apk
```

یا فایل APK را مستقیم روی گوشی کپی و نصب کنید.

---

## روش ۲: نصب با Bubblewrap (نیاز به هاست محلی)

این روش برای زمانی است که می‌خواهید اپ را روی localhost اجرا کنید.

### گام ۱: اجرای اپ روی localhost

```bash
cd source-code
npm install
npm run build
npm start
```

اپ روی http://localhost:3000 اجرا می‌شود.

### گام ۲: نصب Bubblewrap و ساخت TWA

```bash
npm install -g @bubblewrap/cli
mkdir persian-calendar-twa && cd persian-calendar-twa
bubblewrap init --manifest http://localhost:3000/manifest.json
bubblewrap build
```

**نکته:** TWA نیاز به HTTPS دارد. برای localhost می‌توانید از `mkcert` استفاده کنید:
```bash
mkcert localhost
# سپس next را با HTTPS اجرا کنید
```

---

## روش ۳: نصب مستقیم به‌عنوان PWA (ساده‌ترین)

بدون ساخت APK، می‌توانید اپ را به‌عنوان PWA روی گوشی نصب کنید:

1. اپ را روی یک هاست محلی یا آنلاین اجرا کنید
2. در مرورگر کروم اندروید باز کنید
3. منوی سه‌نقطه > **Add to Home screen**
4. اپ آیکون روی صفحه‌ن اصلی ظاهر می‌شود و مثل اپ‌های بومی اجرا می‌شود

---

## رفع مشکل

### مشکل: "Cannot find Android SDK"
```bash
export ANDROID_HOME=$HOME/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/platform-tools
```

### مشکل: "Java version mismatch"
JDK 17 باید نصب باشد. در Android Studio: Settings > Build > Gradle > JDK را روی ۱۷ تنظیم کنید.

### مشکل: نوتیفیکیشن‌ها کار نمی‌کنند
نوتیفیکیشن‌های وب در TWA/Capacitor فقط زمانی کار می‌کنند که:
1. Android API level 26+ (اندروید ۸ به بالا) باشد
2. کاربر در تنظیمات گوشی به اپ اجازه نوتیف داده باشد
3. صفحه اپ باز باشد (برای نوتیف‌های زمان‌بندی‌شده)

### مشکل: پیامک خودکار ارسال نمی‌شود
در حالت آفلاین، اپ در ساعت مشخص یک لینک `sms:` باز می‌کند و اپ پیامک پیش‌فرض گوشی را با متن و شماره آماده‌شده باز می‌کند. شما باید روی «ارسال» بزنید. ارسال کاملاً خودکار نیاز به سرویس آنلاین پیامک (مثل کاوه‌نگار یا ملی‌پیامک) با API key دارد که در نسخه آفلاین امکان‌پذیر نیست.

### مشکل: لینک‌های `tel:` و `sms:` در Capacitor باز نمی‌شوند
در `android/app/src/main/AndroidManifest.xml` این intent filter را اضافه کنید:
```xml
<intent-filter>
    <action android:name="android.intent.action.SENDTO" />
    <data android:scheme="sms" />
    <data android:scheme="smsto" />
    <data android:scheme="tel" />
</intent-filter>
```

---

## مشخصات فنی اپ

| ویژگی | مقدار |
|---|---|
| **نام اپ** | تقویم شمسی میلادی |
| **Package ID پیشنهادی** | `com.persiancalendar.app` |
| **حداقل اندروید** | ۸.۰ (API 26) |
| **اندروید هدف** | ۱۴ (API 34) |
| **جهت** | عمودی (portrait) |
| **تم رنگ** | `#5856D6` (آبی-بنفش) |
| **زبان** | فارسی (RTL) |
| **حالت** | آفلاین / محلی |
| **اندازه APK حدودی** | ۳-۵ مگابایت |

---

## خلاصه دستورات (روش Capacitor)

```bash
# ۱. نصب وابستگی‌ها
cd source-code
npm install

# ۲. ویرایش next.config.ts (output: export)

# ۳. Build استاتیک
npm run build

# ۴. نصب Capacitor
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "تقویم شمسی" "com.persiancalendar.app" --web-dir=out

# ۵. اضافه کردن اندروید
npx cap add android
npx cap copy
npx cap sync

# ۶. باز کردن در Android Studio و Build APK
npx cap open android
# در Android Studio: Build > Build APK(s)

# ۷. نصب روی گوشی
adb install app/build/outputs/apk/debug/app-debug.apk
```

موفق باشید! 🎉
